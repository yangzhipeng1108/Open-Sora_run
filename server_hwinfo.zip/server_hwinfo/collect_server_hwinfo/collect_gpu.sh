#!/bin/bash

# ============================================================================
# 服务器GPU信息收集脚本 - v33
#
# 变更（相比 v32）：
#   - ★ 修复 mock 模式下 get_pcie_slot 返回 Unknown 的问题
#       原因：readlink -f 是直连真机 sysfs，mock 环境读不到
#       修复：readlink -f 走 run_cmd，mock 模式从 sysfs.realpath.<key>.txt 读
#   - 配套 make_mock.sh 需新增生成 sysfs.realpath.<key>.txt 文件
#
# v32 变更保留：
#   - 新增模拟测试能力 --mock-dir / MOCK_DIR
#
# 列顺序（30 列）:
#   server_serial, gpu_index, gpu_uuid,
#   gpu_vendor, gpu_model, gpu_product, gpu_serial, gpu_memory_mib,
#   gpu_vbios_ver, gpu_driver_ver, pcie_bus_id, pcie_slot,
#   pcie_vendor_id, pcie_product_id,
#   pcie_gen, pcie_link_cap, pcie_link_sta, gpu_nvlink,
#   gpu_power_cap, gpu_smi_ver, software_stack_ver,
#   gpu_sm_clk_mhz, gpu_mem_clk_mhz,
#   gpu_fan_speed, gpu_temperature_celsius, gpu_ecc_errors,
#   gpu_power_draw_w, gpu_memory_used_mib, gpu_utilization_percent, gpu_ecc_mode
# ============================================================================

SCRIPT_NAME=$(basename "$0")
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUTPUT_DIR="${OUTPUT_DIR:-${SCRIPT_DIR}/report}"
OUTPUT_FILE=""
SYSTEM_SERIAL=""
DEBUG="${DEBUG:-false}"

# Mock 开关
MOCK_DIR="${MOCK_DIR:-}"
MOCK_MODE=false
[[ -n "$MOCK_DIR" ]] && MOCK_MODE=true

# ---------------------------------------------------------------------------
# Mock / 命令执行包装
# ---------------------------------------------------------------------------

_mock_bdf_key() {
    local bdf="$1"
    bdf="${bdf//:/_}"
    bdf="${bdf//./_}"
    echo "$bdf"
}

run_cmd() {
    local name="$1"; shift
    [[ "$1" == "--" ]] && shift
    if [[ "$MOCK_MODE" == "true" ]]; then
        local f="$MOCK_DIR/${name}.txt"
        if [[ -r "$f" ]]; then
            cat "$f"
        else
            log_debug "mock 缺失: $f"
        fi
        return 0
    fi
    "$@" 2>/dev/null || true
}

have_cmd() {
    [[ "$MOCK_MODE" == "true" ]] && return 0
    command -v "$1" &>/dev/null
}

# ---------------------------------------------------------------------------
# 全局缓存
# ---------------------------------------------------------------------------

declare -a NV_ROWS=()
NV_ROWS_LOADED=false
NVIDIA_SMI_CACHE=""
NVIDIA_SMI_LOADED=false

declare -A LSPCI_VV_CACHE=()
declare -A Q_IDX=()

declare -A PCI_SLOT_MAP=()
PCI_SLOT_MAP_LOADED=false

declare -A NV_TOPO_CACHE=()
NV_TOPO_LOADED=false

declare -A RETIRED_PAGES_CACHE=()
RETIRED_PAGES_LOADED=false

declare -A REMAPPED_ROWS_CACHE=()
REMAPPED_ROWS_LOADED=false

# AMD 缓存
declare -a AMD_BDFS=()
declare -A AMD_GPU_NAME=()
declare -A AMD_GPU_TEMP=()
declare -A AMD_GPU_FAN=()
declare -A AMD_GPU_MEM_TOTAL=()
declare -A AMD_GPU_POWER_CAP=()
declare -A AMD_GPU_HIP_ID=()
declare -A AMD_GPU_UUID=()
declare -A AMD_GPU_SERIAL=()
declare -A AMD_GPU_VBIOS=()
declare -A AMD_GPU_DRIVER_VER=()
declare -A AMD_GPU_PRODUCT_NAME=()

declare -A AMD_GPU_ECC_CE=()
declare -A AMD_GPU_ECC_UE=()
declare -A AMD_GPU_ECC_DF=()
declare -A AMD_GPU_ECC_HAS=()

declare -A AMD_GPU_SM_CLK=()
declare -A AMD_GPU_MEM_CLK=()

AMD_LOADED=false

declare -A AMD_TOPO_CACHE=()
AMD_TOPO_LOADED=false

_AMD_VER_LOADED=false
_AMD_VER_CACHE_SMI="N/A"
_AMD_VER_CACHE_ROCM="N/A"

declare -A _AMD_SECTIONS=()

NV_SMI_VER_CACHE=""
NV_SMI_VER_LOADED=false

# ---------------------------------------------------------------------------
# 颜色 / 日志
# ---------------------------------------------------------------------------

readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly NC='\033[0m'

log_info()  { echo -e "${GREEN}[INFO]${NC} $*" >&2; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC} $*" >&2; }
log_error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }
log_debug() { [[ "${DEBUG}" == "true" ]] && echo -e "${BLUE}[DEBUG]${NC} $*" >&2 || true; }

print_separator() { echo "=========================================" >&2; }
print_header() {
    print_separator
    echo -e "${GREEN}$1${NC}" >&2
    print_separator
}

# ---------------------------------------------------------------------------
# CSV 转义
# ---------------------------------------------------------------------------

csv_escape() {
    local field="$1"
    [[ -z "$field" ]] && { echo ""; return; }
    if [[ "$field" == *","* || "$field" == *"\""* ]]; then
        field=${field//\"/\"\"}
        echo "\"$field\""
    else
        echo "$field"
    fi
}

# ---------------------------------------------------------------------------
# PCI 地址规范化
# ---------------------------------------------------------------------------

normalize_pci_addr() {
    local addr
    addr=$(echo "$1" | tr 'A-F' 'a-f' | tr -d ' ')

    # 摩尔线程 mthreads-gmi 输出 8 位十六进制域号（如 00000000:2a:00.0），
    # 先单独截取到标准 0000 域，避免被下面 [0-9a-f]+ 匹配后 $((16#...))
    # 因超出 64 位而溢出。
    if [[ "$addr" =~ ^[0-9a-f]{8}:([0-9a-f]{2}:[0-9a-f]{2}\.[0-9a-f])$ ]]; then
        printf "0000:%s" "${BASH_REMATCH[1]}"
        return
    fi

    if [[ "$addr" =~ ^([0-9a-f]+):([0-9a-f]{2}):([0-9a-f]{2})\.([0-9a-f])$ ]]; then
        local domain=$((16#${BASH_REMATCH[1]}))
        printf "%04x:%s:%s.%s" "$domain" "${BASH_REMATCH[2]}" "${BASH_REMATCH[3]}" "${BASH_REMATCH[4]}"
        return
    fi
    if [[ "$addr" =~ ^([0-9a-f]{2}):([0-9a-f]{2})\.([0-9a-f])$ ]]; then
        printf "0000:%s:%s.%s" "${BASH_REMATCH[1]}" "${BASH_REMATCH[2]}" "${BASH_REMATCH[3]}"
        return
    fi
    echo "$addr"
}

# ---------------------------------------------------------------------------
# PCIe slot 映射
# ---------------------------------------------------------------------------

_normalize_dmi_addr() {
    local a
    a=$(echo "$1" | tr 'A-F' 'a-f' | tr -d ' ')
    if [[ "$a" =~ ^([0-9a-f]{4}:[0-9a-f]{2}:[0-9a-f]{2})$ ]]; then
        a="${a}.0"
    fi
    if [[ "$a" =~ ^([0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}\.[0-9a-f])$ ]]; then
        a="0000:$a"
    fi
    echo "$a"
}

load_pci_slot_map() {
    [[ "$PCI_SLOT_MAP_LOADED" == "true" ]] && return
    local cur=""
    local count=0
    while IFS= read -r line; do
        if [[ "$line" =~ Designation:[[:space:]]*(.+) ]]; then
            cur="${BASH_REMATCH[1]}"
        fi
        if [[ "$line" =~ Bus[[:space:]]Address:[[:space:]]*([0-9a-fA-F:.]+) ]]; then
            local key
            key=$(_normalize_dmi_addr "${BASH_REMATCH[1]}")
            if [[ -n "$key" ]]; then
                PCI_SLOT_MAP["$key"]="$cur"
                count=$((count + 1))
            fi
        fi
    done < <(run_cmd dmidecode.slot -- sudo dmidecode -t slot)
    PCI_SLOT_MAP_LOADED=true
    log_debug "PCI slot 表加载完成，共 ${count} 条"

    if [[ "$MOCK_MODE" == "true" && "$count" -eq 0 ]]; then
        log_warn "mock 模式下 PCI_SLOT_MAP 为空，请检查 $MOCK_DIR/dmidecode.slot.txt"
    fi
}

# ---------------------------------------------------------------------------
# ★ v33：get_pcie_slot 完整版
#   realpath 走 run_cmd，mock 模式从 sysfs.realpath.<key>.txt 读
# ---------------------------------------------------------------------------

get_pcie_slot() {
    local bdf="$1"
    [[ -z "$bdf" ]] || [[ "$bdf" == "N/A" ]] || [[ "$bdf" == "Unknown" ]] && { echo "N/A"; return; }

    # 统一成全 BDF
    bdf=$(echo "$bdf" | tr 'A-F' 'a-f')
    if [[ "$bdf" =~ ^[0-9a-f]{2}:[0-9a-f]{2}\.[0-9a-f]$ ]]; then
        bdf="0000:$bdf"
    fi

    # ★ realpath 走 run_cmd
    local key_file; key_file=$(_mock_bdf_key "$bdf")
    local realpath
    realpath=$(run_cmd "sysfs.realpath.${key_file}" -- readlink -f "/sys/bus/pci/devices/$bdf")

    if [[ -z "$realpath" ]]; then
        echo "Unknown"
        return
    fi

    # 从 realpath 抽 BDF 链（从 GPU 往上到 root），tac 反转成从 root 向下
    local chain
    chain=$(echo "$realpath" | tr '/' '\n' \
            | grep -E '^[0-9a-f]{4}:[0-9a-f]{2}:[0-9a-f]{2}\.[0-9a-f]$' \
            | tac)

    # ① 精确 BDF 匹配
    local p
    while IFS= read -r p; do
        if [[ -n "${PCI_SLOT_MAP[$p]+x}" ]]; then
            echo "${PCI_SLOT_MAP[$p]}"
            return
        fi
    done <<< "$chain"

    # ② 按 bus 号容错匹配
    while IFS= read -r p; do
        local bus
        bus=$(echo "$p" | cut -d':' -f2)
        local k
        for k in "${!PCI_SLOT_MAP[@]}"; do
            local kbus
            kbus=$(echo "$k" | cut -d':' -f2)
            if [[ "$bus" == "$kbus" ]]; then
                log_debug "容错匹配: $p ≈ $k → ${PCI_SLOT_MAP[$k]}"
                echo "${PCI_SLOT_MAP[$k]}"
                return
            fi
        done
    done <<< "$chain"

    # ③ 未命中，返回带链信息的 Unknown
    echo "Unknown($(echo "$chain" | tr '\n' '|' | sed 's/|$//'))"
}

# ---------------------------------------------------------------------------
# nvidia-smi query 字段映射
# ---------------------------------------------------------------------------

init_query_fields() {
    local fields=(
        index name uuid serial memory.total vbios_version
        pci.bus_id
        pcie.link.gen.current pcie.link.gen.max
        pcie.link.width.current pcie.link.width.max
        power.limit power.draw temperature.gpu fan.speed driver_version
        memory.used utilization.gpu
        clocks.max.sm clocks.max.mem
        ecc.mode.current
        ecc.errors.corrected.volatile.total
        ecc.errors.uncorrected.volatile.total
        ecc.errors.corrected.aggregate.total
        ecc.errors.uncorrected.aggregate.total
    )
    Q_IDX=()
    local i=1
    for f in "${fields[@]}"; do
        Q_IDX["$f"]=$i
        i=$((i + 1))
    done
}

# ---------------------------------------------------------------------------
# nvidia-smi 缓存
# ---------------------------------------------------------------------------

load_nv_rows() {
    [[ "$NV_ROWS_LOADED" == "true" ]] && return 0

    local fields="index,name,uuid,serial,memory.total,vbios_version,pci.bus_id,pcie.link.gen.current,pcie.link.gen.max,pcie.link.width.current,pcie.link.width.max,power.limit,power.draw,temperature.gpu,fan.speed,driver_version,memory.used,utilization.gpu,clocks.max.sm,clocks.max.mem,ecc.mode.current,ecc.errors.corrected.volatile.total,ecc.errors.uncorrected.volatile.total,ecc.errors.corrected.aggregate.total,ecc.errors.uncorrected.aggregate.total"

    local raw
    raw=$(run_cmd nvidia-smi.query -- nvidia-smi --query-gpu="$fields" --format=csv,noheader)

    NV_ROWS=()
    if [[ -n "$raw" ]]; then
        while IFS= read -r l; do
            [[ -n "$l" ]] && NV_ROWS+=("$l")
        done <<< "$raw"
    fi
    NV_ROWS_LOADED=true
}

q_named() {
    local gpu_idx="$1" field_name="$2"
    load_nv_rows
    local line="${NV_ROWS[$gpu_idx]}"
    [[ -z "$line" ]] && { echo ""; return; }
    local idx="${Q_IDX[$field_name]}"
    [[ -z "$idx" ]] && { echo ""; return; }
    echo "$line" | awk -F',' -v n="$idx" '{gsub(/^[ \t]+|[ \t]+$/,"",$n); print $n}'
}

load_nv_smi() {
    [[ "$NVIDIA_SMI_LOADED" == "true" ]] && return 0
    NVIDIA_SMI_CACHE=$(run_cmd nvidia-smi.header -- nvidia-smi)
    NVIDIA_SMI_LOADED=true
}

# ---------------------------------------------------------------------------
# NVLink / PCIe 拓扑
# ---------------------------------------------------------------------------

load_nv_topo() {
    [[ "$NV_TOPO_LOADED" == "true" ]] && return 0
    NV_TOPO_LOADED=true

    local raw
    raw=$(run_cmd nvidia-smi.topo -- nvidia-smi topo -m)
    [[ -z "$raw" ]] && return

    local gpu_count
    gpu_count=$(run_cmd nvidia-smi.query-index -- nvidia-smi --query-gpu=index --format=csv,noheader | wc -l)
    [[ -z "$gpu_count" || "$gpu_count" -le 0 ]] && return

    local line
    while IFS= read -r line; do
        line="${line%$'\r'}"
        if [[ "$line" =~ ^(GPU[0-9]+)[[:space:]] ]]; then
            local row_label="${BASH_REMATCH[1]}"
            local idx="${row_label#GPU}"
            local -a tk=()
            read -ra tk <<< "$line"
            local -a uniq=()
            local i
            for ((i=1; i<=gpu_count; i++)); do
                local target="GPU$((i-1))"
                [[ "$target" == "$row_label" ]] && continue
                local val="${tk[$i]:-}"
                [[ -z "$val" || "$val" == "X" ]] && continue
                local seen=false u
                for u in "${uniq[@]}"; do [[ "$u" == "$val" ]] && { seen=true; break; }; done
                [[ "$seen" == "false" ]] && uniq+=("$val")
            done

            local nv_parts
            if [[ ${#uniq[@]} -eq 0 ]]; then
                nv_parts="N/A"
            else
                nv_parts=$(printf '%s\n' "${uniq[@]}" | LC_ALL=C sort | paste -sd '/' -)
            fi
            NV_TOPO_CACHE["$idx"]="$nv_parts"
        fi
    done <<< "$raw"
}

get_gpu_nvlink() {
    local gpu_idx="$1"
    load_nv_topo
    if [[ -n "${NV_TOPO_CACHE[$gpu_idx]+x}" ]]; then
        echo "${NV_TOPO_CACHE[$gpu_idx]}"
    else
        echo "N/A"
    fi
}

# ---------------------------------------------------------------------------
# retired_pages / remapped_rows
# ---------------------------------------------------------------------------

load_retired_pages() {
    [[ "$RETIRED_PAGES_LOADED" == "true" ]] && return 0
    RETIRED_PAGES_LOADED=true
    local raw
    raw=$(run_cmd nvidia-smi.retired-pages -- \
          nvidia-smi --query-retired-pages=gpu_name,gpu_bus_id,retired_pages.cause,retired_pages.timestamp \
          --format=csv,noheader)
    if [[ -n "$raw" ]]; then
        while IFS= read -r l; do
            [[ -z "$l" ]] && continue
            local bus_id
            bus_id=$(echo "$l" | awk -F',' '{gsub(/^[ \t]+|[ \t]+$/,"",$2); print $2}')
            [[ -n "$bus_id" && "$bus_id" != "N/A" ]] && \
                RETIRED_PAGES_CACHE["$(normalize_pci_addr "$bus_id")"]="$l"
        done <<< "$raw"
    fi
}

load_remapped_rows() {
    [[ "$REMAPPED_ROWS_LOADED" == "true" ]] && return 0
    REMAPPED_ROWS_LOADED=true
    local raw
    raw=$(run_cmd nvidia-smi.remapped-rows -- \
          nvidia-smi --query-remapped-rows=gpu_name,gpu_bus_id,remapped_rows.correctable,remapped_rows.uncorrectable,remapped_rows.pending,remapped_rows.failure \
          --format=csv,noheader)
    if [[ -n "$raw" ]]; then
        while IFS= read -r l; do
            [[ -z "$l" ]] && continue
            local bus_id
            bus_id=$(echo "$l" | awk -F',' '{gsub(/^[ \t]+|[ \t]+$/,"",$2); print $2}')
            [[ -n "$bus_id" && "$bus_id" != "N/A" ]] && \
                REMAPPED_ROWS_CACHE["$(normalize_pci_addr "$bus_id")"]="$l"
        done <<< "$raw"
    fi
}

# ---------------------------------------------------------------------------
# is_na
# ---------------------------------------------------------------------------

is_na() {
    local v="$1"
    [[ -z "$v" ]] && return 0
    case "$v" in
        "N/A"|"[N/A]"|"[Not Supported]"|"None"|"Unknown") return 0 ;;
    esac
    return 1
}

# ---------------------------------------------------------------------------
# lspci / sysfs
# ---------------------------------------------------------------------------

_get_lspci_vv() {
    local pci_addr="$1"
    [[ -z "$pci_addr" ]] || [[ "$pci_addr" == "Unknown" ]] && { echo ""; return; }
    local key; key=$(normalize_pci_addr "$pci_addr")
    if [[ -n "${LSPCI_VV_CACHE[$key]+x}" ]]; then
        echo "${LSPCI_VV_CACHE[$key]}"; return
    fi
    local key_file; key_file=$(_mock_bdf_key "$key")
    local info
    info=$(run_cmd "lspci.vv.${key_file}" -- lspci -s "$key" -vv)
    LSPCI_VV_CACHE["$key"]="$info"
    echo "$info"
}

_get_pcie_vid_sysfs() {
    local pci_addr="$1"
    [[ -z "$pci_addr" ]] || [[ "$pci_addr" == "Unknown" ]] && { echo ""; return; }
    local key; key=$(normalize_pci_addr "$pci_addr")
    local key_file; key_file=$(_mock_bdf_key "$key")
    local v
    v=$(run_cmd "sysfs.vendor.${key_file}" -- cat "/sys/bus/pci/devices/$key/vendor" | tr -d ' \n')
    v="${v#0x}"
    echo "$v"
}

_get_pcie_pid_sysfs() {
    local pci_addr="$1"
    [[ -z "$pci_addr" ]] || [[ "$pci_addr" == "Unknown" ]] && { echo ""; return; }
    local key; key=$(normalize_pci_addr "$pci_addr")
    local key_file; key_file=$(_mock_bdf_key "$key")
    local v
    v=$(run_cmd "sysfs.device.${key_file}" -- cat "/sys/bus/pci/devices/$key/device" | tr -d ' \n')
    v="${v#0x}"
    echo "$v"
}

# ---------------------------------------------------------------------------
# GPU 硬件探测
# ---------------------------------------------------------------------------

detect_nvidia_gpu() {
    if [[ "$MOCK_MODE" == "true" ]]; then
        [[ -f "$MOCK_DIR/nvidia-smi.query.txt" ]] && return 0
        if [[ -f "$MOCK_DIR/lspci.nn.txt" ]]; then
            grep -qiE '\[10de:' "$MOCK_DIR/lspci.nn.txt" && return 0
        fi
        return 1
    fi

    if command -v lspci &>/dev/null; then
        local hits
        hits=$(lspci -nn 2>/dev/null | grep -iE '\[10de:[0-9a-f]{4}\]' || true)
        [[ -z "$hits" ]] && hits=$(lspci 2>/dev/null | grep -i 'nvidia' || true)
        if [[ -n "$hits" ]]; then
            while IFS= read -r l; do log_debug "  NV: $l"; done <<< "$hits"
            return 0
        fi
    fi
    local d v
    for d in /sys/bus/pci/devices/*/vendor; do
        [[ -r "$d" ]] || continue
        v=$(cat "$d" 2>/dev/null)
        [[ "$v" == "0x10de" ]] && return 0
    done
    return 1
}

detect_amd_gpu() {
    if [[ "$MOCK_MODE" == "true" ]]; then
        [[ -f "$MOCK_DIR/amd-smi.static.txt" ]] && return 0
        [[ -f "$MOCK_DIR/amd-smi.list.txt" ]] && return 0
        if [[ -f "$MOCK_DIR/lspci.nn.txt" ]]; then
            grep -qiE '\[1002:' "$MOCK_DIR/lspci.nn.txt" && return 0
        fi
        return 1
    fi

    if command -v lspci &>/dev/null; then
        local hits
        hits=$(lspci -nn 2>/dev/null \
               | grep -iE '\[1002:[0-9a-f]{4}\]' \
               | grep -iE '(VGA compatible controller|Display controller|3D controller|Processing accelerators)' \
               || true)
        if [[ -n "$hits" ]]; then
            while IFS= read -r l; do log_debug "  AMD: $l"; done <<< "$hits"
            return 0
        fi
    fi
    local d v cls
    for d in /sys/bus/pci/devices/*/vendor; do
        [[ -r "$d" ]] || continue
        v=$(cat "$d" 2>/dev/null)
        [[ "$v" != "0x1002" ]] && continue
        local cls_f; cls_f="$(dirname "$d")/class"
        if [[ -r "$cls_f" ]]; then
            cls=$(cat "$cls_f" 2>/dev/null)
            [[ "$cls" =~ ^0x03 || "$cls" =~ ^0x12 ]] && return 0
        fi
    done
    return 1
}

# ---------------------------------------------------------------------------
# 摩尔线程（Moore Threads）GPU 探测
#   PCI vendor id = 1ed5，class 为 3D controller(0302)
# ---------------------------------------------------------------------------

detect_moore_gpu() {
    if [[ "$MOCK_MODE" == "true" ]]; then
        [[ -f "$MOCK_DIR/mthreads-gmi.header.txt" ]] && return 0
        [[ -f "$MOCK_DIR/mthreads-gmi.gpus.txt" ]] && return 0
        if [[ -f "$MOCK_DIR/lspci.nn.txt" ]]; then
            grep -qiE '\[1ed5:' "$MOCK_DIR/lspci.nn.txt" && return 0
        fi
        return 1
    fi

    if command -v lspci &>/dev/null; then
        local hits
        hits=$(lspci -nn 2>/dev/null \
               | grep -iE '\[1ed5:[0-9a-f]{4}\]' \
               | grep -iE '(VGA compatible controller|Display controller|3D controller|Processing accelerators)' \
               || true)
        if [[ -n "$hits" ]]; then
            while IFS= read -r l; do log_debug "  MTT: $l"; done <<< "$hits"
            return 0
        fi
    fi
    local d v cls
    for d in /sys/bus/pci/devices/*/vendor; do
        [[ -r "$d" ]] || continue
        v=$(cat "$d" 2>/dev/null)
        [[ "$v" != "0x1ed5" ]] && continue
        local cls_f; cls_f="$(dirname "$d")/class"
        if [[ -r "$cls_f" ]]; then
            cls=$(cat "$cls_f" 2>/dev/null)
            [[ "$cls" =~ ^0x03 || "$cls" =~ ^0x12 ]] && return 0
        fi
    done
    return 1
}

# ---------------------------------------------------------------------------
# 从 "KEY: value" 行提取值
# ---------------------------------------------------------------------------

_amd_kv() {
    local text="$1" key="$2"
    printf '%s\n' "$text" | awk -v k="$key" '
        {
            line = $0
            sub(/^[[:space:]]+/, "", line)
            if (line ~ ("^" k ":[[:space:]]*")) {
                sub(("^" k ":[[:space:]]*"), "", line)
                sub(/[[:space:]]+$/, "", line)
                print line
                exit
            }
        }
    '
}

_amd_kv_nth() {
    local text="$1" key="$2" n="$3"
    printf '%s\n' "$text" | awk -v k="$key" -v want="$n" '
        {
            line = $0
            sub(/^[[:space:]]+/, "", line)
            if (line ~ ("^" k ":[[:space:]]*")) {
                count++
                if (count == want) {
                    sub(("^" k ":[[:space:]]*"), "", line)
                    sub(/[[:space:]]+$/, "", line)
                    print line
                    exit
                }
            }
        }
    '
}

# 从 CLOCK 段取某子段的最大频率（MHz）
_amd_clock_max_freq() {
    local text="$1" subkey="$2"
    printf '%s\n' "$text" | awk -v k="$subkey" '
        BEGIN { in_clock=0; in_sub=0; in_levels=0; max=0 }
        /^[[:space:]]*CLOCK:[[:space:]]*$/ { in_clock=1; in_sub=0; in_levels=0; next }
        in_clock && /^[[:space:]]{0,4}[A-Z_]+:[[:space:]]*$/ && !/CLOCK:/ {
            in_clock=0; in_sub=0; in_levels=0
        }
        !in_clock { next }
        $0 ~ ("^[[:space:]]+"k":[[:space:]]*$") { in_sub=1; in_levels=0; next }
        in_sub && /FREQUENCY_LEVELS:[[:space:]]*$/ { in_levels=1; next }
        in_levels && /LEVEL [0-9]+:/ {
            line=$0
            sub(/.*:[[:space:]]*/, "", line)
            sub(/[^0-9].*/, "", line)
            if (line+0 > max) max = line+0
            next
        }
        END { if (max > 0) print max }
    '
}

# ---------------------------------------------------------------------------
# 多 GPU 分段
# ---------------------------------------------------------------------------

_amd_split_gpu_sections_into() {
    local raw="$1"
    _AMD_SECTIONS=()
    local cur="" buf="" line
    while IFS= read -r line; do
        line="${line%$'\r'}"
        if [[ "$line" =~ ^GPU:[[:space:]]*([0-9]+)[[:space:]]*$ ]]; then
            [[ -n "$cur" ]] && _AMD_SECTIONS["$cur"]="$buf"
            cur="${BASH_REMATCH[1]}"
            buf=""
        elif [[ -n "$cur" ]]; then
            buf+="$line"$'\n'
        fi
    done <<< "$raw"
    [[ -n "$cur" ]] && _AMD_SECTIONS["$cur"]="$buf"
}

# ---------------------------------------------------------------------------
# AMD 版本合并探测
# ---------------------------------------------------------------------------

_get_amd_versions() {
    [[ "$_AMD_VER_LOADED" == "true" ]] && return
    _AMD_VER_LOADED=true

    _AMD_VER_CACHE_SMI="N/A"
    _AMD_VER_CACHE_ROCM="N/A"

    if have_cmd amd-smi; then
        local vout
        vout=$(run_cmd amd-smi.version -- amd-smi version)
        if [[ -n "$vout" ]]; then
            local smi_ver
            smi_ver=$(echo "$vout" \
                | grep -oE 'AMD-SMI([[:space:]]+version:)?[[:space:]]+[0-9]+\.[0-9]+\.[0-9]+[^[:space:]|]*' \
                | head -1 \
                | grep -oE '[0-9]+\.[0-9]+\.[0-9]+[^[:space:]|]*')
            [[ -n "$smi_ver" ]] && _AMD_VER_CACHE_SMI="$smi_ver"

            local rocm_ver
            rocm_ver=$(echo "$vout" \
                | grep -oE 'ROCm[[:space:]]+version:[[:space:]]*[0-9.]+' \
                | head -1 | grep -oE '[0-9.]+$')
            [[ -n "$rocm_ver" ]] && _AMD_VER_CACHE_ROCM="ROCm $rocm_ver"
        fi
    fi

    if [[ "$_AMD_VER_CACHE_ROCM" == "N/A" ]]; then
        local v
        v=$(run_cmd opt-rocm.version -- cat /opt/rocm/.info/version | head -1 | tr -d '[:space:]')
        [[ -n "$v" ]] && _AMD_VER_CACHE_ROCM="ROCm $v"
    fi

    log_debug "AMD 版本: SMI=$_AMD_VER_CACHE_SMI, ROCm=$_AMD_VER_CACHE_ROCM"
}

get_amd_smi_version() { _get_amd_versions; echo "$_AMD_VER_CACHE_SMI"; }
get_rocm_version()    { _get_amd_versions; echo "$_AMD_VER_CACHE_ROCM"; }

# ---------------------------------------------------------------------------
# NVIDIA SMI 版本
# ---------------------------------------------------------------------------

get_nvidia_smi_version() {
    [[ "$NV_SMI_VER_LOADED" == "true" ]] && { echo "$NV_SMI_VER_CACHE"; return; }
    NV_SMI_VER_LOADED=true

    load_nv_smi
    local v=""
    if [[ -n "$NVIDIA_SMI_CACHE" ]]; then
        v=$(echo "$NVIDIA_SMI_CACHE" \
            | grep -oE 'NVIDIA-SMI[[:space:]]+[0-9]+\.[0-9]+(\.[0-9]+)?' \
            | head -1 | awk '{print $2}')
    fi
    NV_SMI_VER_CACHE="${v:-N/A}"
    echo "$NV_SMI_VER_CACHE"
}

# ---------------------------------------------------------------------------
# AMD 数据加载
# ---------------------------------------------------------------------------

load_amd_data() {
    [[ "$AMD_LOADED" == "true" ]] && return 0
    AMD_LOADED=true

    if have_cmd amd-smi; then
        log_debug "使用 amd-smi 加载 AMD GPU 信息（合并模式）"
        if _parse_amd_smi; then
            log_debug "amd-smi 解析成功，共 ${#AMD_BDFS[@]} 个 GPU"
            return 0
        fi
        log_warn "amd-smi 解析失败，尝试 rocm-smi"
    fi

    if have_cmd rocm-smi && [[ "$MOCK_MODE" != "true" ]]; then
        log_debug "使用 rocm-smi 加载 AMD GPU 信息"
        if _parse_rocm_smi; then
            log_debug "rocm-smi 解析成功，共 ${#AMD_BDFS[@]} 个 GPU"
            return 0
        fi
        log_warn "rocm-smi 解析失败"
    fi

    log_warn "未找到可用的 amd-smi / rocm-smi"
    return 1
}

_parse_amd_smi() {
    # ① list：BDF → UUID
    local list_raw
    list_raw=$(run_cmd amd-smi.list -- amd-smi list)
    [[ -z "$list_raw" ]] && return 1

    declare -A bdf_to_uuid=()
    local cur_bdf=""
    while IFS= read -r line; do
        if [[ "$line" =~ ^GPU:[[:space:]]*([0-9]+)$ ]]; then
            cur_bdf=""
        elif [[ "$line" =~ BDF:[[:space:]]*([0-9a-fA-F:.]+) ]]; then
            cur_bdf=$(normalize_pci_addr "${BASH_REMATCH[1]}")
        elif [[ -n "$cur_bdf" && "$line" =~ UUID:[[:space:]]*([0-9a-fA-F-]+) ]]; then
            bdf_to_uuid["$cur_bdf"]="${BASH_REMATCH[1]}"
        fi
    done <<< "$list_raw"

    # ② static
    local static_raw
    static_raw=$(run_cmd amd-smi.static -- amd-smi static)
    [[ -z "$static_raw" ]] && return 1

    _amd_split_gpu_sections_into "$static_raw"
    declare -A static_sec=()
    local k
    for k in "${!_AMD_SECTIONS[@]}"; do
        static_sec["$k"]="${_AMD_SECTIONS[$k]}"
    done
    [[ ${#static_sec[@]} -eq 0 ]] && return 1

    # ③ metric
    local metric_raw
    metric_raw=$(run_cmd amd-smi.metric -- amd-smi metric)

    declare -A metric_sec=()
    if [[ -n "$metric_raw" ]]; then
        _amd_split_gpu_sections_into "$metric_raw"
        for k in "${!_AMD_SECTIONS[@]}"; do
            metric_sec["$k"]="${_AMD_SECTIONS[$k]}"
        done
    fi
    _AMD_SECTIONS=()

    # ④ 逐 GPU 提取
    local idx
    for idx in "${!static_sec[@]}"; do
        local s_raw="${static_sec[$idx]}"
        [[ "$s_raw" != *"MARKET_NAME:"* ]] && continue
        local m_raw="${metric_sec[$idx]:-}"

        local bdf market_name asic_serial vbios driver_ver
        local product_serial product_name power_cap mem_total

        bdf=$(_amd_kv "$s_raw" "BDF"); bdf=$(normalize_pci_addr "$bdf")
        market_name=$(_amd_kv "$s_raw" "MARKET_NAME")
        asic_serial=$(_amd_kv "$s_raw" "ASIC_SERIAL")
        vbios=$(_amd_kv_nth "$s_raw" "VERSION" 1); vbios=$(echo "$vbios" | tr -d '[:space:]')
        driver_ver=$(_amd_kv_nth "$s_raw" "VERSION" 2); driver_ver=$(echo "$driver_ver" | tr -d '[:space:]')
        product_serial=$(_amd_kv "$s_raw" "PRODUCT_SERIAL")
        product_name=$(_amd_kv "$s_raw" "PRODUCT_NAME")
        power_cap=$(_amd_kv "$s_raw" "MAX_POWER_LIMIT" | grep -oE '^[0-9]+')
        mem_total=$(_amd_kv "$s_raw" "SIZE" | grep -oE '^[0-9]+')

        [[ -z "$bdf" ]] && continue

        # 温度 / 风扇
        local temp="" fan=""
        if [[ -n "$m_raw" ]]; then
            temp=$(echo "$m_raw" | awk -F':[[:space:]]*' '
                /^[[:space:]]*EDGE:/    {gsub(/[^0-9].*/,"",$2); print $2; exit}
                /^[[:space:]]*HOTSPOT:/ {gsub(/[^0-9].*/,"",$2); print $2; exit}
            ')
            fan=$(echo "$m_raw" | awk '
                /^[[:space:]]*FAN:/          {in_fan=1; next}
                /^[[:space:]]*[A-Z_]+:/      {in_fan=0}
                in_fan && /^[[:space:]]*SPEED:/ {
                    sub(/^[[:space:]]*SPEED:[[:space:]]*/, "")
                    sub(/[^0-9].*$/, "")
                    print; exit
                }
            ')
        fi

        # 最大频率
        local sm_clk="" mem_clk=""
        if [[ -n "$s_raw" ]]; then
            sm_clk=$(_amd_clock_max_freq "$s_raw" "GFX")
            [[ -z "$sm_clk" ]] && sm_clk=$(_amd_clock_max_freq "$s_raw" "SYS")
            mem_clk=$(_amd_clock_max_freq "$s_raw" "MEM")
        fi

        AMD_BDFS+=("$bdf")
        AMD_GPU_NAME["$bdf"]="$market_name"
        AMD_GPU_UUID["$bdf"]="${bdf_to_uuid[$bdf]:-N/A}"
        AMD_GPU_HIP_ID["$bdf"]="$idx"
        AMD_GPU_SERIAL["$bdf"]="${product_serial:-$asic_serial}"
        AMD_GPU_VBIOS["$bdf"]="$vbios"
        AMD_GPU_DRIVER_VER["$bdf"]="$driver_ver"
        AMD_GPU_PRODUCT_NAME["$bdf"]="$product_name"
        AMD_GPU_MEM_TOTAL["$bdf"]="$mem_total"
        AMD_GPU_POWER_CAP["$bdf"]="$power_cap"
        AMD_GPU_TEMP["$bdf"]="$temp"
        AMD_GPU_FAN["$bdf"]="$fan"
        AMD_GPU_SM_CLK["$bdf"]="$sm_clk"
        AMD_GPU_MEM_CLK["$bdf"]="$mem_clk"

        # ECC
        if [[ -n "$m_raw" ]]; then
            local ce ue df
            ce=$(_amd_kv "$m_raw" "TOTAL_CORRECTABLE_COUNT"   | grep -oE '^[0-9]+')
            ue=$(_amd_kv "$m_raw" "TOTAL_UNCORRECTABLE_COUNT" | grep -oE '^[0-9]+')
            df=$(_amd_kv "$m_raw" "TOTAL_DEFERRED_COUNT"      | grep -oE '^[0-9]+')
            [[ -n "$ce" ]] && { AMD_GPU_ECC_CE["$bdf"]="$ce"; AMD_GPU_ECC_HAS["$bdf"]="true"; }
            [[ -n "$ue" ]] && AMD_GPU_ECC_UE["$bdf"]="$ue"
            [[ -n "$df" ]] && AMD_GPU_ECC_DF["$bdf"]="$df"
        fi

        log_debug "AMD GPU[$idx] $bdf: name=$market_name vbios=$vbios driver=$driver_ver mem=${mem_total}MB pwrCap=${power_cap}W temp=${temp}°C fan=${fan}% maxSM=${sm_clk}MHz maxMEM=${mem_clk}MHz"
    done

    [[ ${#AMD_BDFS[@]} -gt 0 ]]
}

_parse_rocm_smi() {
    local bus_raw
    bus_raw=$(rocm-smi --showbus 2>/dev/null || true)
    [[ -z "$bus_raw" ]] && return 1

    declare -A idx_to_bdf=()
    local line idx bdf
    while IFS= read -r line; do
        if [[ "$line" =~ GPU\[([0-9]+)\] ]] && [[ "$line" =~ ([0-9a-fA-F]{4}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}\.[0-9a-fA-F]) ]]; then
            idx="${BASH_REMATCH[1]}"
            bdf=$(normalize_pci_addr "${BASH_REMATCH[2]}")
            idx_to_bdf["$idx"]="$bdf"
        fi
    done <<< "$bus_raw"
    [[ ${#idx_to_bdf[@]} -eq 0 ]] && return 1

    local raw
    raw=$(rocm-smi 2>/dev/null || true)
    [[ -z "$raw" ]] && return 1

    while IFS= read -r line; do
        [[ ! "$line" =~ ^([0-9]+)[[:space:]]+([0-9]+)[[:space:]]+0x ]] && continue
        local dev="${BASH_REMATCH[1]}"
        local dev_bdf="${idx_to_bdf[$dev]}"
        [[ -z "$dev_bdf" ]] && continue

        local temp fan pwrcap guid sclk mclk
        temp=$(echo "$line" | grep -oE '[0-9]+\.[0-9]+°C' | head -1 | grep -oE '^[0-9]+')
        fan=$(echo "$line" | grep -oE '[0-9]+%[[:space:]]+auto' | head -1 | grep -oE '^[0-9]+')
        pwrcap=$(echo "$line" | grep -oE 'auto[[:space:]]+[0-9]+\.[0-9]+W' | head -1 | grep -oE '[0-9]+\.[0-9]+' | cut -d. -f1)
        guid=$(echo "$line" | awk -F'[[:space:]][[:space:]]+' '{print $3}' | awk -F',' '{gsub(/[^0-9]/,"",$2); print $2}')
        sclk=$(echo "$line" | grep -oE '[0-9]+Mhz' | head -1 | grep -oE '^[0-9]+')
        mclk=$(echo "$line" | grep -oE '[0-9]+Mhz' | sed -n '2p' | grep -oE '^[0-9]+')

        AMD_BDFS+=("$dev_bdf")
        AMD_GPU_HIP_ID["$dev_bdf"]="$dev"
        [[ -n "$temp"   ]] && AMD_GPU_TEMP["$dev_bdf"]="$temp"
        [[ -n "$fan"    ]] && AMD_GPU_FAN["$dev_bdf"]="$fan"
        [[ -n "$pwrcap" ]] && AMD_GPU_POWER_CAP["$dev_bdf"]="$pwrcap"
        [[ -n "$guid"   ]] && AMD_GPU_UUID["$dev_bdf"]="$guid"
        [[ -n "$sclk"   ]] && AMD_GPU_SM_CLK["$dev_bdf"]="$sclk"
        [[ -n "$mclk"   ]] && AMD_GPU_MEM_CLK["$dev_bdf"]="$mclk"
    done <<< "$raw"

    local mem_raw
    mem_raw=$(rocm-smi --showmeminfo vram 2>/dev/null || true)
    while IFS= read -r line; do
        if [[ "$line" =~ GPU\[([0-9]+)\] ]] && [[ "$line" =~ Total\ Memory.*:[[:space:]]*([0-9]+) ]]; then
            local g_idx="${BASH_REMATCH[1]}"
            local bytes="${BASH_REMATCH[2]}"
            local g_bdf="${idx_to_bdf[$g_idx]}"
            [[ -n "$g_bdf" ]] && AMD_GPU_MEM_TOTAL["$g_bdf"]=$((bytes / 1024 / 1024))
        fi
    done <<< "$mem_raw"

    local vbios_raw
    vbios_raw=$(rocm-smi --showvbios 2>/dev/null || true)
    while IFS= read -r line; do
        if [[ "$line" =~ VBIOS.*:[[:space:]]*(.+)$ ]]; then
            local v="${BASH_REMATCH[1]}"
            v=$(echo "$v" | sed 's/[[:space:]]*$//')
            [[ -n "$v" ]] && {
                local b
                for b in "${AMD_BDFS[@]}"; do
                    [[ -z "${AMD_GPU_VBIOS[$b]:-}" ]] && AMD_GPU_VBIOS["$b"]="$v"
                done
            }
            break
        fi
    done <<< "$vbios_raw"

    local dv=""
    dv=$(run_cmd sysfs.amdgpu.version -- cat /sys/module/amdgpu/version | tr -d '[:space:]')
    if [[ -n "$dv" ]]; then
        local b
        for b in "${AMD_BDFS[@]}"; do
            [[ -z "${AMD_GPU_DRIVER_VER[$b]:-}" ]] && AMD_GPU_DRIVER_VER["$b"]="$dv"
        done
    fi

    [[ ${#AMD_BDFS[@]} -gt 0 ]]
}

# ---------------------------------------------------------------------------
# AMD XGMI 拓扑
# ---------------------------------------------------------------------------

load_amd_topo() {
    [[ "$AMD_TOPO_LOADED" == "true" ]] && return 0
    AMD_TOPO_LOADED=true

    have_cmd amd-smi || return 0

    local raw
    raw=$(run_cmd amd-smi.topology -- amd-smi topology)
    [[ -z "$raw" ]] && return 0

    local in_link_table=false
    local line
    while IFS= read -r line; do
        line="${line%$'\r'}"

        if [[ "$line" =~ ^LINK[[:space:]]+TYPE[[:space:]]+TABLE: ]]; then
            in_link_table=true; continue
        fi

        if $in_link_table; then
            if [[ -z "$line" ]] || [[ "$line" =~ ^[A-Z][A-Z\ -]+TABLE: ]]; then
                break
            fi

            local -a tk=()
            read -ra tk <<< "$line"
            [[ ${#tk[@]} -lt 2 ]] && continue

            if [[ "${tk[1]}" =~ ^[0-9a-fA-F]{4}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}\.[0-9a-fA-F]$ ]]; then
                continue
            fi

            local row_bdf
            row_bdf=$(normalize_pci_addr "${tk[0]}")
            [[ -z "$row_bdf" ]] && continue

            local -a vals=("${tk[@]:1}")
            local -a uniq=()
            local v seen u
            for v in "${vals[@]}"; do
                [[ "$v" == "SELF" ]] && continue
                [[ -z "$v" ]] && continue
                seen=false
                for u in "${uniq[@]}"; do
                    [[ "$u" == "$v" ]] && { seen=true; break; }
                done
                [[ "$seen" == "false" ]] && uniq+=("$v")
            done

            local parts
            if [[ ${#uniq[@]} -eq 0 ]]; then
                parts="N/A"
            else
                parts=$(printf '%s\n' "${uniq[@]}" | LC_ALL=C sort | paste -sd '/' -)
            fi
            AMD_TOPO_CACHE["$row_bdf"]="$parts"
        fi
    done <<< "$raw"
}

get_amd_nvlink() {
    local bdf="$1"
    load_amd_topo
    if [[ -n "${AMD_TOPO_CACHE[$bdf]+x}" ]]; then
        echo "${AMD_TOPO_CACHE[$bdf]}"
    else
        echo "N/A"
    fi
}

# ---------------------------------------------------------------------------
# 系统序列号
# ---------------------------------------------------------------------------

get_serial_from_dmidecode() {
    have_cmd dmidecode || return 1
    local s
    s=$(run_cmd dmidecode.serial -- sudo dmidecode -s system-serial-number | head -1)
    s=$(echo "$s" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    [[ -z "$s" ]] && return 1
    case "$s" in "Not Specified"|"Unknown"|"None"|"N/A"|"[N/A]") return 1 ;; esac
    echo "$s"; return 0
}

get_serial_from_sysfs() {
    local s
    s=$(run_cmd sysfs.product_serial -- cat /sys/class/dmi/id/product_serial | head -1 | tr -d '\n')
    [[ -z "$s" ]] && return 1
    case "$s" in "Not Specified"|"Unknown"|"None") return 1 ;; esac
    echo "$s"; return 0
}

get_serial_from_hostid() {
    local s; s=$(run_cmd hostid -- hostid)
    [[ -n "$s" && "$s" != "00000000" ]] && { echo "$s"; return 0; }
    return 1
}

get_system_serial() {
    local serial
    for m in get_serial_from_dmidecode get_serial_from_sysfs get_serial_from_hostid; do
        if serial=$($m 2>/dev/null) && [[ -n "$serial" ]]; then
            log_info "序列号来源=${m#get_serial_from_}: $serial"
            echo "$serial"; return 0
        fi
    done
    log_warn "无法获取系统序列号，使用 UNKNOWN"
    echo "UNKNOWN"; return 1
}

# ---------------------------------------------------------------------------
# GPU Vendor / Model 映射
# ---------------------------------------------------------------------------

declare -A GPU_VENDOR_MAP=()
init_gpu_vendor_map() {
    GPU_VENDOR_MAP["10de"]="NVIDIA"
    GPU_VENDOR_MAP["1002"]="AMD"
    GPU_VENDOR_MAP["8086"]="Intel"
    GPU_VENDOR_MAP["1ed5"]="Moore Threads"
}

declare -A GPU_MODEL_MAP=()
init_gpu_model_map() {
    GPU_MODEL_MAP["B200"]="B200"; GPU_MODEL_MAP["B300"]="B300"
    GPU_MODEL_MAP["H200"]="H200"; GPU_MODEL_MAP["H20"]="H20"
    GPU_MODEL_MAP["H800"]="H800"; GPU_MODEL_MAP["A800"]="A800"
    GPU_MODEL_MAP["A100"]="A100"; GPU_MODEL_MAP["A30"]="A30"
    GPU_MODEL_MAP["A40"]="A40";   GPU_MODEL_MAP["A16"]="A16"
    GPU_MODEL_MAP["A10"]="A10";   GPU_MODEL_MAP["A2"]="A2"
    GPU_MODEL_MAP["V100S"]="V100S"; GPU_MODEL_MAP["V100"]="V100"
    GPU_MODEL_MAP["T1000"]="T1000"; GPU_MODEL_MAP["T4"]="T4"
    GPU_MODEL_MAP["RTX A6000"]="RTX A6000"
    GPU_MODEL_MAP["RTX A5000"]="RTX A5000"
    GPU_MODEL_MAP["RTX A4000"]="RTX A4000"
    GPU_MODEL_MAP["L40S"]="L40S"; GPU_MODEL_MAP["L40"]="L40"
    GPU_MODEL_MAP["L20"]="L20";   GPU_MODEL_MAP["L4"]="L4"; GPU_MODEL_MAP["L2"]="L2"
    # 摩尔线程
    GPU_MODEL_MAP["S5000"]="MTT S5000"
    GPU_MODEL_MAP["S4000"]="MTT S4000"
    GPU_MODEL_MAP["S3000"]="MTT S3000"
    GPU_MODEL_MAP["S80"]="MTT S80"
}

# ---------------------------------------------------------------------------
# 软件栈版本（NVIDIA）
# ---------------------------------------------------------------------------

get_software_stack_ver_nv() {
    load_nv_smi
    if [[ -n "$NVIDIA_SMI_CACHE" ]]; then
        local v
        v=$(echo "$NVIDIA_SMI_CACHE" | grep "CUDA Version:" | head -1 | sed 's/.*CUDA Version:[[:space:]]*//' | awk '{print $1}')
        if [[ -n "$v" && "$v" != "N/A" && "$v" != "|" ]]; then
            echo "cuda $v"; return
        fi
    fi
    echo "N/A"
}

# ---------------------------------------------------------------------------
# NVIDIA GPU 字段
# ---------------------------------------------------------------------------

get_gpu_count() { load_nv_rows; echo "${#NV_ROWS[@]}"; }

get_gpu_index()   { q_named "$1" "index"; }
get_gpu_uuid()    { local v; v=$(q_named "$1" "uuid"); is_na "$v" && echo "N/A" || echo "$v"; }
get_gpu_serial_nv() { local v; v=$(q_named "$1" "serial"); is_na "$v" && echo "" || echo "$v"; }
get_gpu_vbios_nv()  { local v; v=$(q_named "$1" "vbios_version"); is_na "$v" && echo "" || echo "$v"; }
get_gpu_driver_ver_nv() { local v; v=$(q_named "$1" "driver_version"); is_na "$v" && echo "N/A" || echo "$v"; }

get_gpu_temperature() {
    local v; v=$(q_named "$1" "temperature.gpu")
    is_na "$v" && { echo "N/A"; return; }
    v=$(echo "$v" | sed 's/[^0-9]//g')
    [[ -n "$v" ]] && echo "$v" || echo "N/A"
}

get_gpu_fan_speed() {
    local v; v=$(q_named "$1" "fan.speed")
    is_na "$v" && { echo "N/A"; return; }
    v=$(echo "$v" | sed 's/[^0-9]//g')
    [[ -n "$v" ]] && echo "$v" || echo "N/A"
}

get_gpu_memory_mib() {
    local v; v=$(q_named "$1" "memory.total")
    if ! is_na "$v"; then
        local n
        n=$(echo "$v" | awk '{print $1}' | sed 's/[^0-9]//g')
        if [[ "$n" =~ ^[0-9]+$ ]] && [[ "$n" -gt 0 ]]; then echo "$n"; return; fi
    fi
    echo "0"
}

get_gpu_power_cap() {
    local v; v=$(q_named "$1" "power.limit")
    if ! is_na "$v"; then
        local n
        n=$(echo "$v" | awk '{print $1}' | sed 's/[^0-9.]//g')
        [[ -n "$n" ]] && { echo "$(echo "$n" | awk '{print int($1)}')"; return; }
    fi
    echo "N/A"
}

get_gpu_power_draw_nv() {
    local v; v=$(q_named "$1" "power.draw")
    is_na "$v" && { echo "N/A"; return; }
    v=$(echo "$v" | sed 's/[^0-9.]//g')
    [[ -n "$v" ]] && echo "$(echo "$v" | awk '{printf "%d", $1}')" || echo "N/A"
}

get_gpu_memory_used_nv() {
    local v; v=$(q_named "$1" "memory.used")
    is_na "$v" && { echo "N/A"; return; }
    v=$(echo "$v" | awk '{print $1}' | sed 's/[^0-9]//g')
    [[ -n "$v" ]] && echo "$v" || echo "N/A"
}

get_gpu_utilization_nv() {
    local v; v=$(q_named "$1" "utilization.gpu")
    is_na "$v" && { echo "N/A"; return; }
    v=$(echo "$v" | sed 's/[^0-9]//g')
    [[ -n "$v" ]] && echo "$v" || echo "N/A"
}

get_gpu_pcie_bus_id() {
    local raw; raw=$(q_named "$1" "pci.bus_id")
    if [[ -n "$raw" ]] && ! is_na "$raw"; then normalize_pci_addr "$raw"; return; fi
    local fallback; fallback=$(get_gpu_pci_address "$1")
    [[ -n "$fallback" ]] && echo "$fallback" || echo "N/A"
}

get_gpu_pci_address() {
    local raw; raw=$(q_named "$1" "pci.bus_id")
    if [[ -n "$raw" ]] && ! is_na "$raw"; then normalize_pci_addr "$raw"; return; fi
    echo ""
}

get_gpu_sm_clk_max_nv() {
    local v; v=$(q_named "$1" "clocks.max.sm")
    is_na "$v" && { echo "N/A"; return; }
    v=$(echo "$v" | sed 's/[^0-9]//g')
    [[ -n "$v" ]] && echo "$v" || echo "N/A"
}

get_gpu_mem_clk_max_nv() {
    local v; v=$(q_named "$1" "clocks.max.mem")
    is_na "$v" && { echo "N/A"; return; }
    v=$(echo "$v" | sed 's/[^0-9]//g')
    [[ -n "$v" ]] && echo "$v" || echo "N/A"
}

# ---------------------------------------------------------------------------
# NVIDIA ECC
# ---------------------------------------------------------------------------

get_gpu_ecc_errors() {
    local gpu_idx="$1"
    local pci_addr; pci_addr=$(get_gpu_pci_address "$gpu_idx")
    local pci_key=""
    [[ -n "$pci_addr" ]] && pci_key=$(normalize_pci_addr "$pci_addr")

    local parts=()
    local ecc_mode; ecc_mode=$(q_named "$gpu_idx" "ecc.mode.current")

    if [[ "$ecc_mode" == "Enabled" ]]; then
        local sb db as ad
        sb=$(q_named "$gpu_idx" "ecc.errors.corrected.volatile.total");   [[ ! "$sb" =~ ^[0-9]+$ ]] && sb=0
        db=$(q_named "$gpu_idx" "ecc.errors.uncorrected.volatile.total"); [[ ! "$db" =~ ^[0-9]+$ ]] && db=0
        as=$(q_named "$gpu_idx" "ecc.errors.corrected.aggregate.total");  [[ ! "$as" =~ ^[0-9]+$ ]] && as=0
        ad=$(q_named "$gpu_idx" "ecc.errors.uncorrected.aggregate.total");[[ ! "$ad" =~ ^[0-9]+$ ]] && ad=0

        local total=$((sb + db + as + ad))
        if [[ $total -gt 0 ]]; then
            parts+=("single_bit:${sb}")
            parts+=("double_bit:${db}")
            parts+=("agg_single:${as}")
            parts+=("agg_double:${ad}")
            parts+=("total:${total}")
        fi

        load_retired_pages
        if [[ -n "$pci_key" && -n "${RETIRED_PAGES_CACHE[$pci_key]+x}" ]]; then
            local line="${RETIRED_PAGES_CACHE[$pci_key]}"
            local cause ts
            cause=$(echo "$line" | awk -F',' '{gsub(/^[ \t]+|[ \t]+$/,"",$3); print $3}')
            ts=$(echo "$line"    | awk -F',' '{gsub(/^[ \t]+|[ \t]+$/,"",$4); print $4}')
            if ! is_na "$cause" && [[ -n "$cause" ]] && \
               ! is_na "$ts" && [[ -n "$ts" && "$ts" != "[N/A]" ]]; then
                parts+=("retired_pages_cause:${cause}")
                parts+=("retired_pages_time:${ts}")
            fi
        fi

        load_remapped_rows
        if [[ -n "$pci_key" && -n "${REMAPPED_ROWS_CACHE[$pci_key]+x}" ]]; then
            local line="${REMAPPED_ROWS_CACHE[$pci_key]}"
            local rc ru rp rf
            rc=$(echo "$line" | awk -F',' '{gsub(/^[ \t]+|[ \t]+$/,"",$3); print $3}')
            ru=$(echo "$line" | awk -F',' '{gsub(/^[ \t]+|[ \t]+$/,"",$4); print $4}')
            rp=$(echo "$line" | awk -F',' '{gsub(/^[ \t]+|[ \t]+$/,"",$5); print $5}')
            rf=$(echo "$line" | awk -F',' '{gsub(/^[ \t]+|[ \t]+$/,"",$6); print $6}')
            local has_rr=false
            [[ "$rc" =~ ^[0-9]+$ && "$rc" -gt 0 ]] && has_rr=true
            [[ "$ru" =~ ^[0-9]+$ && "$ru" -gt 0 ]] && has_rr=true
            [[ "$rf" == "Yes" ]] && has_rr=true
            if [[ "$has_rr" == "true" ]]; then
                parts+=("remap_correctable:${rc}")
                parts+=("remap_uncorrectable:${ru}")
                parts+=("remap_pending:${rp}")
                parts+=("remap_failure:${rf}")
            fi
        fi
    fi

    if [[ ${#parts[@]} -eq 0 ]]; then
        echo "0"
    else
        local IFS=','
        echo "${parts[*]}"
    fi
}

get_gpu_ecc_mode_nv() {
    local v; v=$(q_named "$1" "ecc.mode.current")
    is_na "$v" && { echo "N/A"; return; }
    [[ -n "$v" ]] && echo "$v" || echo "N/A"
}

# ---------------------------------------------------------------------------
# lspci 派生字段
# ---------------------------------------------------------------------------

get_gpu_vendor() {
    local pci_addr="$1"
    local vid; vid=$(_get_pcie_vid_sysfs "$pci_addr")
    if [[ -n "$vid" ]] && [[ -n "${GPU_VENDOR_MAP[$vid]}" ]]; then
        echo "${GPU_VENDOR_MAP[$vid]}"; return
    fi
    local info; info=$(_get_lspci_vv "$pci_addr")
    [[ "$info" =~ NVIDIA ]] && { echo "NVIDIA"; return; }
    [[ "$info" =~ Advanced\ Micro\ Devices ]] && { echo "AMD"; return; }
    echo "UNKNOWN"
}

get_gpu_model() {
    local gpu_idx="$1"
    local full_name; full_name=$(q_named "$gpu_idx" "name")
    if [[ -n "$full_name" ]]; then
        local k
        for k in "${!GPU_MODEL_MAP[@]}"; do
            if [[ "$full_name" == *"$k"* ]]; then
                echo "${GPU_MODEL_MAP[$k]}"; return
            fi
        done
        echo "$full_name"; return
    fi
    echo "UNKNOWN"
}

get_gpu_product() {
    local pci_addr="$1"
    [[ -z "$pci_addr" ]] && { echo "N/A"; return; }
    local info; info=$(_get_lspci_vv "$pci_addr")
    local line; line=$(echo "$info" | grep -i "^[[:space:]]*Subsystem:" | head -1)
    if [[ -n "$line" ]]; then
        line=$(echo "$line" | sed 's/^[[:space:]]*Subsystem:[[:space:]]*//' | sed 's/[[:space:]]*$//')
        [[ -n "$line" ]] && { echo "$line"; return; }
    fi
    echo "N/A"
}

get_gpu_serial() {
    local gpu_idx="$1"
    local s; s=$(get_gpu_serial_nv "$gpu_idx")
    [[ -n "$s" ]] && { echo "$s"; return; }
    local pci_addr; pci_addr=$(get_gpu_pci_address "$gpu_idx")
    if [[ -n "$pci_addr" ]]; then
        local info; info=$(_get_lspci_vv "$pci_addr")
        s=$(echo "$info" | grep -i "\[SN\]" | head -1 | sed 's/.*\[SN\]//' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
        [[ -n "$s" ]] && { echo "$s"; return; }
    fi
    echo "N/A"
}

get_gpu_vbios_full() {
    local gpu_idx="$1"
    local f; f=$(get_gpu_vbios_nv "$gpu_idx")
    [[ -n "$f" ]] && { echo "$f"; return; }
    local pci_addr; pci_addr=$(get_gpu_pci_address "$gpu_idx")
    if [[ -n "$pci_addr" ]]; then
        local info; info=$(_get_lspci_vv "$pci_addr")
        f=$(echo "$info" | grep -i "\[FW\]" | head -1 | sed 's/.*\[FW\]//' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
        [[ -n "$f" ]] && { echo "$f"; return; }
    fi
    echo "N/A"
}

get_gpu_pcie_vendor_id() {
    local pci_addr="$1"
    local vid; vid=$(_get_pcie_vid_sysfs "$pci_addr")
    [[ -n "$vid" ]] && echo "$vid" || echo "N/A"
}

get_gpu_pcie_product_id() {
    local pci_addr="$1"
    local pid; pid=$(_get_pcie_pid_sysfs "$pci_addr")
    [[ -n "$pid" ]] && echo "$pid" || echo "N/A"
}

# ---------------------------------------------------------------------------
# pcie_gen / link_cap / link_sta
# ---------------------------------------------------------------------------

gtps_to_pcie_ver() {
    case "$1" in
        "2.5GT/s") echo "PCIe 1.0" ;;
        "5GT/s")   echo "PCIe 2.0" ;;
        "8GT/s")   echo "PCIe 3.0" ;;
        "16GT/s")  echo "PCIe 4.0" ;;
        "32GT/s")  echo "PCIe 5.0" ;;
        "64GT/s")  echo "PCIe 6.0" ;;
        *)         echo "" ;;
    esac
}

get_gpu_pcie_gen() {
    local pci_addr="$1"
    [[ -z "$pci_addr" ]] && { echo "N/A"; return; }
    local info; info=$(_get_lspci_vv "$pci_addr")
    [[ -z "$info" ]] && { echo "N/A"; return; }
    local cap_line sta_line
    cap_line=$(echo "$info" | grep -E "LnkCap:" | head -1)
    sta_line=$(echo "$info" | grep -E "LnkSta:" | head -1)
    local speed
    speed=$(echo "$cap_line" | grep -oE 'Speed [0-9.]+GT/s' | head -1 | sed 's/Speed //')
    [[ -z "$speed" ]] && speed=$(echo "$sta_line" | grep -oE 'Speed [0-9.]+GT/s' | head -1 | sed 's/Speed //')
    [[ -z "$speed" ]] && { echo "N/A"; return; }
    local ver
    ver=$(gtps_to_pcie_ver "$speed")
    [[ -z "$ver" ]] && { echo "N/A"; return; }
    echo "$ver"
}

get_gpu_pcie_link_cap() {
    local pci_addr="$1"
    [[ -z "$pci_addr" ]] && { echo "N/A"; return; }
    local info; info=$(_get_lspci_vv "$pci_addr")
    [[ -z "$info" ]] && { echo "N/A"; return; }
    local cap_line
    cap_line=$(echo "$info" | grep -E "LnkCap:" | head -1)
    [[ -z "$cap_line" ]] && { echo "N/A"; return; }
    local speed width
    speed=$(echo "$cap_line" | grep -oE 'Speed [0-9.]+GT/s' | head -1 | sed 's/Speed //')
    width=$(echo "$cap_line" | grep -oE 'Width x[0-9]+' | head -1 | sed 's/Width //')
    if [[ -n "$speed" ]] && [[ -n "$width" ]]; then echo "${speed} ${width}"
    elif [[ -n "$speed" ]]; then echo "$speed"
    elif [[ -n "$width" ]]; then echo "$width"
    else echo "N/A"; fi
}

get_gpu_pcie_link_sta() {
    local pci_addr="$1"
    [[ -z "$pci_addr" ]] && { echo "N/A"; return; }
    local info; info=$(_get_lspci_vv "$pci_addr")
    [[ -z "$info" ]] && { echo "N/A"; return; }
    local sta_line
    sta_line=$(echo "$info" | grep -E "LnkSta:" | head -1)
    [[ -z "$sta_line" ]] && { echo "N/A"; return; }
    local sta_speed sta_speed_state
    sta_speed=$(echo "$sta_line" | grep -oE 'Speed [0-9.]+GT/s' | head -1 | sed 's/Speed //')
    sta_speed_state=$(echo "$sta_line" | grep -oE 'Speed [0-9.]+GT/s \([^)]*\)' | head -1 \
                      | grep -oE '\([^)]*\)' | tr -d '()')
    [[ -z "$sta_speed_state" ]] && sta_speed_state="ok"
    local sta_width sta_width_state
    sta_width=$(echo "$sta_line" | grep -oE 'Width x[0-9]+' | head -1 | sed 's/Width x//')
    sta_width_state=$(echo "$sta_line" | grep -oE 'Width x[0-9]+ \([^)]*\)' | head -1 \
                      | grep -oE '\([^)]*\)' | tr -d '()')
    [[ -z "$sta_width_state" ]] && sta_width_state="ok"
    local sp_str="" wd_str=""
    [[ -n "$sta_speed" ]] && sp_str="${sta_speed} (${sta_speed_state})"
    [[ -n "$sta_width" ]] && wd_str="x${sta_width} (${sta_width_state})"
    if [[ -n "$sp_str" ]] && [[ -n "$wd_str" ]]; then echo "${sp_str} ${wd_str}"
    elif [[ -n "$sp_str" ]]; then echo "$sp_str"
    elif [[ -n "$wd_str" ]]; then echo "$wd_str"
    else echo "N/A"; fi
}

# ---------------------------------------------------------------------------
# AMD 辅助字段
# ---------------------------------------------------------------------------

get_amd_name_from_lspci() {
    local bdf="$1"
    local info; info=$(_get_lspci_vv "$bdf")
    local line; line=$(echo "$info" | head -1)
    local name
    name=$(echo "$line" | sed 's/^[0-9a-fA-F:.]*[[:space:]]*//')
    name=$(echo "$name" | sed 's/^[^:]*:[[:space:]]*//')
    name=$(echo "$name" | sed 's/\[AMD\/ATI\][[:space:]]*//')
    name=$(echo "$name" | sed 's/[[:space:]]*$//')
    if [[ "$name" =~ (AMD[[:space:]]+Instinct[[:space:]]+[A-Za-z0-9]+) ]]; then
        echo "${BASH_REMATCH[1]}"; return
    fi
    echo "$name"
}

get_amd_serial_from_lspci() {
    local bdf="$1"
    local info; info=$(_get_lspci_vv "$bdf")
    local s
    s=$(echo "$info" | grep -i "\[SN\]" | head -1 | sed 's/.*\[SN\]//' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    [[ -n "$s" ]] && echo "$s" || echo "N/A"
}

get_amd_vbios_from_lspci() {
    local bdf="$1"
    local info; info=$(_get_lspci_vv "$bdf")
    local f
    f=$(echo "$info" | grep -i "\[FW\]" | head -1 | sed 's/.*\[FW\]//' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    [[ -n "$f" ]] && echo "$f" || echo "N/A"
}

format_amd_ecc() {
    local bdf="$1"
    if [[ "${AMD_GPU_ECC_HAS[$bdf]:-}" == "true" ]]; then
        local ce="${AMD_GPU_ECC_CE[$bdf]:-0}"
        local ue="${AMD_GPU_ECC_UE[$bdf]:-0}"
        local df="${AMD_GPU_ECC_DF[$bdf]:-0}"
        local total=$((ce + ue + df))
        if [[ $total -eq 0 ]]; then
            echo "0"
        else
            echo "correctable:${ce},uncorrectable:${ue},deferred:${df},total:${total}"
        fi
        return
    fi
    echo "N/A"
}

# ---------------------------------------------------------------------------
# AMD 采集主流程
# ---------------------------------------------------------------------------

collect_amd_info() {
    local serial="$1"
    local output_file="$2"

    log_info "正在收集 AMD GPU 信息..."

    load_amd_data
    load_amd_topo

    if [[ ${#AMD_BDFS[@]} -eq 0 ]]; then
        log_warn "无 amd-smi/rocm-smi 数据，从 sysfs 枚举 AMD 加速器/显示设备"
        local d v cls bdf
        for d in /sys/bus/pci/devices/*/vendor; do
            [[ -r "$d" ]] || continue
            v=$(cat "$d" 2>/dev/null)
            [[ "$v" != "0x1002" ]] && continue
            bdf=$(basename "$(dirname "$d")")
            cls=$(cat "$(dirname "$d")/class" 2>/dev/null || echo "")
            [[ "$cls" =~ ^0x03 || "$cls" =~ ^0x12 ]] || continue
            AMD_BDFS+=("$bdf")
        done
    fi

    local total=${#AMD_BDFS[@]}
    if [[ $total -eq 0 ]]; then
        log_warn "未找到 AMD GPU"
        return 0
    fi
    log_info "检测到 $total 个 AMD GPU 设备"

    local software_stack_val; software_stack_val=$(get_rocm_version)
    local gpu_smi_ver_val;    gpu_smi_ver_val=$(get_amd_smi_version)
    log_info "AMD-SMI 版本: $gpu_smi_ver_val, 软件栈: $software_stack_val"

    local record_count=0
    local bdf
    local fallback_idx=0

    for bdf in "${AMD_BDFS[@]}"; do
        bdf=$(normalize_pci_addr "$bdf")

        local name="${AMD_GPU_NAME[$bdf]:-}"
        [[ -z "$name" ]] && name=$(get_amd_name_from_lspci "$bdf")
        [[ -z "$name" ]] && name="AMD GPU"

        local hip_id="${AMD_GPU_HIP_ID[$bdf]:-$fallback_idx}"
        local temp="${AMD_GPU_TEMP[$bdf]:-N/A}"; [[ -z "$temp" ]] && temp="N/A"
        local fan="${AMD_GPU_FAN[$bdf]:-N/A}";  [[ -z "$fan"  ]] && fan="N/A"
        local mem_total="${AMD_GPU_MEM_TOTAL[$bdf]:-0}"; [[ -z "$mem_total" ]] && mem_total="0"
        local power_cap="${AMD_GPU_POWER_CAP[$bdf]:-N/A}"; [[ -z "$power_cap" ]] && power_cap="N/A"
        local uuid="${AMD_GPU_UUID[$bdf]:-N/A}"; [[ -z "$uuid" ]] && uuid="N/A"
        local asic_serial="${AMD_GPU_SERIAL[$bdf]:-}"
        local vbios="${AMD_GPU_VBIOS[$bdf]:-}"
        local driver_ver="${AMD_GPU_DRIVER_VER[$bdf]:-}"
        local product_name="${AMD_GPU_PRODUCT_NAME[$bdf]:-}"
        local sm_clk="${AMD_GPU_SM_CLK[$bdf]:-N/A}";   [[ -z "$sm_clk"  ]] && sm_clk="N/A"
        local mem_clk="${AMD_GPU_MEM_CLK[$bdf]:-N/A}"; [[ -z "$mem_clk" ]] && mem_clk="N/A"

        local nvlink_val; nvlink_val=$(get_amd_nvlink "$bdf")

        local pcie_slot_val; pcie_slot_val=$(get_pcie_slot "$bdf")
        local pcie_gen_val;  pcie_gen_val=$(get_gpu_pcie_gen "$bdf")
        local pcie_cap_val;  pcie_cap_val=$(get_gpu_pcie_link_cap "$bdf")
        local pcie_sta_val;  pcie_sta_val=$(get_gpu_pcie_link_sta "$bdf")
        local vid; vid=$(_get_pcie_vid_sysfs "$bdf"); [[ -z "$vid" ]] && vid="1002"
        local pid; pid=$(_get_pcie_pid_sysfs "$bdf"); [[ -z "$pid" ]] && pid="N/A"

        local product_val="$product_name"
        [[ -z "$product_val" ]] && product_val=$(get_gpu_product "$bdf")

        local serial_val="$asic_serial"
        [[ -z "$serial_val" ]] && serial_val=$(get_amd_serial_from_lspci "$bdf")

        local vbios_val="$vbios"
        [[ -z "$vbios_val" ]] && vbios_val=$(get_amd_vbios_from_lspci "$bdf")

        local driver_val="$driver_ver"
        if [[ -z "$driver_val" ]]; then
            driver_val=$(run_cmd sysfs.amdgpu.version -- cat /sys/module/amdgpu/version | tr -d '[:space:]')
        fi
        [[ -z "$driver_val" ]] && driver_val="N/A"

        local ecc_val; ecc_val=$(format_amd_ecc "$bdf")

        local f=()
        f+=("$(csv_escape "$serial")")
        f+=("$(csv_escape "$hip_id")")
        f+=("$(csv_escape "$uuid")")
        f+=("$(csv_escape "AMD")")
        f+=("$(csv_escape "$name")")
        f+=("$(csv_escape "$product_val")")
        f+=("$(csv_escape "$serial_val")")
        f+=("$(csv_escape "$mem_total")")
        f+=("$(csv_escape "$vbios_val")")
        f+=("$(csv_escape "$driver_val")")
        f+=("$(csv_escape "$bdf")")
        f+=("$(csv_escape "$pcie_slot_val")")
        f+=("$(csv_escape "$vid")")
        f+=("$(csv_escape "$pid")")
        f+=("$(csv_escape "$pcie_gen_val")")
        f+=("$(csv_escape "$pcie_cap_val")")
        f+=("$(csv_escape "$pcie_sta_val")")
        f+=("$(csv_escape "$nvlink_val")")
        f+=("$(csv_escape "$power_cap")")
        f+=("$(csv_escape "$gpu_smi_ver_val")")
        f+=("$(csv_escape "$software_stack_val")")
        f+=("$(csv_escape "$sm_clk")")
        f+=("$(csv_escape "$mem_clk")")
        f+=("$(csv_escape "$fan")")
        f+=("$(csv_escape "$temp")")
        f+=("$(csv_escape "$ecc_val")")
        f+=("$(csv_escape "N/A")")                       # gpu_power_draw_w
        f+=("$(csv_escape "N/A")")                       # gpu_memory_used_mib
        f+=("$(csv_escape "N/A")")                       # gpu_utilization_percent
        f+=("$(csv_escape "N/A")")                       # gpu_ecc_mode

        local IFS=','
        echo "${f[*]}" >> "$output_file"
        record_count=$((record_count + 1))

        log_info "✅ AMD GPU $hip_id: $name (BDF: $bdf, Mem: ${mem_total}MiB, XGMI: $nvlink_val, MaxSMClk: ${sm_clk}MHz, MaxMemClk: ${mem_clk}MHz, Temp: $temp°C, ECC: $ecc_val)"

        fallback_idx=$((fallback_idx + 1))
    done

    echo "$record_count"
}

# ============================================================================
# 摩尔线程（Moore Threads）采集
#
#   数据来源：
#     - mthreads-gmi            : GPU 列表（名称/BDF/显存/温度/ECC/驱动版本）
#     - mthreads-gmi --query -d POWER : 功耗（Power Draw / Current Power Limit）
#     - lspci -vv / sysfs       : 序列号 / vbios / Subsystem / PCIe 链路能力
#
#   说明：mthreads-gmi 输出存在大量对齐空格，解析一律用「首个冒号」切分，
#         并把 key 两端空白去掉后精确匹配，避免 "Power Limit" 命中多行。
#
#   关键：mthreads-gmi 的 BDF 是 8 位域号（00000000:2a:00.0），统一交给
#         normalize_pci_addr() 归一化为 0000:2a:00.0，与 sysfs / dmidecode 对齐。
# ============================================================================

# 缓存 mthreads-gmi 的原始输出
MTT_GMI_HEADER_CACHE=""
declare -A MTT_GPU_NAME=()             # BDF → 名称（如 MTT S5000）
declare -A MTT_GPU_MEM_USED=()         # BDF → 已用显存 MiB
declare -A MTT_GPU_MEM_TOTAL=()        # BDF → 总显存 MiB
declare -A MTT_GPU_UTIL=()             # BDF → GPU 利用率 (%)
declare -A MTT_GPU_TEMP=()             # BDF → 温度 (°C)
declare -A MTT_GPU_ECC=()              # BDF → ECC 模式（如 "On-die, EDC"）
declare -A MTT_GPU_POWER_CAP=()        # BDF → 当前功耗上限 (W)
declare -A MTT_GPU_POWER_DRAW=()       # BDF → 当前功耗 (W)
declare -A MTT_GPU_SM_CLK=()           # BDF → Graphics 时钟 (MHz)
declare -A MTT_GPU_MEM_CLK=()          # BDF → Memory 时钟 (MHz)
declare -A MTT_GPU_FAN=()              # BDF → 风扇转速 (RPM/%；无则 N/A)
declare -a MTT_GPU_UUIDS=()            # 按枚举顺序的 UUID 列表（与 MTT_BDFS 对齐）
declare -a MTT_BDFS=()                 # 顺序 BDF 列表（索引数组）
MTT_LOADED=false
MTT_DRIVER_VER=""
MTT_GMI_VER=""

load_mtt_gmi() {
    [[ "$MTT_LOADED" == "true" ]] && return 0
    MTT_LOADED=true

    local header
    header=$(run_cmd mthreads-gmi.header -- mthreads-gmi)
    MTT_GMI_HEADER_CACHE="$header"
    if [[ -n "$header" ]]; then
        MTT_GMI_VER=$(echo "$header" | grep -oE 'mthreads-gmi:[[:space:]]*[0-9.]+' \
                      | head -1 | sed 's/.*:[[:space:]]*//')
        MTT_DRIVER_VER=$(echo "$header" | grep -oE 'Driver Version:[[:space:]]*[^[:space:]]+' \
                         | head -1 | sed 's/Driver Version:[[:space:]]*//')
    fi

    # 解析 GPU 列表（含显存/温度/ECC）
    local gpus
    gpus=$(run_cmd mthreads-gmi.gpus -- mthreads-gmi)
    [[ -z "$gpus" ]] && gpus="$header"
    _parse_mtt_gpus "$gpus"

    # 解析功耗 / 频率 / 风扇
    local perf
    perf=$(run_cmd mthreads-gmi.perf -- mthreads-gmi --query -d POWER,CLOCK,FAN)
    [[ -z "$perf" ]] && perf=$(run_cmd mthreads-gmi.power -- mthreads-gmi --query -d POWER)
    _parse_mtt_perf "$perf"

    # 解析 UUID（按枚举顺序与 MTT_BDFS 对齐）
    local lgu
    lgu=$(run_cmd mthreads-gmi.list-gpus -- mthreads-gmi --list-gpus)
    _parse_mtt_uuids "$lgu"

    log_debug "摩尔线程: gmi=${MTT_GMI_VER:-N/A}, driver=${MTT_DRIVER_VER:-N/A}, GPU=${#MTT_BDFS[@]}"
    [[ ${#MTT_BDFS[@]} -gt 0 ]]
}

# 解析 mthreads-gmi 主输出的 GPU 行，例如：
#   0    MTT S5000            |00000000:2a:00.0    |0%    17238MiB(81920MiB)
#        Physical      P0     |16x(16x)            |36C   YES
#                                                  |      On-die, EDC
_parse_mtt_gpus() {
    local raw="$1"
    local cur_bdf="" cur_name=""

    local line
    while IFS= read -r line; do
        line="${line%$'\r'}"
        [[ -z "$line" ]] && continue

        # 进程段开始后不再解析
        [[ "$line" =~ ^Processes: ]] && break
        # 分隔线 / 表头行跳过（表头无数字索引，且不承载 GPU 状态）
        [[ "$line" =~ ^\+?-{3,} ]] && continue

        # 主行：<idx> <name> |<BDF> |<util> <mem>
        if [[ "$line" =~ ^[[:space:]]*[0-9]+[[:space:]] ]]; then
            local row="$line"
            local col1 col2
            col1=$(echo "$row" | awk -F'|' '{print $1}')
            col2=$(echo "$row" | awk -F'|' '{print $2}')
            local bdf name
            bdf=$(echo "$col2" | grep -oE '[0-9a-fA-F]{8}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}\.[0-9a-fA-F]' | head -1)
            [[ -z "$bdf" ]] && { cur_bdf=""; continue; }
            bdf=$(normalize_pci_addr "$bdf")

            name=$(echo "$col1" | sed -E 's/^[[:space:]]*[0-9]+[[:space:]]+//' \
                   | sed 's/[[:space:]]*$//')
            # col1 里名称后面可能还有尾随空白，取第一个非数字字段
            name=$(echo "$name" | sed -E 's/[[:space:]]{2,}.*$//')

            MTT_GPU_NAME["$bdf"]="$name"
            MTT_BDFS+=("$bdf")

            cur_bdf="$bdf"
            cur_name="$name"

            local mem
            mem=$(echo "$row" | grep -oE '[0-9]+MiB\([0-9]+MiB\)' | head -1)
            if [[ -n "$mem" ]]; then
                MTT_GPU_MEM_USED["$bdf"]=$(echo "$mem" | grep -oE '^[0-9]+')
                MTT_GPU_MEM_TOTAL["$bdf"]=$(echo "$mem" | grep -oE '\([0-9]+MiB\)' | grep -oE '[0-9]+')
            fi
            MTT_GPU_UTIL["$bdf"]=$(echo "$row" | awk -F'|' '{print $3}' | grep -oE '^[[:space:]]*[0-9]+%' | grep -oE '[0-9]+')
            continue
        fi

        # 状态行（Physical / Perf 等）：补温度与 ECC，保留 cur_bdf 直到下个 GPU
        if [[ -n "$cur_bdf" ]]; then
            local temp ecc
            temp=$(echo "$line" | grep -oE '[0-9]+C' | head -1 | grep -oE '[0-9]+')
            [[ -n "$temp" ]] && MTT_GPU_TEMP["$cur_bdf"]="$temp"
            if echo "$line" | grep -qiE 'EDC|ECC|On-die'; then
                ecc=$(echo "$line" | sed 's/^[^|]*|//' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
                [[ -n "$ecc" ]] && MTT_GPU_ECC["$cur_bdf"]="$ecc"
            fi
        fi
    done <<< "$raw"
}

# 解析 --query -d POWER,CLOCK,FAN，例如：
#   GPU0 00000000:2a:00.0
#       Power Readings
#           Power Draw                :  927.57W
#           Current Power Limit       :  950.00W
#       Clocks
#           Graphics                  :  1727MHz
#           Memory                    :  2500MHz
#       Fan
#           Channel                   :  0
#
# 注意：不同 key 会重复出现（如 Memory 在 Clocks 段），用段落前缀消歧：
#   "Graphics"  → SM 频率；"Memory" 在 Clocks 段 → 显存频率
_parse_mtt_perf() {
    local raw="$1"
    [[ -z "$raw" ]] && return 0

    local cur_bdf=""
    local section=""        # 当前段落（Power Readings / Clocks / Fan）
    local line
    while IFS= read -r line; do
        line="${line%$'\r'}"
        if [[ "$line" =~ GPU[0-9]+[[:space:]]+([0-9a-fA-F]{8}:[0-9a-fA-F]{2}:[0-9a-fA-F]{2}\.[0-9a-fA-F]) ]]; then
            cur_bdf=$(normalize_pci_addr "${BASH_REMATCH[1]}")
            section=""
            continue
        fi
        [[ -z "$cur_bdf" ]] && continue
        [[ -z "${line//[[:space:]]/}" ]] && continue

        # 段落标题：整行无冒号、缩进较浅
        if [[ "$line" != *:* ]]; then
            section=$(echo "$line" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
            continue
        fi

        # key: value —— 用第一个冒号切分
        local key val
        key=$(echo "$line" | sed 's/:.*$//' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
        val=$(echo "$line" | sed 's/^[^:]*:[[:space:]]*//' | sed 's/[[:space:]]*$//')

        case "$key" in
            "Power Draw")
                MTT_GPU_POWER_DRAW["$cur_bdf"]=$(echo "$val" | grep -oE '^[0-9]+') ;;
            "Current Power Limit")
                MTT_GPU_POWER_CAP["$cur_bdf"]=$(echo "$val" | grep -oE '^[0-9]+') ;;
            "Graphics")
                MTT_GPU_SM_CLK["$cur_bdf"]=$(echo "$val" | grep -oE '^[0-9]+') ;;
            "Memory")
                [[ "$section" == "Clocks" ]] && \
                    MTT_GPU_MEM_CLK["$cur_bdf"]=$(echo "$val" | grep -oE '^[0-9]+') ;;
            "Speed"|"RPM")
                # 若 mthreads-gmi 在 Fan 段给出 Speed/RPM 则采集
                [[ "$section" == "Fan" ]] && \
                    MTT_GPU_FAN["$cur_bdf"]=$(echo "$val" | grep -oE '^[0-9]+') ;;
        esac
    done <<< "$raw"
}

# 解析 `mthreads-gmi --list-gpus` 输出：
#   GPU 0 : MTT S5000  (UUID : 9fbaf120-bace-4321-c6b2-55f0fb51ebae)
#   按 GPU 序号存入 MTT_GPU_UUIDS[]，与 MTT_BDFS 顺序对齐。
_parse_mtt_uuids() {
    local raw="$1"
    [[ -z "$raw" ]] && return 0

    local line
    while IFS= read -r line; do
        line="${line%$'\r'}"
        if [[ "$line" =~ ^GPU[[:space:]]+([0-9]+) ]]; then
            # Do not run another [[ =~ ]] before saving idx: it overwrites BASH_REMATCH.
            local idx="${BASH_REMATCH[1]}"
            local uuid
            uuid=$(echo "$line" | grep -oE 'UUID[[:space:]]*:[[:space:]]*[0-9a-fA-F-]+' | grep -oE '[0-9a-fA-F-]+$')
            [[ -n "$uuid" ]] && MTT_GPU_UUIDS[$idx]="$uuid"
        fi
    done <<< "$raw"
}

# 枚举摩尔线程 GPU BDF（真机走 sysfs，mock 走已解析的 MTT_BDFS）
_build_mtt_bdfs() {
    if [[ ${#MTT_BDFS[@]} -gt 0 ]]; then
        return 0
    fi
    local d v cls bdf
    for d in /sys/bus/pci/devices/*/vendor; do
        [[ -r "$d" ]] || continue
        v=$(cat "$d" 2>/dev/null)
        [[ "$v" != "0x1ed5" ]] && continue
        cls=$(cat "$(dirname "$d")/class" 2>/dev/null || echo "")
        [[ "$cls" =~ ^0x03 || "$cls" =~ ^0x12 ]] || continue
        bdf=$(basename "$(dirname "$d")")
        MTT_BDFS+=("$(normalize_pci_addr "$bdf")")
    done
}

# 从 lspci -vv 提取型号名（Subsystem 优先），兜底用 mthreads-gmi 名称
_mtt_name_from_lspci() {
    local bdf="$1"
    local info; info=$(_get_lspci_vv "$bdf")
    [[ -z "$info" ]] && { echo ""; return; }
    local soc
    soc=$(echo "$info" | head -1 | sed -E 's/^[0-9a-fA-F:.]+ [^:]*: //')
    soc=$(echo "$soc" | sed -E 's/\[1ed5:[0-9a-fA-F]{4}\]//' | sed 's/[[:space:]]*$//')
    echo "$soc"
}

# ---------------------------------------------------------------------------
# 摩尔线程采集主流程（输出与 NVIDIA/AMD 相同 30 列）
# ---------------------------------------------------------------------------

collect_moore_info() {
    local serial="$1"
    local output_file="$2"

    log_info "正在收集 Moore Threads GPU 信息..."

    load_mtt_gmi
    _build_mtt_bdfs

    local total=${#MTT_BDFS[@]}
    if [[ $total -eq 0 ]]; then
        log_warn "未找到 Moore Threads GPU"
        return 0
    fi
    log_info "检测到 $total 个 Moore Threads GPU 设备"

    local gpu_smi_ver_val="${MTT_GMI_VER:-N/A}"
    local software_stack_val="N/A"
    [[ -n "$MTT_DRIVER_VER" ]] && software_stack_val="driver $MTT_DRIVER_VER"

    local record_count=0
    local idx=0
    local bdf
    for bdf in "${MTT_BDFS[@]}"; do
        bdf=$(normalize_pci_addr "$bdf")

        # ---- 型号 ----
        local name="${MTT_GPU_NAME[$bdf]:-}"
        local model_val
        if [[ -n "$name" ]]; then
            local k found=""
            for k in "${!GPU_MODEL_MAP[@]}"; do
                if [[ "$name" == *"$k"* ]]; then found="${GPU_MODEL_MAP[$k]}"; break; fi
            done
            model_val="${found:-$name}"
        else
            model_val=$(_mtt_name_from_lspci "$bdf")
        fi
        [[ -z "$model_val" ]] && model_val="MTT GPU"

        # ---- 静态字段（lspci / sysfs）----
        local product_val; product_val=$(get_gpu_product "$bdf")
        local serial_val=""
        local info; info=$(_get_lspci_vv "$bdf")
        [[ -n "$info" ]] && serial_val=$(echo "$info" | grep -i "\[SN\]" | head -1 \
            | sed 's/.*\[SN\]//' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//' \
            | sed 's/^Serial number:[[:space:]]*//')
        [[ -z "$serial_val" ]] && serial_val="N/A"

        local vbios_val=""
        [[ -n "$info" ]] && vbios_val=$(echo "$info" | grep -i "\[FW\]" | head -1 \
            | sed 's/.*\[FW\]//' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//' \
            | sed 's/^Firmware version:[[:space:]]*//')
        [[ -z "$vbios_val" ]] && vbios_val="N/A"

        local mem_total="${MTT_GPU_MEM_TOTAL[$bdf]:-0}"; [[ -z "$mem_total" ]] && mem_total="0"
        local mem_used="${MTT_GPU_MEM_USED[$bdf]:-N/A}"; [[ -z "$mem_used" ]] && mem_used="N/A"
        local utilization="${MTT_GPU_UTIL[$bdf]:-N/A}"; [[ -z "$utilization" ]] && utilization="N/A"
        local temp="${MTT_GPU_TEMP[$bdf]:-N/A}"; [[ -z "$temp" ]] && temp="N/A"
        local ecc_val="${MTT_GPU_ECC[$bdf]:-N/A}"; [[ -z "$ecc_val" ]] && ecc_val="N/A"
        local power_cap="${MTT_GPU_POWER_CAP[$bdf]:-N/A}"; [[ -z "$power_cap" ]] && power_cap="N/A"
        local driver_val="${MTT_DRIVER_VER:-N/A}"
        local sm_clk="${MTT_GPU_SM_CLK[$bdf]:-N/A}";   [[ -z "$sm_clk"  ]] && sm_clk="N/A"
        local mem_clk="${MTT_GPU_MEM_CLK[$bdf]:-N/A}"; [[ -z "$mem_clk" ]] && mem_clk="N/A"
        local fan_val="${MTT_GPU_FAN[$bdf]:-N/A}";     [[ -z "$fan_val" ]] && fan_val="N/A"

        local pcie_slot_val; pcie_slot_val=$(get_pcie_slot "$bdf")
        local pcie_gen_val;  pcie_gen_val=$(get_gpu_pcie_gen "$bdf")
        local pcie_cap_val;  pcie_cap_val=$(get_gpu_pcie_link_cap "$bdf")
        local pcie_sta_val;  pcie_sta_val=$(get_gpu_pcie_link_sta "$bdf")
        local vid; vid=$(_get_pcie_vid_sysfs "$bdf"); [[ -z "$vid" ]] && vid="1ed5"
        local pid; pid=$(_get_pcie_pid_sysfs "$bdf"); [[ -z "$pid" ]] && pid="N/A"

        local f=()
        local uuid_val="${MTT_GPU_UUIDS[$idx]:-N/A}"; [[ -z "$uuid_val" ]] && uuid_val="N/A"

        f+=("$(csv_escape "$serial")")
        f+=("$(csv_escape "$idx")")
        f+=("$(csv_escape "$uuid_val")")                 # gpu_uuid
        f+=("$(csv_escape "Moore Threads")")             # gpu_vendor
        f+=("$(csv_escape "$model_val")")                # gpu_model
        f+=("$(csv_escape "$product_val")")              # gpu_product
        f+=("$(csv_escape "$serial_val")")               # gpu_serial
        f+=("$(csv_escape "$mem_total")")                # gpu_memory_mib
        f+=("$(csv_escape "$vbios_val")")                # gpu_vbios_ver
        f+=("$(csv_escape "$driver_val")")               # gpu_driver_ver
        f+=("$(csv_escape "$bdf")")                      # pcie_bus_id
        f+=("$(csv_escape "$pcie_slot_val")")
        f+=("$(csv_escape "$vid")")
        f+=("$(csv_escape "$pid")")
        f+=("$(csv_escape "$pcie_gen_val")")
        f+=("$(csv_escape "$pcie_cap_val")")
        f+=("$(csv_escape "$pcie_sta_val")")
        f+=("$(csv_escape "N/A")")                       # gpu_nvlink
        f+=("$(csv_escape "$power_cap")")
        f+=("$(csv_escape "$gpu_smi_ver_val")")
        f+=("$(csv_escape "$software_stack_val")")
        f+=("$(csv_escape "$sm_clk")")                   # gpu_sm_clk_mhz
        f+=("$(csv_escape "$mem_clk")")                  # gpu_mem_clk_mhz
        f+=("$(csv_escape "$fan_val")")                  # gpu_fan_speed
        f+=("$(csv_escape "$temp")")                     # gpu_temperature_celsius
        f+=("$(csv_escape "N/A")")                        # gpu_ecc_errors（MTT 无错误计数来源）
        f+=("$(csv_escape "${MTT_GPU_POWER_DRAW[$bdf]:-N/A}")") # gpu_power_draw_w
        f+=("$(csv_escape "$mem_used")")                 # gpu_memory_used_mib
        f+=("$(csv_escape "$utilization")")              # gpu_utilization_percent
        f+=("$(csv_escape "$ecc_val")")                  # gpu_ecc_mode

        local IFS=','
        echo "${f[*]}" >> "$output_file"
        record_count=$((record_count + 1))

        log_info "✅ MTT GPU $idx: $model_val (BDF: $bdf, Mem: ${mem_total}MiB, Temp: $temp°C, PowerCap: ${power_cap}W, SMClk: ${sm_clk}MHz, MemClk: ${mem_clk}MHz, ECC: $ecc_val)"

        idx=$((idx + 1))
    done

    echo "$record_count"
}

# ---------------------------------------------------------------------------
# 输出
# ---------------------------------------------------------------------------

generate_output_filename() {
    local serial="$1"
    local clean
    clean=$(echo "$serial" | sed 's/[^a-zA-Z0-9_-]//g')
    if [[ -z "$clean" || "$clean" == "UNKNOWN" ]]; then
        echo "${OUTPUT_DIR}/gpu_info.csv"
    else
        echo "${OUTPUT_DIR}/gpu_info_${clean}.csv"
    fi
}

write_csv_header() {
    echo "server_serial,gpu_index,gpu_uuid,gpu_vendor,gpu_model,gpu_product,gpu_serial,gpu_memory_mib,gpu_vbios_ver,gpu_driver_ver,pcie_bus_id,pcie_slot,pcie_vendor_id,pcie_product_id,pcie_gen,pcie_link_cap,pcie_link_sta,gpu_nvlink,gpu_power_cap,gpu_smi_ver,software_stack_ver,gpu_sm_clk_mhz,gpu_mem_clk_mhz,gpu_fan_speed,gpu_temperature_celsius,gpu_ecc_errors,gpu_power_draw_w,gpu_memory_used_mib,gpu_utilization_percent,gpu_ecc_mode" > "$1"
}

# ---------------------------------------------------------------------------
# NVIDIA 采集主流程
# ---------------------------------------------------------------------------

collect_gpu_info() {
    local serial="$1"
    local output_file="$2"

    log_info "正在收集 NVIDIA GPU 信息..."

    load_nv_rows
    load_nv_smi
    load_nv_topo

    local gpu_smi_ver;    gpu_smi_ver=$(get_nvidia_smi_version)
    local software_stack; software_stack=$(get_software_stack_ver_nv)
    log_info "NVIDIA-SMI: $gpu_smi_ver, 软件栈: $software_stack"

    local gpu_count; gpu_count=$(get_gpu_count)
    if [[ "$gpu_count" -eq 0 ]]; then
        log_warn "未检测到 NVIDIA GPU 设备！"
        return 0
    fi
    log_info "检测到 $gpu_count 个 NVIDIA GPU 设备"

    local any_ecc_enabled=false
    local gi
    for ((gi=0; gi<gpu_count; gi++)); do
        local em; em=$(q_named "$gi" "ecc.mode.current")
        if [[ "$em" == "Enabled" ]]; then any_ecc_enabled=true; break; fi
    done
    if [[ "$any_ecc_enabled" == "true" ]]; then
        load_retired_pages
        load_remapped_rows
    else
        log_info "所有 NVIDIA GPU 的 ECC 均未启用，跳过 retired_pages / remapped_rows 查询"
    fi

    local record_count=0
    local gpu_idx

    for ((gpu_idx=0; gpu_idx<gpu_count; gpu_idx++)); do
        local pci_addr; pci_addr=$(get_gpu_pci_address "$gpu_idx")

        local pcie_gen_val pcie_link_cap_val pcie_link_sta_val
        pcie_gen_val=$(get_gpu_pcie_gen "$pci_addr")
        pcie_link_cap_val=$(get_gpu_pcie_link_cap "$pci_addr")
        pcie_link_sta_val=$(get_gpu_pcie_link_sta "$pci_addr")

        local nvlink_val;    nvlink_val=$(get_gpu_nvlink "$gpu_idx")
        local pcie_slot_val; pcie_slot_val=$(get_pcie_slot "$pci_addr")
        local ecc_val;       ecc_val=$(get_gpu_ecc_errors "$gpu_idx")
        local fan_val;       fan_val=$(get_gpu_fan_speed "$gpu_idx")
        local sm_clk_val;    sm_clk_val=$(get_gpu_sm_clk_max_nv "$gpu_idx")
        local mem_clk_val;   mem_clk_val=$(get_gpu_mem_clk_max_nv "$gpu_idx")
        local power_draw_val; power_draw_val=$(get_gpu_power_draw_nv "$gpu_idx")
        local mem_used_val;   mem_used_val=$(get_gpu_memory_used_nv "$gpu_idx")
        local util_val;       util_val=$(get_gpu_utilization_nv "$gpu_idx")
        local ecc_mode_val;   ecc_mode_val=$(get_gpu_ecc_mode_nv "$gpu_idx")

        local f=()
        f+=("$(csv_escape "$serial")")
        f+=("$(csv_escape "$(get_gpu_index "$gpu_idx")")")
        f+=("$(csv_escape "$(get_gpu_uuid "$gpu_idx")")")
        f+=("$(csv_escape "$(get_gpu_vendor "$pci_addr")")")
        f+=("$(csv_escape "$(get_gpu_model "$gpu_idx")")")
        f+=("$(csv_escape "$(get_gpu_product "$pci_addr")")")
        f+=("$(csv_escape "$(get_gpu_serial "$gpu_idx")")")
        f+=("$(csv_escape "$(get_gpu_memory_mib "$gpu_idx")")")
        f+=("$(csv_escape "$(get_gpu_vbios_full "$gpu_idx")")")
        f+=("$(csv_escape "$(get_gpu_driver_ver_nv "$gpu_idx")")")
        f+=("$(csv_escape "$(get_gpu_pcie_bus_id "$gpu_idx")")")
        f+=("$(csv_escape "$pcie_slot_val")")
        f+=("$(csv_escape "$(get_gpu_pcie_vendor_id "$pci_addr")")")
        f+=("$(csv_escape "$(get_gpu_pcie_product_id "$pci_addr")")")
        f+=("$(csv_escape "$pcie_gen_val")")
        f+=("$(csv_escape "$pcie_link_cap_val")")
        f+=("$(csv_escape "$pcie_link_sta_val")")
        f+=("$(csv_escape "$nvlink_val")")
        f+=("$(csv_escape "$(get_gpu_power_cap "$gpu_idx")")")
        f+=("$(csv_escape "$gpu_smi_ver")")
        f+=("$(csv_escape "$software_stack")")
        f+=("$(csv_escape "$sm_clk_val")")
        f+=("$(csv_escape "$mem_clk_val")")
        f+=("$(csv_escape "$fan_val")")
        f+=("$(csv_escape "$(get_gpu_temperature "$gpu_idx")")")
        f+=("$(csv_escape "$ecc_val")")
        f+=("$(csv_escape "$power_draw_val")")   # gpu_power_draw_w
        f+=("$(csv_escape "$mem_used_val")")     # gpu_memory_used_mib
        f+=("$(csv_escape "$util_val")")         # gpu_utilization_percent
        f+=("$(csv_escape "$ecc_mode_val")")     # gpu_ecc_mode

        local IFS=','
        echo "${f[*]}" >> "$output_file"
        record_count=$((record_count + 1))

        log_info "✅ NVIDIA GPU $gpu_idx: $(get_gpu_model "$gpu_idx") (BusID: $(get_gpu_pcie_bus_id "$gpu_idx"), Mem: $(get_gpu_memory_mib "$gpu_idx")MiB, NVLink: $nvlink_val, MaxSMClk: ${sm_clk_val}MHz, MaxMemClk: ${mem_clk_val}MHz, Temp: $(get_gpu_temperature "$gpu_idx")°C, ECC: $ecc_val)"
    done

    echo "$record_count"
}

# ---------------------------------------------------------------------------
# 主函数
# ---------------------------------------------------------------------------

main() {
    print_header "服务器GPU信息收集工具 (v33)"

    if [[ "$MOCK_MODE" == "true" ]]; then
        log_info "🧪 Mock 模式: MOCK_DIR=$MOCK_DIR"
    fi

    init_gpu_vendor_map
    init_gpu_model_map
    init_query_fields

    local has_nvidia=false has_amd=false has_moore=false
    detect_nvidia_gpu && has_nvidia=true
    detect_amd_gpu    && has_amd=true
    detect_moore_gpu  && has_moore=true

    if [[ "$has_nvidia" == "false" && "$has_amd" == "false" && "$has_moore" == "false" ]]; then
        log_warn "未检测到 NVIDIA / AMD / Moore Threads GPU（lspci / sysfs 均未命中）"
        print_separator
        echo -e "${YELLOW}⚠ 当前节点未检测到 NVIDIA / AMD / Moore Threads GPU，无需采集，脚本退出${NC}" >&2
        print_separator
        exit 0
    fi

    [[ "$has_nvidia" == "true" ]] && log_info "已检测到 NVIDIA GPU"
    [[ "$has_amd" == "true"    ]] && log_info "已检测到 AMD GPU"
    [[ "$has_moore" == "true"  ]] && log_info "已检测到 Moore Threads GPU"

    if [[ "$has_nvidia" == "true" ]] && ! have_cmd nvidia-smi; then
        log_error "检测到 NVIDIA GPU，但系统未安装 nvidia-smi（或不在 PATH 中）"
        exit 1
    fi
    if [[ "$has_amd" == "true" ]]; then
        if ! have_cmd amd-smi && ! have_cmd rocm-smi; then
            log_warn "检测到 AMD GPU，但未安装 amd-smi / rocm-smi，仅能采集静态信息"
        fi
    fi
    if [[ "$has_moore" == "true" ]]; then
        if ! have_cmd mthreads-gmi; then
            log_warn "检测到 Moore Threads GPU，但未安装 mthreads-gmi，仅能采集静态信息"
        fi
    fi

    SYSTEM_SERIAL=$(get_system_serial)
    log_info "最终使用系统序列号: $SYSTEM_SERIAL"

    OUTPUT_FILE=$(generate_output_filename "$SYSTEM_SERIAL")

    for t in dmidecode lspci; do
        have_cmd "$t" || log_warn "缺少工具: $t"
    done

    # mock 模式下跳过 sudo 检查
    if [[ "$MOCK_MODE" != "true" ]]; then
        if ! sudo -v 2>/dev/null; then
            log_error "需要 sudo 权限"
            exit 1
        fi
    fi

    load_pci_slot_map

    [[ -d "$OUTPUT_DIR" ]] || mkdir -p "$OUTPUT_DIR" 2>/dev/null \
        || { log_error "无法创建 $OUTPUT_DIR"; exit 1; }

    write_csv_header "$OUTPUT_FILE"

    if [[ "$has_nvidia" == "true" ]]; then
        collect_gpu_info "$SYSTEM_SERIAL" "$OUTPUT_FILE" >/dev/null
    fi

    if [[ "$has_amd" == "true" ]]; then
        collect_amd_info "$SYSTEM_SERIAL" "$OUTPUT_FILE" >/dev/null
    fi

    if [[ "$has_moore" == "true" ]]; then
        collect_moore_info "$SYSTEM_SERIAL" "$OUTPUT_FILE" >/dev/null
    fi

    print_separator
    echo -e "${GREEN}✅ 完成！${NC}" >&2
    print_separator
    echo -e "📁 输出文件: ${BLUE}$OUTPUT_FILE${NC}" >&2

    if [[ -f "$OUTPUT_FILE" ]]; then
        echo -e "📊 GPU记录: ${BLUE}$(($(wc -l < "$OUTPUT_FILE") - 1))${NC} 条" >&2
        print_separator
        cat "$OUTPUT_FILE"
        print_separator
    fi
}

# ---------------------------------------------------------------------------
# 参数
# ---------------------------------------------------------------------------

show_help() {
    cat << EOF
服务器GPU信息收集工具 (v33)

用法: $SCRIPT_NAME [选项]

选项:
    -h, --help          显示帮助
    -d, --debug         调试模式
    -o, --output DIR    输出目录 (默认: <脚本目录>/report)
    -s, --serial SN     手动指定系统序列号
    --mock-dir DIR      模拟模式，从 DIR 读取命令输出（用于回归测试）

环境变量:
    DEBUG=true          等价于 -d
    MOCK_DIR=DIR        等价于 --mock-dir DIR

模拟模式说明:
    所有外部命令改为从 \$MOCK_DIR/<name>.txt 读取，不再执行真命令。
    关键 mock 文件（由 make_mock.sh 生成）：
      - nvidia-smi.query.txt / nvidia-smi.header.txt / nvidia-smi.topo.txt
      - amd-smi.list.txt / amd-smi.static.txt / amd-smi.metric.txt
      - amd-smi.topology.txt / amd-smi.version.txt
      - lspci.nn.txt / lspci.list.txt / lspci.vv.<key>.txt
      - sysfs.realpath.<key>.txt（get_pcie_slot 依赖它查 slot 归属）
      - sysfs.vendor.<key>.txt / sysfs.device.<key>.txt
      - dmidecode.slot.txt / dmidecode.serial.txt
    其中 <key> 为规范化全 BDF 把 ':' 和 '.' 换成 '_'：
      0000:0f:00.0 → 0000_0f_00_0

输出列（30 列）:
    server_serial,gpu_index,gpu_uuid,
    gpu_vendor,gpu_model,gpu_product,gpu_serial,gpu_memory_mib,
    gpu_vbios_ver,gpu_driver_ver,pcie_bus_id,pcie_slot,
    pcie_vendor_id,pcie_product_id,
    pcie_gen,pcie_link_cap,pcie_link_sta,gpu_nvlink,
    gpu_power_cap,gpu_smi_ver,software_stack_ver,
    gpu_sm_clk_mhz,gpu_mem_clk_mhz,
    gpu_fan_speed,gpu_temperature_celsius,gpu_ecc_errors,
    gpu_power_draw_w,gpu_memory_used_mib,gpu_utilization_percent,gpu_ecc_mode

v34 变更:
    - 新增摩尔线程（Moore Threads）GPU 支持（mthreads-gmi）
    - 新增 4 列（26 → 30）：gpu_power_draw_w / gpu_memory_used_mib /
      gpu_utilization_percent / gpu_ecc_mode，三厂商列数保持一致

v33 变更:
    - 修复 mock 模式下 get_pcie_slot 返回 Unknown
      原因：readlink -f 直连真机 sysfs
      修复：readlink -f 走 run_cmd，mock 从 sysfs.realpath.<key>.txt 读

v32 变更:
    - 新增模拟测试能力 --mock-dir / MOCK_DIR

v31 变更:
    - 移除 gpu_soc_clk_mhz 列（27 → 26 列）

v30 变更:
    - Clock 改为最大频率
    - 移除 gpu_throttle_reason 列

v29 变更:
    - 新增频率指标列

v28 变更:
    - AMD 采集合并为 5 次 amd-smi 调用

v27 变更:
    - AMD ECC 输出 correctable/uncorrectable/deferred/total

v26 变更:
    - nvidia_smi_ver → gpu_smi_ver

v25 变更:
    - 新增 gpu_driver_ver；gpu_firmware → gpu_vbios_ver；
      nvidia_cuda_ver → software_stack_ver
EOF
}

parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)   show_help; exit 0 ;;
            -d|--debug)  DEBUG="true"; shift ;;
            -o|--output) OUTPUT_DIR="$2"; shift 2 ;;
            -s|--serial) SYSTEM_SERIAL="$2"; shift 2 ;;
            --mock-dir)  MOCK_DIR="$2"; MOCK_MODE=true; shift 2 ;;
            *) log_error "未知选项: $1"; show_help; exit 1 ;;
        esac
    done
}

parse_args "$@"
main
