客户端需安装好 smartmontools lldpd ipmitool
（如为摩尔线程 GPU 节点，需额外安装 mthreads-gmi）

1. 分发收集脚本
ansible-playbook -i hosts 1.copy_collect_script.yml

2. 执行收集脚本
ansible-playbook -i hosts 2.run_collect_script.yml
或者 ansible -i hosts all -b -m shell -a 'bash /opt/collect_server_hwinfo/1.collect_all_hwinfo.sh'

3. 收集各节点执行结果至本机
ansible-playbook -i hosts 3.fetch_reports.yml

4. 汇总各节点执行结果
./4.summarize.py
