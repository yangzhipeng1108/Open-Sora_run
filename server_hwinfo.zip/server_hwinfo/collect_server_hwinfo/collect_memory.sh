#!/bin/bash

# ============================================================================
# 服务器内存信息收集脚本 - 优化版
# 功能：收集服务器内存硬件信息，生成CSV格式报告
# 输出列：server_serial,mem_type,mem_vendor,mem_product,mem_clock_mhz,mem_size_gb,mem_slot,mem_serial
#
# 厂商识别优先级：
#   1. dmidecode 的 Manufacturer 字段（最权威）
#   2. 型号正则模式表（主力）
#   3. 例外型号精确表（极小，兜底）
#   4. UNKNOWN
# ============================================================================

# 全局变量
SCRIPT_NAME=$(basename "$0")
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUTPUT_DIR="${OUTPUT_DIR:-${SCRIPT_DIR}/report}"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
OUTPUT_FILE=""
SYSTEM_SERIAL=""
DEBUG="${DEBUG:-false}"

# 颜色定义
readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly NC='\033[0m'

# ============================================================================
# 日志函数
# ============================================================================

log_info()  { echo -e "${GREEN}[INFO]${NC} $*" >&2; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC} $*" >&2; }
log_error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }
log_debug() {
    if [[ "${DEBUG}" == "true" ]]; then
        echo -e "${BLUE}[DEBUG]${NC} $*" >&2
    fi
}

print_separator() { echo "========================================="; }
print_header() {
    print_separator
    echo -e "${GREEN}$1${NC}"
    print_separator
}

# ============================================================================
# 系统序列号获取
# ============================================================================

get_serial_from_dmidecode() {
    local serial
    serial=$(sudo dmidecode -s system-serial-number 2>/dev/null | head -1)
    if [[ -n "$serial" ]] && [[ "$serial" != "Not Specified" ]] && [[ "$serial" != "Unknown" ]]; then
        echo "$serial"; return 0
    fi
    return 1
}

get_serial_from_lshw() {
    local serial
    serial=$(sudo lshw -system 2>/dev/null | grep "serial:" | head -1 | awk '{print $2}')
    if [[ -n "$serial" ]] && [[ "$serial" != "None" ]]; then
        echo "$serial"; return 0
    fi
    return 1
}

get_serial_from_sysfs() {
    local serial
    if [[ -f "/sys/class/dmi/id/product_serial" ]]; then
        serial=$(sudo cat /sys/class/dmi/id/product_serial 2>/dev/null)
        if [[ -n "$serial" ]] && [[ "$serial" != "Not Specified" ]]; then
            echo "$serial"; return 0
        fi
    fi
    return 1
}

get_serial_from_hostid() {
    local serial
    serial=$(hostid 2>/dev/null)
    if [[ -n "$serial" ]] && [[ "$serial" != "00000000" ]]; then
        echo "$serial"; return 0
    fi
    return 1
}

get_system_serial() {
    local serial=""
    local methods=(
        "get_serial_from_dmidecode"
        "get_serial_from_lshw"
        "get_serial_from_sysfs"
        "get_serial_from_hostid"
    )

    echo "[INFO] 正在获取系统序列号..." >&2

    for method in "${methods[@]}"; do
        if serial=$($method 2>/dev/null); then
            local method_name="${method#get_serial_from_}"
            echo "[INFO] 通过 ${method_name} 获取到序列号: $serial" >&2
            echo "$serial"
            return 0
        fi
    done

    echo "[WARN] 无法获取系统序列号，使用默认值: UNKNOWN" >&2
    echo "UNKNOWN"
    return 1
}

# ============================================================================
# Vendor 识别规则
# ============================================================================

# 型号正则模式表（按顺序匹配，先命中先返回）
# 格式: '正则|厂商名'
declare -a VENDOR_PATTERNS

# 例外型号精确表（模式匹配搞不定的少数情况，精确或包含匹配）
declare -A VENDOR_EXCEPTIONS

init_vendor_map() {
    log_debug "初始化Vendor模式匹配表..."

    VENDOR_PATTERNS=(
        # ---------- 三星 Samsung ----------
        # M3xx / M32x 服务器内存，前缀已覆盖；其他 M 开头做宽泛兜底
        '^M[0-9]{2}[A-Z]|Samsung'

        # ---------- SK Hynix ----------
        '^HMA|Hynix'
        '^HMC|Hynix'

        # ---------- 美光 Micron ----------
        '^18ASF|Micron'
        '^36ASF|Micron'
        '^MT[0-9]|Micron'
        '^MTC|Micron'

        # ---------- 金士顿 Kingston ----------
        '^KVR|Kingston'
        '^KSM|Kingston'
        '^KHX|Kingston'
        '^KF[0-9]|Kingston'
        '^HX[0-9]|Kingston'

        # ---------- 英睿达 Crucial ----------
        '^CT[0-9]|Crucial'
        '^BL[0-9]|Crucial'

        # ---------- 海盗船 Corsair ----------
        '^CM[KWHTPDV45]|Corsair'

        # ---------- 威刚 ADATA ----------
        '^AD[0-9]|ADATA'
        '^AX[0-9]|ADATA'

        # ---------- 芝奇 G.Skill ----------
        '^F[345]-|G.Skill'

        # ---------- 博帝 Patriot ----------
        '^PV[0-9]|Patriot'
        '^PSD|Patriot'

        # ---------- 十铨 TeamGroup ----------
        '^TF|TeamGroup'
        '^TPD|TeamGroup'
        '^TED|TeamGroup'
        'T-FORCE|TeamGroup'

        # ---------- 南亚 Nanya ----------
        '^NT[0-9]|Nanya'

        # ---------- 记忆科技 Ramaxel ----------
        '^RM[0-9]|Ramaxel'

        # ---------- 创见 Transcend ----------
        '^TS[0-9]|Transcend'

        # ---------- 宇瞻 Apacer ----------
        '^AP[0-9]|Apacer'
        '^78\.|Apacer'

        # ---------- 广颖电通 Silicon Power ----------
        '^SP[0-9]|Silicon Power'

        # ---------- PNY / 雷克沙 / 科赋 / 海康 ----------
        '^PNY|PNY'
        '^LD[0-9]|Lexar'
        '^KD[0-9]|KLEVV'
        '^HK[0-9]|Hikvision'

        # ---------- OEM / 服务器品牌 ----------
        '^HPE|HPE'
        '^HP[0-9]|HPE'
        '^DELL|Dell'
        '^SNP|Dell'
        '^IBM|IBM'
        '^LEN|Lenovo'
        '^CISCO|Cisco'
        '^INTEL|Intel'
        '^TOSHIBA|Kioxia'
        '^KIOXIA|Kioxia'

        # ---------- 老牌 / 其他 ----------
        '^EBJ|Elpida'
        '^EDJ|Elpida'
        '^INFINEON|Infineon'
        '^HYS|Infineon'
        '^QIMONDA|Qimonda'
        '^IM[0-9]|Qimonda'
        '^HUAWEI|Huawei'
        '^HW[0-9]|Huawei'
        '^H3C|H3C'
        '^INSPUR|Inspur'
        '^SUGON|Sugon'
    )

    # 例外型号（精确 / 包含匹配，优先级高于正则模式表）
    # 只在正则表会误判或覆盖不到时才需要加
    VENDOR_EXCEPTIONS=()

    log_debug "Vendor规则初始化完成：${#VENDOR_PATTERNS[@]} 条正则，${#VENDOR_EXCEPTIONS[@]} 条例外"
}

# ============================================================================
# 生成 AWK 规则字符串
# ============================================================================

generate_vendor_awk() {
    local awk_code=""

    # 例外表
    local key val
    for key in "${!VENDOR_EXCEPTIONS[@]}"; do
        local k="${key//\\/\\\\}"; k="${k//\"/\\\"}"
        val="${VENDOR_EXCEPTIONS[$key]}"
        awk_code="${awk_code}vendor_exceptions[\"${k}\"] = \"${val}\"; "
    done

    # 正则模式表（用 | 分隔，AWK 里按顺序尝试）
    awk_code="${awk_code}vendor_patterns = \""
    local first=1
    for rule in "${VENDOR_PATTERNS[@]}"; do
        local pattern="${rule%%|*}"
        local vendor="${rule##*|}"
        # AWK 正则分隔符用 |
        if [[ $first -eq 1 ]]; then
            awk_code="${awk_code}${pattern}=>${vendor}"
            first=0
        else
            awk_code="${awk_code}|${pattern}=>${vendor}"
        fi
    done
    awk_code="${awk_code}\"; "

    echo "$awk_code"
}

# ============================================================================
# 内存信息解析
# ============================================================================

parse_memory_info() {
    local serial="$1"
    local output_file="$2"
    local awk_vendor_code
    awk_vendor_code=$(generate_vendor_awk)

    log_info "正在解析内存信息..."

    sudo dmidecode -t memory 2>/dev/null | awk -v serial="$serial" '
    BEGIN {
        # 初始化 vendor 规则
        '"$awk_vendor_code"'

        in_memory = 0
        mem_type = ""
        mem_product = ""
        mem_clock = ""
        mem_serial = ""
        mem_size = ""
        mem_slot = ""
        mem_vendor_dmi = ""
        record_count = 0
    }

    /^[[:space:]]*Memory Device/ {
        if (in_memory && mem_size != "" && mem_size != "No Module Installed" && mem_size != "Not Installed") {
            record_count++
            print_record(serial)
        }
        in_memory = 1
        mem_type = ""
        mem_product = ""
        mem_clock = ""
        mem_serial = ""
        mem_size = ""
        mem_slot = ""
        mem_vendor_dmi = ""
    }

    in_memory == 1 {
        line = $0
        sub(/^[[:space:]]*/, "", line)

        if (index(line, "Type:") == 1) {
            val = substr(line, 6)
            gsub(/^[[:space:]]*|[[:space:]]*$/, "", val)
            if (val != "Unknown" && val != "Not Specified" && val != "Error") {
                if (index(val, "DDR5") > 0) mem_type = "DDR5"
                else if (index(val, "DDR4") > 0) mem_type = "DDR4"
                else if (index(val, "DDR3") > 0) mem_type = "DDR3"
                else mem_type = val
            }
        }
        else if (index(line, "Size:") == 1) {
            mem_size = substr(line, 6)
            gsub(/^[[:space:]]*|[[:space:]]*$/, "", mem_size)
            if (index(mem_size, "No Module Installed") > 0 || index(mem_size, "Not Installed") > 0) {
                mem_size = ""
            }
        }
        else if (index(line, "Speed:") == 1) {
            mem_clock = substr(line, 7)
            gsub(/^[[:space:]]*|[[:space:]]*$/, "", mem_clock)
            if (index(mem_clock, "Unknown") > 0 || index(mem_clock, "Not Specified") > 0) {
                mem_clock = ""
            }
        }
        else if (index(line, "Serial Number:") == 1) {
            mem_serial = substr(line, 15)
            gsub(/^[[:space:]]*|[[:space:]]*$/, "", mem_serial)
            if (index(mem_serial, "Not Specified") > 0 || index(mem_serial, "Unknown") > 0) {
                mem_serial = "N/A"
            }
        }
        else if (index(line, "Locator:") == 1) {
            mem_slot = substr(line, 10)
            gsub(/^[[:space:]]*|[[:space:]]*$/, "", mem_slot)
        }
        else if (index(line, "Part Number:") == 1) {
            mem_product = substr(line, 14)
            gsub(/^[[:space:]]*|[[:space:]]*$/, "", mem_product)
            if (index(mem_product, "Not Specified") > 0 || index(mem_product, "Unknown") > 0) {
                mem_product = ""
            }
        }
        else if (index(line, "Manufacturer:") == 1) {
            mem_vendor_dmi = substr(line, 15)
            gsub(/^[[:space:]]*|[[:space:]]*$/, "", mem_vendor_dmi)
            if (index(mem_vendor_dmi, "Not Specified") > 0 || \
                index(mem_vendor_dmi, "Unknown") > 0 || \
                index(mem_vendor_dmi, "NO DIMM") > 0 || \
                index(mem_vendor_dmi, "NO MODULE") > 0) {
                mem_vendor_dmi = ""
            }
        }
    }

    # -----------------------------------------------------------------------
    # 从 dmidecode Manufacturer 字段归一化厂商名
    # -----------------------------------------------------------------------
    function normalize_dmi_vendor(d,    u) {
        u = toupper(d)
        if (index(u, "SAMSUNG") > 0)                       return "Samsung"
        if (index(u, "HYNIX") > 0)                         return "Hynix"
        if (index(u, "MICRON") > 0)                        return "Micron"
        if (index(u, "KINGSTON") > 0)                      return "Kingston"
        if (index(u, "CRUCIAL") > 0)                       return "Crucial"
        if (index(u, "CORSAIR") > 0)                       return "Corsair"
        if (index(u, "ADATA") > 0)                         return "ADATA"
        if (index(u, "G.SKILL") > 0 || index(u, "GSKILL") > 0) return "G.Skill"
        if (index(u, "PATRIOT") > 0)                       return "Patriot"
        if (index(u, "TEAMGROUP") > 0 || index(u, "TEAM GROUP") > 0) return "TeamGroup"
        if (index(u, "NANYA") > 0)                         return "Nanya"
        if (index(u, "RAMAXEL") > 0)                       return "Ramaxel"
        if (index(u, "TRANSCEND") > 0)                     return "Transcend"
        if (index(u, "APACER") > 0)                        return "Apacer"
        if (index(u, "SILICON POWER") > 0)                 return "Silicon Power"
        if (index(u, "PNY") > 0)                           return "PNY"
        if (index(u, "LEXAR") > 0)                         return "Lexar"
        if (index(u, "KLEVV") > 0)                         return "KLEVV"
        if (index(u, "HIKVISION") > 0)                     return "Hikvision"
        if (index(u, "HPE") > 0 || index(u, "HEWLETT") > 0) return "HPE"
        if (index(u, "DELL") > 0)                          return "Dell"
        if (index(u, "IBM") > 0)                           return "IBM"
        if (index(u, "LENOVO") > 0)                        return "Lenovo"
        if (index(u, "CISCO") > 0)                         return "Cisco"
        if (index(u, "INTEL") > 0)                         return "Intel"
        if (index(u, "TOSHIBA") > 0)                       return "Toshiba"
        if (index(u, "KIOXIA") > 0)                        return "Kioxia"
        if (index(u, "ELPIDA") > 0)                        return "Elpida"
        if (index(u, "INFINEON") > 0)                      return "Infineon"
        if (index(u, "QIMONDA") > 0)                       return "Qimonda"
        if (index(u, "HUAWEI") > 0)                        return "Huawei"
        if (index(u, "H3C") > 0)                           return "H3C"
        if (index(u, "INSPUR") > 0)                        return "Inspur"
        if (index(u, "SUGON") > 0)                         return "Sugon"
        return ""
    }

    # -----------------------------------------------------------------------
    # 用正则模式表匹配 Part Number
    # -----------------------------------------------------------------------
    function match_vendor_pattern(p,    n, arr, i, seg, pat, ven, pos) {
        if (vendor_patterns == "") return ""
        n = split(vendor_patterns, arr, "|")
        for (i = 1; i <= n; i++) {
            seg = arr[i]
            pos = index(seg, "=>")
            if (pos <= 0) continue
            pat = substr(seg, 1, pos - 1)
            ven = substr(seg, pos + 2)
            if (p ~ pat) return ven
        }
        return ""
    }

    # -----------------------------------------------------------------------
    # 打印记录
    # -----------------------------------------------------------------------
    function print_record(serial,    size_num, clock_num, vendor, p, key) {
        gsub(/[[:space:]]+/, "", mem_product)
        p = toupper(mem_product)

        size_num = mem_size
        gsub(/[^0-9]/, "", size_num)
        if (size_num == "") size_num = "0"

        clock_num = mem_clock
        gsub(/[^0-9]/, "", clock_num)
        if (clock_num == "") clock_num = "0"

        # 1) dmidecode Manufacturer 字段（最高优先级）
        vendor = ""
        if (mem_vendor_dmi != "") {
            vendor = normalize_dmi_vendor(mem_vendor_dmi)
            if (vendor == "") vendor = mem_vendor_dmi
        }

        # 2) 例外型号精确/包含匹配
        if (vendor == "" && p != "") {
            for (key in vendor_exceptions) {
                if (p == key || index(p, key) > 0) {
                    vendor = vendor_exceptions[key]
                    break
                }
            }
        }

        # 3) 正则模式表匹配
        if (vendor == "" && p != "") {
            vendor = match_vendor_pattern(p)
        }

        if (vendor == "") vendor = "UNKNOWN"

        # 内存类型兜底
        if (mem_type == "" && mem_product != "") {
            if (index(mem_product, "DDR5") > 0) mem_type = "DDR5"
            else if (index(mem_product, "DDR4") > 0) mem_type = "DDR4"
            else if (index(mem_product, "DDR3") > 0) mem_type = "DDR3"
            else mem_type = "UNKNOWN"
        }

        # 输出
        print serial "," mem_type "," vendor "," mem_product "," clock_num "," size_num "," mem_slot "," mem_serial
    }

    END {
        if (in_memory && mem_size != "" && mem_size != "No Module Installed" && mem_size != "Not Installed") {
            record_count++
            print_record(serial)
        }
    }
    ' >> "$output_file"

    local record_count
    record_count=$(tail -n +2 "$output_file" 2>/dev/null | wc -l | tr -d ' ')
    echo "${record_count:-0}"
}

# ============================================================================
# CSV 文件操作
# ============================================================================

generate_output_filename() {
    local serial="$1"
    local dir="${OUTPUT_DIR}"
    local clean_serial
    clean_serial=$(echo "$serial" | sed 's/[^a-zA-Z0-9_-]//g')

    if [[ -z "$clean_serial" ]] || [[ "$clean_serial" == "UNKNOWN" ]]; then
        echo "${dir}/memory_info.csv"
    else
        echo "${dir}/memory_info_${clean_serial}.csv"
    fi
}

write_csv_header() {
    local output_file="$1"
    echo "server_serial,mem_type,mem_vendor,mem_product,mem_clock_mhz,mem_size_gb,mem_slot,mem_serial" > "$output_file"
    log_debug "CSV头已写入: $output_file"
}

# ============================================================================
# 主函数
# ============================================================================

main() {
    print_header "服务器内存信息收集工具"

    init_vendor_map

    if [[ -z "$SYSTEM_SERIAL" ]]; then
        SYSTEM_SERIAL=$(get_system_serial)
    fi

    OUTPUT_FILE=$(generate_output_filename "$SYSTEM_SERIAL")

    if ! command -v dmidecode &>/dev/null; then
        log_error "dmidecode 命令未找到，请安装: apt-get install dmidecode 或 yum install dmidecode"
        exit 1
    fi

    if ! command -v sudo &>/dev/null; then
        log_error "sudo 命令未找到，请以root用户运行"
        exit 1
    fi

    if ! sudo -v 2>/dev/null; then
        log_error "需要sudo权限才能运行此脚本"
        log_error "请使用: sudo $SCRIPT_NAME"
        exit 1
    fi

    if [[ ! -d "$OUTPUT_DIR" ]]; then
        mkdir -p "$OUTPUT_DIR" 2>/dev/null || {
            log_error "无法创建输出目录: $OUTPUT_DIR"
            exit 1
        }
    fi

    write_csv_header "$OUTPUT_FILE"

    local record_count
    record_count=$(parse_memory_info "$SYSTEM_SERIAL" "$OUTPUT_FILE")

    print_separator
    echo -e "${GREEN}✅ 完成！${NC}"
    print_separator
    echo -e "📁 输出文件: ${BLUE}$OUTPUT_FILE${NC}"

    if [[ -f "$OUTPUT_FILE" ]]; then
        local line_count
        line_count=$(($(wc -l < "$OUTPUT_FILE") - 1))
        echo -e "📊 内存记录: ${BLUE}$line_count${NC} 条"
        print_separator
        echo -e "${YELLOW}📄 内容预览:${NC}"
        print_separator
        cat "$OUTPUT_FILE"
        print_separator
    else
        log_error "输出文件生成失败"
        exit 1
    fi
}

# ============================================================================
# 命令行参数
# ============================================================================

set -eo pipefail 2>/dev/null || true

show_help() {
    cat << EOF
服务器内存信息收集工具（优化版）

用法: $SCRIPT_NAME [选项]

选项:
    -h, --help          显示此帮助信息
    -d, --debug         启用调试模式
    -o, --output DIR    指定输出目录 (默认: 脚本所在目录/report)
    -s, --serial SN     手动指定系统序列号

示例:
    sudo $SCRIPT_NAME
    sudo $SCRIPT_NAME -o /tmp
    sudo $SCRIPT_NAME -s 2B48K82
    sudo $SCRIPT_NAME -d

输出格式:
    server_serial,mem_type,mem_vendor,mem_product,mem_clock_mhz,mem_size_gb,mem_slot,mem_serial

厂商识别优先级:
    1. dmidecode Manufacturer 字段
    2. 型号正则模式表
    3. 例外型号表
    4. UNKNOWN
EOF
}

parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)
                show_help
                exit 0
                ;;
            -d|--debug)
                DEBUG="true"
                shift
                ;;
            -o|--output)
                OUTPUT_DIR="$2"
                shift 2
                ;;
            -s|--serial)
                SYSTEM_SERIAL="$2"
                shift 2
                ;;
            *)
                log_error "未知选项: $1"
                show_help
                exit 1
                ;;
        esac
    done
}

parse_args "$@"
main

# ============================================================================
# 结束
# ============================================================================
