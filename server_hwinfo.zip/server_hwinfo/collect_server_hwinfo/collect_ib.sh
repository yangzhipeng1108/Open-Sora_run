#!/bin/bash
# ============================================================================
# 服务器 IB 网卡信息收集脚本 - v18
# 功能：收集服务器 InfiniBand 网卡硬件信息（含光模块），生成 CSV 报告
#
# 建议以 root 运行：sudo bash collect_ib.sh
#
# ----------------------------------------------------------------------------
# errors 列的设计原则
# ----------------------------------------------------------------------------
#   只记录"可能是硬件问题、或预示硬件故障"的项。
#   读不到 / 字段缺失 / 无法判断 → 一律不报告。
#   "缺数据"不等于"有故障"；混为一谈会让 errors 列被噪声淹没，
#   真正的问题反而看不见。正常时输出 "0"。
#
# ----------------------------------------------------------------------------
# 判据一览
# ----------------------------------------------------------------------------
#   数据来源合法性
#     link_layer                     非 InfiniBand（可能是以太网模式口）
#   链路状态（sysfs）
#     ib_state                       state 未到 Active
#     ib_phys_state                  phys_state 非 LinkUp
#     ib_state_phys_mismatch         上层 Active 却底层未 LinkUp（矛盾）
#   链路状态（mlxlink）
#     mlxlink_state / _phys_state    mlxlink 报告的 State / Physical state 异常
#     mlxlink_autoneg:OFF            自动协商关闭
#     loopback:<mode>                端口处于环回（未连对端）
#     mlxlink_status:<opcode>        Status Opcode 非 0
#   劣化
#     ib_speed_degraded:<cur>/<cap>  当前速率低于能力速率
#                                     （交换机限速也会如此，故属信息项）
#   光模块（用模块自带门限）
#     optics_tx/rx_out_of_range:[<low>..<high>]
#     optics_tx/rx_margin_low:<dB>   余量 < 2dB
#     optics_voltage/bias/temp_out_of_range
#     optics_fault:<位名>=<lanes>    per-lane 故障位非零
#     optics_module_fw_fault / optics_datapath_fw_fault / optics_los_alarm
#   IB 计数器（非零才输出）
#     见 _is_ib_error_counter() 白名单，共 12 项
#
# ----------------------------------------------------------------------------
# 关键实现约定
# ----------------------------------------------------------------------------
#   1) mlxlink 全脚本只调用一次。
#      `mlxlink -d <BDF> -m` 的输出是 bare 版本的【超集】——
#      前半是端口级诊断（Operational/Supported/Troubleshooting/Tool），
#      后半是 Module Info（光模块 DDM）。因此能力枚举 / 端口诊断 /
#      光模块三处共用同一次调用，结果缓存在 MLXLINK_RAW_CACHE（按 BDF）。
#
#   2) 计数器读到 4294967295 (0xFFFFFFFF) 一律跳过。
#      这是 32 位寄存器满量程的"无数据"哨兵值，不是真实计数。
#      mlx5 的 port_xmit_wait 恒为该值，故未纳入白名单。
#
#   3) 声明的判据必须先校验取值格式，再判异常。
#      例如 Status Opcode 必须是纯数字才判非 0；State 与 Physical state
#      必须都解析成功才下判断。否则字段没读全时会被误判成故障。
#
#   4) 已知未修复：is_ib_iface() 按 netdev type 筛选端口
#      （32=IB，1=ETHER），因此以太网模式的 mlx5 端口会被整行过滤掉。
#      后果是端口数少算，且上面的 link_layer 判据对这类口不会触发。
#      该行为属于全脚本既有设计（"只统计 IB 口"），修改会改变 CSV
#      行数语义，故保留现状，仅在此标注。
#
# 输出列（29 列）：
#   server_serial,ib_vendor,ib_model,ib_product,ib_serial,
#   ib_cap_speed_gb,ib_cur_speed_gb,ib_port_num,
#   ib_port_subnum,ib_firmware,ib_interface_name,ib_port_guid,
#   nic_pcie_bus_id,nic_port_pcie_bus_id,pcie_slot,
#   pcie_vendor_id,pcie_product_id,pcie_gen,pcie_link_cap,pcie_link_sta,
#   optics_vendor,optics_pn,optics_fw_ver,optics_rev,optics_sn,
#   optics_tx_power_mw,optics_rx_power_mw,optics_temperature_c,errors
# ============================================================================

# 不用 `set -e`，只保留 pipefail。
#
# 加 -e 的后果是：任何一条命令意外返回非 0，脚本立刻退出，而此时 CSV
# 可能只写了一部分 —— 文件看起来是正常生成的，只是行数少了。
# 现场很难发现，比直接报错危险得多。
#
# 本脚本要在各种半残环境里跑（无 root、无 mlxlink、无 ibstat、部分 sysfs
# 不可读），"某条命令失败"是常态而非异常，靠 -e 统一终止并不合适。
# 因此在真正需要中断的地方显式判断（见 collect_ib_info / main），
# 其余地方用 `|| true` 让单点失败降级为"该字段为空"。
#
# pipefail 让管道中间环节的失败仍影响整体状态。
set -o pipefail 2>/dev/null || true

SCRIPT_NAME=$(basename "$0")
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUTPUT_DIR="${OUTPUT_DIR:-${SCRIPT_DIR}/report}"
OUTPUT_FILE=""
SYSTEM_SERIAL=""
# 用户是否用 -s 显式指定了序列号。
# parse_args 会把 -s 的值写进 SYSTEM_SERIAL；本标志让 main 只在
# 用户没指定时才去自动探测，避免覆盖用户指定的值。
SERIAL_EXPLICIT=false
DEBUG="${DEBUG:-false}"

if [[ "$(id -u)" -eq 0 ]]; then SUDO=""; else SUDO="sudo"; fi

# ============================================================================
# 颜色变量（保护性定义）
# ============================================================================
if [[ -z "${RED:-}" ]]; then
    RED=$'\033[0;31m'
    GREEN=$'\033[0;32m'
    YELLOW=$'\033[1;33m'
    BLUE=$'\033[0;34m'
    NC=$'\033[0m'
    readonly RED GREEN YELLOW BLUE NC
fi

# ============================================================================
# 日志
# ============================================================================

log_info()  { echo -e "${GREEN}[INFO]${NC} $*" >&2; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC} $*" >&2; }
log_error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }
log_debug() {
    if [[ "${DEBUG}" == "true" ]]; then
        echo -e "${BLUE}[DEBUG]${NC} $*" >&2
    fi
}

print_separator() { echo "=========================================" >&2; }
print_header() {
    print_separator
    echo -e "${GREEN}$1${NC}" >&2
    print_separator
}

# ============================================================================
# CSV 转义 / 行输出
# ============================================================================

# 表头与列数是【唯一权威】。output_row 会拿这两个常量做自检，
# 所以必须定义在 output_row 之前。
readonly CSV_HEADER='server_serial,ib_vendor,ib_model,ib_product,ib_serial,ib_cap_speed_gb,ib_cur_speed_gb,ib_port_num,ib_port_subnum,ib_firmware,ib_interface_name,ib_port_guid,nic_pcie_bus_id,nic_port_pcie_bus_id,pcie_slot,pcie_vendor_id,pcie_product_id,pcie_gen,pcie_link_cap,pcie_link_sta,optics_vendor,optics_pn,optics_fw_ver,optics_rev,optics_sn,optics_tx_power_mw,optics_rx_power_mw,optics_temperature_c,errors'
readonly CSV_COLUMNS=29

csv_escape() {
    local field="$1"
    if [[ -z "$field" ]]; then
        printf ''
        return
    fi
    if [[ "$field" == *","* || "$field" == *"\""* || "$field" == *$'\n'* ]]; then
        field=$(printf '%s' "$field" | sed 's/"/""/g')
        printf '"%s"' "$field"
    else
        printf '%s' "$field"
    fi
}

# ----------------------------------------------------------------------------
# output_row：把各列值转义后拼成一行 CSV，并【强制校验列数】
#
# 实现要点：
#   纯参数展开做引号加倍，不为每个字段起一次 sed。
#      一次命令替换，29 列就是每行 29 次 fork。
#   2) 用【下标】而不是 `[[ -n "$out" ]]` 判断"是不是第一个字段"。
#      后者把"$out 非空"当成"已输出过字段"的代理，只有在前面所有字段
#      都非空时才成立。开头若有连续空字段：
#          ('','B','C') → 'B,C'    只剩 2 列（应为 3）
#          ('','','C')  → 'C'      只剩 1 列（应为 3）
#      空列连同分隔符一起被吞掉 → 静默错列。IB 数据里
#      ib_product / ib_serial / optics_* 在真机上确实会为空，
#      这条路径是可达的。
#   3) 拼完后再数一遍【真正的字段数】并断言，不匹配就报错并返回非 0。
#      只检查实参个数（$#）是不够的：传 29 个参数照样能拼出 28 列。
#
# 说明：csv_escape 仍会在"字段含逗号/引号/换行"时起一次 sed。IB 数据里
# 这种情况很少（型号名里偶尔有逗号），代价可忽略；绝大多数普通字段
# 不产生 fork。
# ----------------------------------------------------------------------------
output_row() {
    if [[ $# -ne $CSV_COLUMNS ]]; then
        log_error "内部错误: CSV 列数不匹配（期望 $CSV_COLUMNS，实际 $#）"
        return 1
    fi

    local out="" v i=0
    for v in "$@"; do
        if (( i > 0 )); then
            out+=",$(csv_escape "$v")"
        else
            out="$(csv_escape "$v")"
        fi
        i=$(( i + 1 ))
    done

    # 真正的列数自检：按 CSV 引号规则扫描，数出字段个数。
    # csv_escape 会给含逗号的字段加引号，所以不能简单数逗号。
    local _n=1 _q=0 _ch _k
    for (( _k = 0; _k < ${#out}; _k++ )); do
        _ch="${out:_k:1}"
        if [[ "$_ch" == '"' ]]; then
            # 连续两个 "" 是转义后的引号，不切换引号状态
            if [[ "${out:_k+1:1}" == '"' ]]; then
                _k=$(( _k + 1 ))
            else
                _q=$(( 1 - _q ))
            fi
        elif [[ "$_ch" == ',' && "$_q" -eq 0 ]]; then
            _n=$(( _n + 1 ))
        fi
    done

    if [[ "$_n" -ne "$CSV_COLUMNS" ]]; then
        log_error "内部错误: CSV 字段数不匹配（期望 $CSV_COLUMNS，实际 $_n）"
        return 1
    fi

    printf '%s\n' "$out"
    return 0
}

# ============================================================================
# 系统序列号
# ============================================================================

get_serial_from_dmidecode() {
    local serial=""
    serial=$($SUDO dmidecode -s system-serial-number 2>/dev/null | head -1)
    if [[ -n "$serial" ]] && [[ "$serial" != "Not Specified" ]] && [[ "$serial" != "Unknown" ]]; then
        echo "$serial"
        return 0
    fi
    return 1
}

get_serial_from_sysfs() {
    local serial=""
    if [[ -f "/sys/class/dmi/id/product_serial" ]]; then
        serial=$(cat /sys/class/dmi/id/product_serial 2>/dev/null)
        if [[ -n "$serial" ]] && [[ "$serial" != "Not Specified" ]]; then
            echo "$serial"
            return 0
        fi
    fi
    return 1
}

get_serial_from_hostid() {
    local serial=""
    serial=$(hostid 2>/dev/null)
    if [[ -n "$serial" ]] && [[ "$serial" != "00000000" ]]; then
        echo "$serial"
        return 0
    fi
    return 1
}

get_system_serial() {
    local serial=""
    local methods=(
        "get_serial_from_dmidecode"
        "get_serial_from_sysfs"
        "get_serial_from_hostid"
    )

    log_info "正在获取系统序列号..."

    for method in "${methods[@]}"; do
        if serial=$($method 2>/dev/null); then
            local method_name="${method#get_serial_from_}"
            log_info "通过 ${method_name} 获取到序列号: $serial"
            echo "$serial"
            return 0
        fi
    done

    log_warn "无法获取系统序列号，使用默认值: UNKNOWN"
    echo "UNKNOWN"
    return 1
}

# ============================================================================
# Vendor ID 映射
# ============================================================================

declare -A VENDOR_ID_MAP

init_vendor_id_map() {
    log_debug "初始化Vendor ID映射表..."
    VENDOR_ID_MAP["15b3"]="Mellanox"
    VENDOR_ID_MAP["1d22"]="BAIDU"
    VENDOR_ID_MAP["10b5"]="PLX"
    VENDOR_ID_MAP["1af4"]="Red Hat VirtIO"
    VENDOR_ID_MAP["1a6e"]="Amazon"
    VENDOR_ID_MAP["15ad"]="VMware"
    VENDOR_ID_MAP["1d6b"]="Linux Foundation"
    log_debug "Vendor ID映射表初始化完成，共 ${#VENDOR_ID_MAP[@]} 条映射"
}

# ============================================================================
# PCIe 派生信息
# ============================================================================

declare -A LSPCI_LNK_CACHE=()
declare -A LSPCI_VVV_CACHE=()
declare -A PCI_SLOT_MAP=()
declare -A PCIE_SLOT_CACHE=()
PCI_SLOT_MAP_LOADED=false

# 按数据来源拆分的两个光模块缓存，键的语义必须与来源一致：
#   MLXLINK_OPTICS_CACHE  键 = BDF        （mlxlink -d <BDF>）
#   ETHTOOL_OPTICS_CACHE  键 = 接口名      （ethtool -m <iface>）
declare -A MLXLINK_OPTICS_CACHE=()
declare -A ETHTOOL_OPTICS_CACHE=()
declare -A IB_CAP_SPEED_CACHE=()
# 端口级诊断缓存（键 = BDF）。端口诊断结果只取决于该 PCI 设备。
#   这张卡要跑好几次 mlxlink（能力枚举 + 光模块 + 端口诊断），
#   缓存避免重复调用（每次调用要读 HCA 寄存器，耗时数百 ms 到数秒）。
declare -A LINK_DIAG_CACHE=()

# mlxlink 原始输出缓存（键 = BDF）—— 一次调用，三处复用。
#
# `mlxlink -d <BDF> -m` 的输出是 bare 版本的超集：前半是端口级诊断
# （Operational / Troubleshooting 等），后半是 Module Info（光模块 DDM）。
# 所以能力枚举 / 光模块 / 端口诊断三处共用同一次调用。
#
# mlxlink 每次都要经 MST 驱动读 HCA 寄存器和 EEPROM，耗时可达数百 ms
# 到数秒，是脚本里最贵的操作。
#
# 空串表示"调用失败/无输出"，同样缓存，避免同一张卡被反复重试。
declare -A MLXLINK_RAW_CACHE=()

# 取（必要时执行一次）指定 BDF 的 mlxlink -m 原始输出。
# 失败返回 1，stdout 为空。
_mlxlink_raw() {
    local bdf="$1"
    [[ -z "$bdf" || "$bdf" == "N/A" || "$bdf" == "Unknown" ]] && return 1

    if [[ -n "${MLXLINK_RAW_CACHE[$bdf]+x}" ]]; then
        local cached="${MLXLINK_RAW_CACHE[$bdf]}"
        [[ -z "$cached" ]] && return 1
        printf '%s\n' "$cached"
        return 0
    fi

    local mlxlink_cmd
    mlxlink_cmd=$(command -v mlxlink 2>/dev/null || true)
    if [[ -z "$mlxlink_cmd" ]]; then
        MLXLINK_RAW_CACHE["$bdf"]=""
        return 1
    fi

    local out
    out=$($SUDO "$mlxlink_cmd" -d "$bdf" -m 2>/dev/null || true)

    # 只在确认是正常输出时才缓存内容；否则缓存空串（同样避免重复重试）
    if [[ -n "$out" ]] && echo "$out" | grep -q "Operational Info"; then
        MLXLINK_RAW_CACHE["$bdf"]="$out"
        printf '%s\n' "$out"
        return 0
    fi

    MLXLINK_RAW_CACHE["$bdf"]=""
    return 1
}

# 清空 mlxlink 相关缓存（供将来需要强制重读时使用；当前不调用）
reset_mlxlink_caches() {
    MLXLINK_RAW_CACHE=()
    IB_CAP_SPEED_CACHE=()
    MLXLINK_OPTICS_CACHE=()
    LINK_DIAG_CACHE=()
    return 0
}

normalize_pci_addr() {
    local a
    a=$(echo "$1" | tr 'A-F' 'a-f' | tr -d ' ')
    if [[ "$a" =~ ^([0-9a-f]+):([0-9a-f]{2}):([0-9a-f]{2})\.([0-9a-f])$ ]]; then
        local domain=$((16#${BASH_REMATCH[1]}))
        printf "%04x:%s:%s.%s" "$domain" "${BASH_REMATCH[2]}" "${BASH_REMATCH[3]}" "${BASH_REMATCH[4]}"
        return
    fi
    if [[ "$a" =~ ^([0-9a-f]{2}):([0-9a-f]{2})\.([0-9a-f])$ ]]; then
        printf "0000:%s:%s.%s" "${BASH_REMATCH[1]}" "${BASH_REMATCH[2]}" "${BASH_REMATCH[3]}"
        return
    fi
    echo "$a"
}

_normalize_dmi_addr() {
    local a
    a=$(echo "$1" | tr 'A-F' 'a-f' | tr -d ' ')
    [[ "$a" =~ ^([0-9a-f]{4}:[0-9a-f]{2}:[0-9a-f]{2})$ ]] && a="${a}.0"
    [[ "$a" =~ ^([0-9a-f]{2}:[0-9a-f]{2}:[0-9a-f]{2}\.[0-9a-f])$ ]] && a="0000:$a"
    echo "$a"
}

load_pci_slot_map() {
    [[ "$PCI_SLOT_MAP_LOADED" == "true" ]] && return
    PCI_SLOT_MAP_LOADED=true

    log_debug "加载 dmidecode -t slot..."
    local cur="" line
    while IFS= read -r line; do
        if [[ "$line" =~ Designation:[[:space:]]*(.+) ]]; then
            cur=$(echo "${BASH_REMATCH[1]}" | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
        fi
        if [[ "$line" =~ Bus[[:space:]]Address:[[:space:]]*([0-9a-fA-F:.]+) ]]; then
            local key; key=$(_normalize_dmi_addr "${BASH_REMATCH[1]}")
            [[ -n "$key" ]] && PCI_SLOT_MAP["$key"]="$cur"
        fi
    done < <($SUDO dmidecode -t slot 2>/dev/null)

    log_debug "PCI slot 表: ${#PCI_SLOT_MAP[@]} 条"
}

get_pcie_slot() {
    local bdf="$1"
    [[ -z "$bdf" || "$bdf" == "N/A" || "$bdf" == "Unknown" ]] && { echo "N/A"; return; }

    if [[ -n "${PCIE_SLOT_CACHE[$bdf]+x}" ]]; then
        echo "${PCIE_SLOT_CACHE[$bdf]}"; return
    fi

    bdf=$(echo "$bdf" | tr 'A-F' 'a-f')
    [[ "$bdf" =~ ^[0-9a-f]{2}:[0-9a-f]{2}\.[0-9a-f]$ ]] && bdf="0000:$bdf"

    local realpath; realpath=$(readlink -f "/sys/bus/pci/devices/$bdf" 2>/dev/null)
    if [[ -z "$realpath" ]]; then
        PCIE_SLOT_CACHE["$bdf"]="N/A"; echo "N/A"; return
    fi

    local chain; chain=$(echo "$realpath" | tr '/' '\n' \
        | grep -E '^[0-9a-f]{4}:[0-9a-f]{2}:[0-9a-f]{2}\.[0-9a-f]$' | tac)

    local p k bus kbus result="N/A"
    while IFS= read -r p; do
        [[ -n "${PCI_SLOT_MAP[$p]+x}" ]] && { result="${PCI_SLOT_MAP[$p]}"; break; }
    done <<< "$chain"

    if [[ "$result" == "N/A" ]]; then
        while IFS= read -r p; do
            bus=$(echo "$p" | cut -d':' -f2)
            for k in "${!PCI_SLOT_MAP[@]}"; do
                kbus=$(echo "$k" | cut -d':' -f2)
                if [[ "$bus" == "$kbus" ]]; then result="${PCI_SLOT_MAP[$k]}"; break 2; fi
            done
        done <<< "$chain"
    fi

    if [[ "$result" == "N/A" ]]; then
        local phys
        phys=$($SUDO lspci -s "$bdf" -vv 2>/dev/null \
            | grep -E "^[[:space:]]*Physical Slot:" | head -1 \
            | sed 's/.*Physical Slot:[[:space:]]*//')
        [[ -n "$phys" ]] && result="PhysicalSlot:${phys}"
    fi

    PCIE_SLOT_CACHE["$bdf"]="$result"
    echo "$result"
}

_get_lspci_vv() {
    local a="$1"
    [[ -z "$a" ]] && { echo ""; return; }
    local key; key=$(normalize_pci_addr "$a")
    [[ -n "${LSPCI_LNK_CACHE[$key]+x}" ]] && { echo "${LSPCI_LNK_CACHE[$key]}"; return; }
    local info
    info=$($SUDO lspci -s "$key" -vv 2>/dev/null || true)
    [[ -z "$info" ]] && info=$(lspci -s "$key" -vv 2>/dev/null || true)
    LSPCI_LNK_CACHE["$key"]="$info"
    echo "$info"
}

_get_lspci_vvv() {
    local a="$1"
    [[ -z "$a" ]] && { echo ""; return; }
    local key; key=$(normalize_pci_addr "$a")
    [[ -n "${LSPCI_VVV_CACHE[$key]+x}" ]] && { echo "${LSPCI_VVV_CACHE[$key]}"; return; }
    local info
    info=$($SUDO lspci -s "$key" -vvv 2>/dev/null || true)
    [[ -z "$info" ]] && info=$(lspci -s "$key" -vvv 2>/dev/null || true)
    LSPCI_VVV_CACHE["$key"]="$info"
    echo "$info"
}

gtps_to_pcie_ver() {
    case "$1" in
        "2.5GT/s") echo "PCIe 1.0" ;; "5GT/s")  echo "PCIe 2.0" ;;
        "8GT/s")   echo "PCIe 3.0" ;; "16GT/s") echo "PCIe 4.0" ;;
        "32GT/s")  echo "PCIe 5.0" ;; "64GT/s") echo "PCIe 6.0" ;;
        *)         echo "" ;;
    esac
}

get_pcie_gen() {
    local a="$1"
    [[ -z "$a" ]] && { echo "N/A"; return; }
    local info; info=$(_get_lspci_vv "$a")
    [[ -z "$info" ]] && { echo "N/A"; return; }
    local cap; cap=$(echo "$info" | grep -E "LnkCap:" | head -1 \
        | grep -oE 'Speed [0-9.]+GT/s' | head -1 | sed 's/Speed //')
    [[ -z "$cap" ]] && cap=$(echo "$info" | grep -E "LnkSta:" | head -1 \
        | grep -oE 'Speed [0-9.]+GT/s' | head -1 | sed 's/Speed //')
    [[ -z "$cap" ]] && { echo "N/A"; return; }
    local v; v=$(gtps_to_pcie_ver "$cap")
    [[ -z "$v" ]] && { echo "N/A"; return; }
    echo "$v"
}

get_pcie_link_cap() {
    local a="$1"
    [[ -z "$a" ]] && { echo "N/A"; return; }
    local info; info=$(_get_lspci_vv "$a")
    [[ -z "$info" ]] && { echo "N/A"; return; }
    local cap_line speed width
    cap_line=$(echo "$info" | grep -E "LnkCap:" | head -1)
    speed=$(echo "$cap_line" | grep -oE 'Speed [0-9.]+GT/s' | head -1 | sed 's/Speed //')
    width=$(echo "$cap_line" | grep -oE 'Width x[0-9]+' | head -1 | sed 's/Width //')
    if   [[ -n "$speed" && -n "$width" ]]; then echo "${speed} ${width}"
    elif [[ -n "$speed" ]]; then echo "$speed"
    elif [[ -n "$width" ]]; then echo "$width"
    else echo "N/A"; fi
}

get_pcie_link_sta() {
    local a="$1"
    [[ -z "$a" ]] && { echo "N/A"; return; }
    local info; info=$(_get_lspci_vv "$a")
    [[ -z "$info" ]] && { echo "N/A"; return; }
    local sta s ss w ws
    sta=$(echo "$info" | grep -E "LnkSta:" | head -1)
    s=$(echo "$sta" | grep -oE 'Speed [0-9.]+GT/s' | head -1 | sed 's/Speed //')
    ss=$(echo "$sta" | grep -oE 'Speed [0-9.]+GT/s \([^)]*\)' | head -1 | grep -oE '\([^)]*\)' | tr -d '()')
    [[ -z "$ss" ]] && ss="ok"
    w=$(echo "$sta" | grep -oE 'Width x[0-9]+' | head -1 | sed 's/Width //')
    ws=$(echo "$sta" | grep -oE 'Width x[0-9]+ \([^)]*\)' | head -1 | grep -oE '\([^)]*\)' | tr -d '()')
    [[ -z "$ws" ]] && ws="ok"
    local sstr="" wstr=""
    [[ -n "$s" ]] && sstr="${s} (${ss})"
    [[ -n "$w" ]] && wstr="${w} (${ws})"
    if   [[ -n "$sstr" && -n "$wstr" ]]; then echo "$sstr $wstr"
    elif [[ -n "$sstr" ]]; then echo "$sstr"
    elif [[ -n "$wstr" ]]; then echo "$wstr"
    else echo "N/A"; fi
}

get_pcie_vid() {
    local a="$1"
    [[ -z "$a" ]] && { echo "N/A"; return; }
    local k; k=$(normalize_pci_addr "$a")
    local f="/sys/bus/pci/devices/$k/vendor"
    if [[ -f "$f" ]]; then
        local v; v=$(cat "$f" 2>/dev/null); v="${v#0x}"; v="${v//[[:space:]]/}"
        [[ -n "$v" ]] && { echo "$v"; return; }
    fi
    echo "N/A"
}

get_pcie_pid() {
    local a="$1"
    [[ -z "$a" ]] && { echo "N/A"; return; }
    local k; k=$(normalize_pci_addr "$a")
    local f="/sys/bus/pci/devices/$k/device"
    if [[ -f "$f" ]]; then
        local v; v=$(cat "$f" 2>/dev/null); v="${v#0x}"; v="${v//[[:space:]]/}"
        [[ -n "$v" ]] && { echo "$v"; return; }
    fi
    echo "N/A"
}

# ============================================================================
# IB 接口判定（不依赖接口名）
# ============================================================================

is_ib_iface() {
    local iface="$1"
    [[ -z "$iface" ]] && return 1
    [[ -e "/sys/class/net/$iface" ]] || return 1

    local tfile="/sys/class/net/$iface/type"
    if [[ -r "$tfile" ]]; then
        local t
        t=$(cat "$tfile" 2>/dev/null | tr -d ' \n')
        if [[ -n "$t" ]]; then
            case "$t" in
                32) log_debug "  接口 $iface: type=32 (ARPHRD_INFINIBAND) → IB"; return 0 ;;
                1)  log_debug "  接口 $iface: type=1 (ARPHRD_ETHER) → 非 IB"; return 1 ;;
                772) log_debug "  接口 $iface: type=772 (ARPHRD_LOOPBACK) → 非 IB"; return 1 ;;
            esac
        fi
    fi

    if command -v ip &>/dev/null; then
        local ipout
        ipout=$(ip -o link show "$iface" 2>/dev/null)
        if [[ -n "$ipout" ]]; then
            if echo "$ipout" | grep -q 'link/infiniband'; then
                log_debug "  接口 $iface: ip link 显示 link/infiniband → IB"
                return 0
            fi
            if echo "$ipout" | grep -q 'link/ether'; then
                log_debug "  接口 $iface: ip link 显示 link/ether → 非 IB"
                return 1
            fi
        fi
    fi

    if [[ -d "/sys/class/net/$iface/device/infiniband" ]]; then
        log_debug "  接口 $iface: device/infiniband 目录存在 → IB"
        return 0
    fi

    log_debug "  接口 $iface: 不匹配任何 IB 判据 → 非 IB"
    return 1
}

_is_pci_desc_ib() {
    local pci_addr="$1"
    [[ -z "$pci_addr" ]] && return 1

    local desc
    desc=$(lspci -s "$pci_addr" 2>/dev/null | head -1)
    [[ -z "$desc" ]] && return 1

    if echo "$desc" | grep -qi "InfiniBand" && ! echo "$desc" | grep -qi "Ethernet"; then
        return 0
    fi
    return 1
}

is_virtual_function() {
    local iface="$1"
    local pci_addr="$2"

    # 判据顺序：内核事实优先，名字启发式最后。
    #
    # 名字判定是启发式。一个物理 PF 只要接口名恰好以 v<数字> 结尾
    # （或含 _v<数字> / -vf<数字>），就会被误判成 VF 并提前 return，
    # 于是走不到 sriov_numvfs 那一行 → 该口被 is_physical_ib_nic 过滤
    # → ib_port_num 少算 → CSV 缺行（静默少数据）。
    #
    # sriov_numvfs 的存在是内核给出的确凿事实（只有 PF 才有这个文件），
    # 确凿事实必须压在启发式之前。
    # （与 collect_nic_v2.sh 的顺序一致。）

    # ---- 1) physfn 符号链接：确凿的 VF 标志 ----
    if [[ -n "$pci_addr" ]]; then
        local physfn_link="/sys/bus/pci/devices/$pci_addr/physfn"
        if [[ -L "$physfn_link" ]]; then
            log_debug "IB设备 $iface (PCI: $pci_addr) 是VF (physfn 符号链接)"
            return 0
        fi
    fi

    # ---- 2) sriov_numvfs 文件：确凿的 PF 标志（必须早于名字判定）----
    # 与函数末尾的 return 1 结果相同，作用是短路：命中后跳过下面的
    # 名字正则和 lspci 调用，省一次 fork。
    if [[ -n "$pci_addr" ]]; then
        local sriov_file="/sys/bus/pci/devices/$pci_addr/sriov_numvfs"
        if [[ -f "$sriov_file" ]]; then
            log_debug "IB设备 $iface (PCI: $pci_addr) 是PF (存在 sriov_numvfs)"
            return 1
        fi
    fi

    # ---- 3) 接口名启发式（放在内核事实之后）----
    if [[ "$iface" =~ v[0-9]+$ ]] || [[ "$iface" =~ _v[0-9]+ ]] || [[ "$iface" =~ -vf[0-9]+ ]]; then
        log_debug "IB设备 $iface 是VF (接口名称匹配VF模式)"
        return 0
    fi

    # ---- 4) 设备路径含 virtfn/vf ----
    if [[ -L "/sys/class/net/$iface/device" ]]; then
        local dev_path
        dev_path=$(readlink -f "/sys/class/net/$iface/device" 2>/dev/null)
        if [[ -n "$dev_path" ]]; then
            if [[ "$dev_path" =~ virtfn[0-9]+ ]] || [[ "$dev_path" =~ /vf[0-9]+/ ]]; then
                log_debug "IB设备 $iface 是VF (设备路径含 virtfn 或 vf)"
                return 0
            fi
        fi
    fi

    # ---- 5) 最后才问 lspci ----
    if [[ -n "$pci_addr" ]]; then
        local pci_info
        pci_info=$($SUDO lspci -v -s "$pci_addr" 2>/dev/null || true)
        if echo "$pci_info" | grep -qi "Virtual Function"; then
            log_debug "IB设备 $iface 是VF (lspci 标记为 Virtual Function)"
            return 0
        fi
    fi

    return 1
}

is_physical_ib_nic() {
    local iface="$1"

    if [[ "$iface" == "lo" ]]; then
        return 1
    fi

    if [[ "$iface" =~ ^(veth|docker|br-|virbr|tun|tap|vnet|bond|dummy|sit|ip6tnl|gre|gretap|erspan) ]]; then
        return 1
    fi

    if [[ ! -L "/sys/class/net/$iface/device" ]]; then
        return 1
    fi

    if ! is_ib_iface "$iface"; then
        return 1
    fi

    local pci_addr=""
    if [[ -L "/sys/class/net/$iface/device" ]]; then
        pci_addr=$(basename "$(readlink -f "/sys/class/net/$iface/device")" 2>/dev/null)
    fi

    if is_virtual_function "$iface" "$pci_addr"; then
        return 1
    fi

    return 0
}

get_physical_ib_nics() {
    local nics=()
    local pf_count=0
    local vf_count=0
    local virtual_count=0

    log_info "正在扫描InfiniBand网卡并过滤Virtual Function (VF)..."

    # ★ 用 while + read 按行遍历，而不是 `for iface in $(ls ...)`。
    #   `$(ls)` 的结果会先做一次【词分割】（受 IFS 影响），接口名里若有
    #   空白就会被拆成两个不存在的名字；`ls` 本身还多起一个进程。
    #   接口名不可能含换行，所以按行读是安全的。
    local iface pci_addr
    while IFS= read -r iface; do
        [[ -z "$iface" ]] && continue
        if is_physical_ib_nic "$iface"; then
            nics+=("$iface")
            ((pf_count++)) || true
            log_debug "✅ 保留物理IB网卡: $iface"
        else
            if [[ -L "/sys/class/net/$iface/device" ]]; then
                pci_addr=$(basename "$(readlink -f "/sys/class/net/$iface/device")" 2>/dev/null)
                if [[ -n "$pci_addr" ]] && _is_pci_desc_ib "$pci_addr"; then
                    ((vf_count++)) || true
                    log_debug "⏭️  跳过IB VF网卡: $iface"
                else
                    ((virtual_count++)) || true
                fi
            else
                ((virtual_count++)) || true
            fi
        fi
    done < <(ls /sys/class/net/ 2>/dev/null)

    log_info "扫描完成: 物理IB网卡 ${#nics[@]} 个, IB VF网卡 ${vf_count} 个, 虚拟接口 ${virtual_count} 个"

    # 逐行输出，数组为空时一个字节都不输出 ——
    # 调用方因此可以安全地用 mapfile 按行读取，不依赖词分割。
    if [[ ${#nics[@]} -gt 0 ]]; then
        printf '%s\n' "${nics[@]}"
    fi
    return 0
}

# ============================================================================
# PCI Bus 相关
# ============================================================================

get_pci_bus_base() {
    local pci_addr="$1"
    local base=""

    if [[ -n "$pci_addr" ]]; then
        if [[ "$pci_addr" =~ ^([0-9a-fA-F]{2}:[0-9a-fA-F]{2})\.[0-9]+$ ]]; then
            base="${BASH_REMATCH[1]}"
        elif [[ "$pci_addr" =~ ^[0-9a-fA-F]{4}:([0-9a-fA-F]{2}:[0-9a-fA-F]{2})\.[0-9]+$ ]]; then
            base="${BASH_REMATCH[1]}"
        else
            base=$(echo "$pci_addr" | cut -d'.' -f1)
            if [[ "$base" =~ ^[0-9a-fA-F]{4}:(.+)$ ]]; then
                base="${BASH_REMATCH[1]}"
            fi
        fi
    fi

    echo "$base"
}

# 一次性建立 interface → bus_base 映射，供端口分组查表使用。
#
# get_ports_for_bus 若对每张卡都重扫全部接口，复杂度是 O(n^2)，
#   readlink -f + get_pci_bus_base，命中的再跑 is_ib_iface +
#   is_virtual_function（后者可能调 lspci）。复杂度 O(卡数 × 接口数)。
#   8 卡 × 32 口的机器上就是 256 次判定，其中不少是外部进程。
# 现在只遍历一次，降到 O(接口数)。
#
# 这里刻意用【全局关联数组】而不是 nameref（local -n）传引用：
#   nameref 需要 bash 4.3+，而 CentOS 7 自带的是 bash 4.2。
#   本脚本已用 declare -A（bash 4.0 即可），保持在 4.2 能跑。
declare -A IFACE_BUS_MAP=()

build_iface_bus_map() {
    IFACE_BUS_MAP=()

    local nic pci
    while IFS= read -r nic; do
        [[ -z "$nic" ]] && continue
        [[ -L "/sys/class/net/$nic/device" ]] || continue

        pci=$(get_pci_address "$nic")
        [[ -z "$pci" ]] && continue

        # 必须用与主流程同一套判据（is_physical_ib_nic），不要另写一套弱的。
        # 否则只要有一个"有 device 链接但不是物理 IB 口"的接口落在同一 bus
        # （如带 device 链接的 bond/网桥、smartNIC 的 representor 口），
        # 端口数就会虚高。判据统一后 IFACE_BUS_MAP 与 nics[] 才是同一集合。
        is_physical_ib_nic "$nic" || continue

        IFACE_BUS_MAP["$nic"]="$(get_pci_bus_base "$pci")"
    done < <(ls /sys/class/net/ 2>/dev/null)

    log_debug "接口→bus 映射: ${#IFACE_BUS_MAP[@]} 条"
    return 0
}

get_ports_for_bus() {
    local bus_base="$1"
    local ports=()

    if [[ -n "$bus_base" ]]; then
        # 查表，不再重扫全部接口
        local nic
        for nic in "${!IFACE_BUS_MAP[@]}"; do
            [[ "${IFACE_BUS_MAP[$nic]}" == "$bus_base" ]] && ports+=("$nic")
        done
    fi

    # 排序：端口顺序必须稳定，否则同一台机器两次跑出来的
    # ib_port_subnum 会对不上，跟历史 CSV 也没法比对。
    if [[ ${#ports[@]} -gt 1 ]]; then
        local sorted
        sorted=$(printf '%s\n' "${ports[@]}" | sort)
        mapfile -t ports <<< "$sorted"
    fi

    # 逐行输出（空数组时零字节），调用方用 mapfile 读，不依赖词分割。
    if [[ ${#ports[@]} -gt 0 ]]; then
        printf '%s\n' "${ports[@]}"
    fi
    return 0
}

# ============================================================================
# IB 设备名称 / 端口号
# ============================================================================

get_ib_device_name() {
    local iface="$1"
    local ib_device=""

    if [[ -L "/sys/class/net/$iface" ]]; then
        local link_path
        link_path=$(readlink -f "/sys/class/net/$iface" 2>/dev/null)
        if [[ -n "$link_path" ]]; then
            ib_device=$(echo "$link_path" | grep -oE 'infiniband/[^/]+' | cut -d'/' -f2)
            if [[ -n "$ib_device" ]]; then
                echo "$ib_device"
                return
            fi
        fi
    fi

    if [[ -d "/sys/class/net/$iface/device/infiniband" ]]; then
        ib_device=$(ls /sys/class/net/$iface/device/infiniband/ 2>/dev/null | head -1)
        if [[ -n "$ib_device" ]]; then
            echo "$ib_device"
            return
        fi
    fi

    echo ""
}

# 按 PCI 地址反查 IB 设备名（找不到返回空）。
#
# 以太网模式的 mlx5 端口，netdev 路径里不一定出现 infiniband/<dev>，
# 此时用 BDF 扫 /sys/class/infiniband/*/device 反查，作为兜底。
get_ib_device_by_bdf() {
    local bdf="$1"
    [[ -z "$bdf" || "$bdf" == "N/A" || "$bdf" == "Unknown" ]] && { echo ""; return 0; }

    local want
    want=$(normalize_pci_addr "$bdf")

    local d dev target
    for d in /sys/class/infiniband/*; do
        [[ -d "$d" ]] || continue
        [[ -L "$d/device" ]] || continue
        target=$(basename "$(readlink -f "$d/device" 2>/dev/null)" 2>/dev/null)
        [[ -z "$target" ]] && continue
        if [[ "$(normalize_pci_addr "$target")" == "$want" ]]; then
            basename "$d"
            return 0
        fi
    done

    echo ""
    return 0
}

get_ib_port_number() {
    local iface="$1"
    local port_num=""

    # 这个函数的值被拿去拼 sysfs 路径，猜错就会静默串数据：
    #   /sys/class/infiniband/$dev/ports/$port_num/{rate,counters,gids/0}
    # 返回错误的端口号时，速率/计数/GUID 会全部来自另一个口，
    # 而且看不出异常 —— 数字是真的，只是属于别的口。
    #
    # 因此不用任何兜底猜测，可靠判据走完仍无法确定时返回空串。
    # 空值会让调用方拼出 .../ports//rate（不存在）→ 拿到 N/A，
    # 而不是悄悄返回别的口的数据。宁可缺数据，不要错数据。

    # ---- 1) device/port（传统 mlx4 路径）----
    if [[ -f "/sys/class/net/$iface/device/port" ]]; then
        port_num=$(cat "/sys/class/net/$iface/device/port" 2>/dev/null | tr -d ' \n')
        if [[ "$port_num" =~ ^[0-9]+$ ]]; then
            echo "$port_num"
            return 0
        fi
    fi

    # ---- 2) 用 ndevs 反查：最可靠，直接回答"这个 netdev 是哪个 IB 端口" ----
    local ib_device
    ib_device=$(get_ib_device_name "$iface")
    if [[ -n "$ib_device" ]]; then
        local ports_dir="/sys/class/infiniband/$ib_device/ports"
        if [[ -d "$ports_dir" ]]; then
            local p ndev_file ndev
            for p in "$ports_dir"/*; do
                [[ -d "$p" ]] || continue
                ndev_file="$p/gid_attrs/ndevs/0"
                if [[ -f "$ndev_file" ]]; then
                    ndev=$(cat "$ndev_file" 2>/dev/null | tr -d ' \n')
                    if [[ "$ndev" == "$iface" ]]; then
                        echo "$(basename "$p")"
                        return 0
                    fi
                fi
            done
        fi
    fi

    # ---- 3) device/infiniband 下有多口时可判定；单口直接就是 1 ----
    if [[ -d "/sys/class/net/$iface/device/infiniband" ]] && [[ -n "$ib_device" ]]; then
        local ports_dir2="/sys/class/infiniband/$ib_device/ports"
        local n=0 q
        if [[ -d "$ports_dir2" ]]; then
            for q in "$ports_dir2"/*; do
                [[ -d "$q" ]] && n=$(( n + 1 ))
            done
        fi
        if [[ "$n" -eq 1 ]]; then
            echo "1"
            return 0
        fi
    fi

    # ---- 4) 无法确定：返回空，让调用方拿到"缺数据"而不是"错数据" ----
    log_debug "  无法确定 $iface 的 IB 端口号（多口卡且 ndevs 不可用），相关字段将留空"
    echo ""
    return 1
}

# ============================================================================
# IB 信息字段获取
# ============================================================================

get_pci_address() {
    local iface="$1"
    local pci_addr=""

    if [[ -L "/sys/class/net/$iface/device" ]]; then
        pci_addr=$(basename "$(readlink -f "/sys/class/net/$iface/device")" 2>/dev/null)
    fi

    echo "$pci_addr"
}

get_ib_vendor() {
    local pci_addr="$1"
    local vendor=""

    if [[ -n "$pci_addr" ]]; then
        local norm
        norm=$(normalize_pci_addr "$pci_addr")
        local vendor_file="/sys/bus/pci/devices/$norm/vendor"
        if [[ -f "$vendor_file" ]]; then
            local vendor_id
            vendor_id=$(cat "$vendor_file" 2>/dev/null | sed 's/^0x//' | tr -d ' \n')
            if [[ -n "${VENDOR_ID_MAP[$vendor_id]}" ]]; then
                vendor="${VENDOR_ID_MAP[$vendor_id]}"
            fi
        fi
    fi

    echo "${vendor:-UNKNOWN}"
}

get_ib_model() {
    local pci_addr="$1"
    local model=""

    if [[ -n "$pci_addr" ]]; then
        local pci_info
        pci_info=$(_get_lspci_vvv "$pci_addr")

        local subsystem_line
        subsystem_line=$(echo "$pci_info" | grep -i "^[[:space:]]*Subsystem:" | head -1)
        if [[ -n "$subsystem_line" ]]; then
            model=$(echo "$subsystem_line" | sed 's/^[[:space:]]*Subsystem:[[:space:]]*//' | sed 's/[[:space:]]*$//')
            if [[ -n "$model" ]]; then
                log_debug "从Subsystem获取到IB型号: $model"
                echo "$model"
                return
            fi
        fi
    fi

    if [[ -n "$pci_addr" ]]; then
        local pci_name
        pci_name=$(lspci -s "$pci_addr" 2>/dev/null | head -1)
        if [[ -n "$pci_name" ]]; then
            model=$(echo "$pci_name" | awk -F': ' '{print $2}')
            if [[ -n "$model" ]]; then
                log_debug "从设备名称获取到IB型号: $model"
                echo "$model"
                return
            fi
        fi
    fi

    echo "UNKNOWN"
}

get_ib_product() {
    local pci_addr="$1"
    local product=""

    if [[ -n "$pci_addr" ]]; then
        local pci_info
        pci_info=$(_get_lspci_vvv "$pci_addr")
        product=$(echo "$pci_info" | grep -i "\[PN\]" | head -1 \
            | sed 's/.*\[PN\]//' \
            | sed 's/^[[:space:]]*//;s/[[:space:]]*$//' \
            | sed 's/^Part number:[[:space:]]*//')
        if [[ -n "$product" ]]; then
            echo "$product"
            return
        fi
    fi

    echo "N/A"
}

get_ib_serial() {
    local pci_addr="$1"
    local serial=""

    if [[ -n "$pci_addr" ]]; then
        local pci_info
        pci_info=$(_get_lspci_vvv "$pci_addr")
        serial=$(echo "$pci_info" | grep -i "\[SN\]" | head -1 \
            | sed 's/.*\[SN\]//' \
            | sed 's/^[[:space:]]*//;s/[[:space:]]*$//' \
            | sed 's/^Serial number:[[:space:]]*//')
        if [[ -n "$serial" ]]; then
            echo "$serial"
            return
        fi
    fi

    echo "N/A"
}

# ============================================================================
# HCA 支持的 IB 最高速率
#
#   从 mlxlink -d <bdf> -m 的 "Enabled Link Speed" 行解析。
#   该行形如：Enabled Link Speed : 0x00000075 (HDR,EDR,FDR,QDR,SDR)
#   括号内是枚举名，优先级（高→低）：
#     XDR=800  NDR=400  HDR=200  EDR=100
#     FDR10=40 FDR=56   QDR=40   DDR=20  SDR=10
#   注意：FDR10 要放在 FDR 前匹配。
# ============================================================================

_ib_cap_from_mlxlink_output() {
    local out="$1"
    [[ -z "$out" ]] && { echo "N/A"; return; }

    local line
    line=$(echo "$out" | grep -E "^[[:space:]]*Enabled Link Speed" | head -1)
    [[ -z "$line" ]] && { echo "N/A"; return; }

    if echo "$line" | grep -qi "XDR";   then echo "800"; return; fi
    if echo "$line" | grep -qi "NDR";   then echo "400"; return; fi
    if echo "$line" | grep -qi "HDR";   then echo "200"; return; fi
    if echo "$line" | grep -qi "EDR";   then echo "100"; return; fi
    if echo "$line" | grep -qi "FDR10"; then echo "40";  return; fi
    if echo "$line" | grep -qi "FDR";   then echo "56";  return; fi
    if echo "$line" | grep -qi "QDR";   then echo "40";  return; fi
    if echo "$line" | grep -qi "DDR";   then echo "20";  return; fi
    if echo "$line" | grep -qi "SDR";   then echo "10";  return; fi

    echo "N/A"
}

get_ib_cap_speed_gb() {
    local bdf="$1"
    [[ -z "$bdf" || "$bdf" == "N/A" || "$bdf" == "Unknown" ]] && { echo "N/A"; return; }

    local cache_key="$bdf"
    if [[ -n "${IB_CAP_SPEED_CACHE[$cache_key]+x}" ]]; then
        echo "${IB_CAP_SPEED_CACHE[$cache_key]}"
        return
    fi

    local result="N/A"

    # 复用 _mlxlink_raw 的共享缓存，取 "Enabled Link Speed" 字段。
    local mlx_out
    if mlx_out=$(_mlxlink_raw "$bdf"); then
        result=$(_ib_cap_from_mlxlink_output "$mlx_out")
    else
        log_debug "  ib_cap_speed_gb: mlxlink 未安装或无输出，无法获取 HCA 能力"
    fi

    IB_CAP_SPEED_CACHE["$cache_key"]="$result"
    echo "$result"
}

# ============================================================================
# 当前协商速率
# ============================================================================

get_ib_cur_speed_gb() {
    local iface="$1"
    local speed=""

    local ib_device
    ib_device=$(get_ib_device_name "$iface")
    if [[ -n "$ib_device" ]] && command -v ibstat &>/dev/null; then
        local port_num
        port_num=$(get_ib_port_number "$iface")
        local ibstat_output
        ibstat_output=$(ibstat "$ib_device" "$port_num" 2>/dev/null)
        if [[ -n "$ibstat_output" ]]; then
            speed=$(echo "$ibstat_output" | grep -i "^[[:space:]]*Rate:" | head -1 | awk -F': ' '{print $2}' | awk '{print $1}')
            if [[ -n "$speed" ]] && [[ "$speed" =~ ^[0-9]+$ ]]; then
                echo "$speed"
                return
            fi
        fi
    fi

    if [[ -n "$ib_device" ]]; then
        local port_num
        port_num=$(get_ib_port_number "$iface")
        local rate_file="/sys/class/infiniband/$ib_device/ports/$port_num/rate"
        if [[ -f "$rate_file" ]]; then
            speed=$(cat "$rate_file" 2>/dev/null | awk '{print $1}')
            if [[ -n "$speed" ]] && [[ "$speed" =~ ^[0-9]+$ ]]; then
                echo "$speed"
                return
            fi
        fi
    fi

    if command -v ethtool &>/dev/null; then
        local current_speed
        current_speed=$($SUDO ethtool "$iface" 2>/dev/null | grep -i "speed" | awk '{print $2}')
        if [[ -n "$current_speed" ]] && [[ "$current_speed" != "Unknown!" ]] && [[ "$current_speed" != "Speed:" ]]; then
            speed=$(echo "$current_speed" | sed 's/Mb\/s//' | sed 's/mb\/s//' | tr -d ' ')
            if [[ -n "$speed" ]] && [[ "$speed" =~ ^[0-9]+$ ]]; then
                if [[ "$speed" -ge 1000 ]]; then
                    speed=$((speed / 1000))
                fi
                echo "$speed"
                return
            fi
        fi
    fi

    echo "0"
}

get_ib_firmware() {
    local iface="$1"
    local firmware=""

    local ib_device
    ib_device=$(get_ib_device_name "$iface")
    if [[ -n "$ib_device" ]] && command -v ibstat &>/dev/null; then
        firmware=$(ibstat "$ib_device" 2>/dev/null | grep -i "Firmware version" | head -1 | awk -F': ' '{print $2}')
        if [[ -n "$firmware" ]]; then
            echo "$firmware"
            return
        fi
    fi

    if [[ -n "$ib_device" ]]; then
        local fw_file="/sys/class/infiniband/$ib_device/fw_ver"
        if [[ -f "$fw_file" ]]; then
            firmware=$(cat "$fw_file" 2>/dev/null)
            if [[ -n "$firmware" ]]; then
                echo "$firmware"
                return
            fi
        fi
    fi

    local pci_addr
    pci_addr=$(get_pci_address "$iface")
    if [[ -n "$pci_addr" ]]; then
        local pci_info
        pci_info=$(_get_lspci_vvv "$pci_addr")
        firmware=$(echo "$pci_info" | grep -i "\[FW\]" | head -1 | sed 's/.*\[FW\]//' | sed 's/^[[:space:]]*//' | sed 's/[[:space:]]*$//')
        if [[ -n "$firmware" ]]; then
            echo "$firmware"
            return
        fi
    fi

    echo "N/A"
}

get_ib_interface_name() {
    local iface="$1"
    echo "$iface"
}

# ----------------------------------------------------------------------------
# 把 GID 归一化成 64 位 Port GUID："0x" + 16 位小写十六进制。
#
# 两个数据源格式不同：
#   ibstat 分支  → Port GUID，形如 0x946dae030072d3f6               (64bit)
#   gids/0 分支  → GID，形如 fe80:0000:...:946d:ae03:0072:d3f6    (128bit)
#
# GID = [子网前缀 64bit][GUID 64bit]，IB 规范里 link-local GID 的默认
# 格式是 fe80:: + GUID，所以 GID 的后 64 位才是 Port GUID。
#
# 不归一化会导致同一列两种长度（18 / 39 字符）、两种含义，
# 两行数据不可比，按固定宽度解析还会错位。
#
# 输入为空/无法识别时返回空串（由调用方决定填 N/A）。
# ----------------------------------------------------------------------------
_normalize_port_guid() {
    local raw="$1"
    [[ -z "$raw" ]] && { echo ""; return; }

    local orig="$raw"

    # 去掉空白，统一小写，去 0x 前缀
    raw="${raw//[[:space:]]/}"
    raw="${raw,,}"
    raw="${raw#0x}"

    local hex=""

    if [[ "$raw" == *:* ]]; then
        # ---- 冒号分隔形式 ----
        # ★ 必须先处理 IPv6 的 "::" 缩写 ★
        #   "fe80::946d:ae03:0072:d3f6" 这种写法里 "::" 代表
        #   【一组或多组全 0】，直接按 ':' 切分会得到空元素，
        #   拼出来的长度是 24 而不是 32，于是归一化失败、
        #   原样返回 —— 而 gids/0 恰恰经常是这个格式。
        #   所以这里把 "::" 先展开成足够数量的 ":0"。
        local left="" right="" n_left=0 n_right=0
        if [[ "$raw" == *"::"* ]]; then
            left="${raw%%::*}"
            right="${raw#*::}"
            # 数一数两边各有多少组
            if [[ -n "$left" ]]; then
                n_left=$(awk -v s="$left" 'BEGIN{ n=split(s,a,":"); print n }')
            fi
            if [[ -n "$right" ]]; then
                n_right=$(awk -v s="$right" 'BEGIN{ n=split(s,a,":"); print n }')
            fi
            local missing=$(( 8 - n_left - n_right ))
            [[ $missing -lt 0 ]] && missing=0
            local fill="" i
            for (( i = 0; i < missing; i++ )); do
                fill+=":0"
            done
            raw="${left}${fill}:${right}"
            # 处理 "::" 在首/尾导致的前后多余冒号
            raw="${raw#:}"
            raw="${raw%:}"
        fi

        local parts
        IFS=':' read -r -a parts <<< "$raw"
        local joined=""
        local p
        for p in "${parts[@]}"; do
            [[ -z "$p" ]] && continue
            # 补足每组 4 位（"ae03"→"ae03"，"0"→"0000"）
            while [[ ${#p} -lt 4 ]]; do p="0${p}"; done
            joined+="$p"
        done
        hex="$joined"
    else
        hex="$raw"
    fi

    # 只保留十六进制字符
    hex="${hex//[^0-9a-f]/}"

    # 32 位十六进制 = 128bit GID → 取后 16 位（后 64bit = Port GUID）
    if [[ ${#hex} -eq 32 ]]; then
        hex="${hex:16:16}"
    fi

    if [[ ${#hex} -eq 16 ]]; then
        echo "0x${hex}"
    else
        # 长度异常：不猜，交回原始值（至少不丢信息）
        echo "$orig"
    fi
}

get_ib_port_guid() {
    local iface="$1"
    local port_guid=""

    local ib_device
    ib_device=$(get_ib_device_name "$iface")

    # ★ 端口号只解析一次 ★
    # 注意：两个分支不要各调一次 get_ib_port_number，
    #   遍历 sysfs 甚至跑 ibstat，重复调用纯属浪费。
    local port_num=""
    if [[ -n "$ib_device" ]]; then
        port_num=$(get_ib_port_number "$iface")
    fi

    # ---- 1) ibstat：首选，直接给 Port GUID ----
    if [[ -n "$ib_device" ]] && command -v ibstat &>/dev/null; then
        local ibstat_output
        ibstat_output=$(ibstat "$ib_device" "$port_num" 2>/dev/null)
        if [[ -n "$ibstat_output" ]]; then
            port_guid=$(echo "$ibstat_output" | grep -i "Port GUID" | head -1 \
                        | sed 's/^[^:]*:[[:space:]]*//' | sed 's/[[:space:]]*$//')
            if [[ -n "$port_guid" ]]; then
                echo "$(_normalize_port_guid "$port_guid")"
                return 0
            fi
        fi
    fi

    # ---- 2) sysfs：回退。注意 gids/0 给的是【GID】，需取后 64 位 ----
    #
    # ★ 优先 node_guid 而不是 gids/0 ★
    #   /sys/class/infiniband/<dev>/node_guid 是节点 GUID（64bit），
    #   格式与 ibstat 的 Port GUID 一致，比从 GID 里截取更直接、
    #   不依赖 GID 的格式假设。单口卡上 node_guid == port_guid。
    #   多口卡上两者可能不同，此时才退回 gids/0 取后 64 位。
    if [[ -n "$ib_device" && -n "$port_num" ]]; then
        local gid_file="/sys/class/infiniband/$ib_device/ports/$port_num/gids/0"
        if [[ -f "$gid_file" ]]; then
            port_guid=$(cat "$gid_file" 2>/dev/null)
            if [[ -n "$port_guid" ]]; then
                echo "$(_normalize_port_guid "$port_guid")"
                return 0
            fi
        fi
    fi

    echo "N/A"
    return 1
}

# ============================================================================
# IB 错误计数
# ============================================================================

# ----------------------------------------------------------------------------
# 端口级健康检查：链路类型 / state / phys_state（读 sysfs，几乎零成本）
#
# 输出：link_layer:eth / ib_state:Down / ib_phys_state:Polling /
#       ib_state_phys_mismatch:Active/Polling；空串表示正常。
#
# ① link_layer != InfiniBand（最高优先级）
#    ConnectX-6 支持 IB/ETH 双模。以太网模式下速率/GUID/端口号仍会正常
#    输出，但整行数据其实来自一个以太网口 —— 属"来源不合法"，
#    会静默污染整份 IB 报表。
#
# ② state 未到 Active(4)
#    取值 1 Down / 2 Initialize / 3 Armed / 4 Active
#
# ③ state=Active 但 phys_state != LinkUp(5)
#    取值 1 Sleep / 2 Polling / 3 Disabled / 4 PortConfigurationTraining
#         5 LinkUp / 6 LinkErrorRecovery / 7 Phy Test
#
# sysfs 格式为 "<num>: <NAME>"，解析时优先取名字，取不到再比较数字。
#
# ⚠️ 已知限制：is_ib_iface() 按 netdev type 筛选端口（32=IB，1=ETHER），
#    以太网模式的 mlx5 端口会被整行过滤掉，因此判据 ① 对这类口不会触发。
#    这是全脚本既有设计（"只统计 IB 口"），修改会改变 CSV 行数语义，
#    故未改动。BDF 兜底见下方 get_ib_device_by_bdf。
# ----------------------------------------------------------------------------
get_link_diag() {
    local iface="$1"
    local bdf="${2:-}"

    local ib_device port_num
    ib_device=$(get_ib_device_name "$iface")
    # ★ BDF 兜底：以太网模式下 netdev 路径可能不含 infiniband/<dev>，
    #   此时用 PCI 地址反查，避免 link_layer 检查静默失效。
    if [[ -z "$ib_device" && -n "$bdf" ]]; then
        ib_device=$(get_ib_device_by_bdf "$bdf")
        [[ -n "$ib_device" ]] && log_debug "  $iface: 经 BDF $bdf 反查到 IB 设备 $ib_device"
    fi
    [[ -z "$ib_device" ]] && { echo ""; return 0; }
    port_num=$(get_ib_port_number "$iface")
    [[ -z "$port_num" ]] && { echo ""; return 0; }

    local pdir="/sys/class/infiniband/$ib_device/ports/$port_num"
    [[ -d "$pdir" ]] || { echo ""; return 0; }

    local result=""

    # ---- ① link_layer ----
    local ll=""
    if [[ -f "$pdir/link_layer" ]]; then
        ll=$(cat "$pdir/link_layer" 2>/dev/null)
        ll="${ll//[[:space:]]/}"
        # 只在【不是 InfiniBand】时才报告。
        # 注意大小写与可能的取值差异，统一转小写比较。
        if [[ -n "$ll" && "${ll,,}" != "infiniband" ]]; then
            result="link_layer:${ll}"
        fi
    fi

    # ---- ② state ----
    local st="" st_num="" st_name=""
    if [[ -f "$pdir/state" ]]; then
        st=$(cat "$pdir/state" 2>/dev/null)
        st="${st//[[:space:]]/}"
        # 形如 "4: ACTIVE"；取数字与名字
        if [[ "$st" =~ ^([0-9]+):[[:space:]]*(.+)$ ]]; then
            st_num="${BASH_REMATCH[1]}"
            st_name="${BASH_REMATCH[2]}"
        elif [[ "$st" =~ ^[0-9]+$ ]]; then
            st_num="$st"
        fi
        # Active == 4。只报【不是 4】的情况。
        if [[ -n "$st_num" && "$st_num" != "4" ]]; then
            result="${result:+$result;}ib_state:${st_name:-$st_num}"
        fi
    fi

    # ---- ③ phys_state ----
    local ps="" ps_num="" ps_name=""
    if [[ -f "$pdir/phys_state" ]]; then
        ps=$(cat "$pdir/phys_state" 2>/dev/null)
        ps="${ps//[[:space:]]/}"
        if [[ "$ps" =~ ^([0-9]+):[[:space:]]*(.+)$ ]]; then
            ps_num="${BASH_REMATCH[1]}"
            ps_name="${BASH_REMATCH[2]}"
        elif [[ "$ps" =~ ^[0-9]+$ ]]; then
            ps_num="$ps"
        fi
    fi

    # 物理层异常：只要 phys_state 有值且不是 LinkUp(5) 就值得记录，
    # 因为"Active 却不在 LinkUp"是最典型的异常组合。
    if [[ -n "$ps_num" && "$ps_num" != "5" ]]; then
        # 若 state 也不是 Active，那 ② 已经报过了，这里只补充物理层详情；
        # 若 state 是 Active 而物理层异常，则额外标注这个矛盾。
        if [[ -n "$st_num" && "$st_num" == "4" ]]; then
            result="${result:+$result;}ib_state_phys_mismatch:${st_name:-4}/${ps_name:-$ps_num}"
        else
            result="${result:+$result;}ib_phys_state:${ps_name:-$ps_num}"
        fi
    fi

    echo "$result"
    return 0
}

# ----------------------------------------------------------------------------
# 端口级 mlxlink 诊断（复用 _mlxlink_raw 的共享缓存）
#
# 输出：alerts（分号分隔，空串 = 无异常）
#   loopback:<mode>            非 "No Loopback" 即异常
#   mlxlink_status:<opcode>    Status Opcode 非 0（须为纯数字）
#   mlxlink_autoneg:OFF        协商关闭
#   mlxlink_state:<s>/<p>      State 非 Active（需 s 与 p 都读到）
#   mlxlink_phys_state:<p>     Physical state 非 LinkUp
#
# 缓存的原始文本里含有 Operational / Supported / Troubleshooting / Tool
# Information 四段，可解析：State / Physical state / Loopback Mode /
# Auto Negotiation / Status Opcode。没有 BER / SNR / 链路计数器，
# 那些需要 amBER 等专门子命令，本脚本不采集。
#
# 缓存：按 BDF 缓存解析结果（原始文本由 MLXLINK_RAW_CACHE 缓存）。
# ----------------------------------------------------------------------------
get_link_diag_mlxlink() {
    local bdf="$1"
    [[ -z "$bdf" || "$bdf" == "N/A" || "$bdf" == "Unknown" ]] && { echo ""; return 0; }

    if [[ -n "${LINK_DIAG_CACHE[$bdf]+x}" ]]; then
        echo "${LINK_DIAG_CACHE[$bdf]}"
        return 0
    fi

    local out
    if ! out=$(_mlxlink_raw "$bdf"); then
        LINK_DIAG_CACHE["$bdf"]=""
        echo ""
        return 0
    fi

    # 只在确实是 mlxlink 的正常输出时才继续（防止把报错文本当数据）
    if ! echo "$out" | grep -q "Operational Info"; then
        LINK_DIAG_CACHE["$bdf"]=""
        echo ""
        return 0
    fi

    # 单次遍历取全部字段
    local state="" phys="" loopback="" autoneg="" opcode=""
    local line key val
    while IFS= read -r line; do
        [[ "$line" == *:* ]] || continue
        key="${line%%:*}"
        val="${line#*:}"
        key="${key#"${key%%[![:space:]]*}"}"
        key="${key%"${key##*[![:space:]]}"}"
        val="${val#"${val%%[![:space:]]*}"}"
        val="${val%"${val##*[![:space:]]}"}"
        case "$key" in
            "State")            state="$val" ;;
            "Physical state")   phys="$val" ;;
            "Loopback Mode")    loopback="$val" ;;
            "Auto Negotiation") autoneg="$val" ;;
            "Status Opcode")    opcode="$val" ;;
        esac
    done <<< "$out"

    local alerts=""

    # 下面三个字段都遵循同一条约定：
    #   先校验取值格式/完整性，只有确实读到已知的异常取值才报告。
    #   直接把字段值和期望值比较的话，字段没被完整捕获（空串或混入
    #   不可见字符）时就会落到"异常"分支，从而误报。
    #   本脚本总原则：读不到 ≠ 有问题。

    # ① Loopback：非 "No Loopback" 说明端口被置于环回模式 ——
    #    此时链路"看起来通"，但根本没连到对端，是测试态而非生产态。
    #    用正向识别（_mlxlink_is_loopback）只认已知的环回模式名。
    if [[ -n "$loopback" ]] && _mlxlink_is_loopback "$loopback"; then
        alerts="${alerts:+$alerts;}loopback:${loopback// /_}"
    fi

    # ② Status Opcode：非 0 表示 mlxlink 自身判定有异常，
    #    配合 Recommendation 一起看最有价值。
    #    要求是纯数字，避免字段混入不可见字符时误报。
    if [[ "$opcode" =~ ^[0-9]+$ ]] && [[ "$opcode" -ne 0 ]]; then
        alerts="${alerts:+$alerts;}mlxlink_status:${opcode}"
    fi

    # ③ Auto Negotiation 关闭：IB 链路理应开启协商
    if [[ "${autoneg^^}" == "OFF" ]]; then
        alerts="${alerts:+$alerts;}mlxlink_autoneg:OFF"
    fi

    # ④ State / Physical state 异常
    #    两个字段必须都解析成功才下判断 —— 只读到一个说明没读全，
    #    不足以断言端口异常。
    if [[ -n "$state" && -n "$phys" ]]; then
        if [[ "${state,,}" != "active" ]]; then
            alerts="${alerts:+$alerts;}mlxlink_state:${state// /_}/${phys// /_}"
        elif [[ "${phys,,}" != "linkup" ]]; then
            alerts="${alerts:+$alerts;}mlxlink_phys_state:${phys// /_}"
        fi
    fi

    LINK_DIAG_CACHE["$bdf"]="$alerts"
    echo "$alerts"
    return 0
}

# ----------------------------------------------------------------------------
# 速率降级：当前速率 < 能力速率
#
# 判据所需的 ib_cap_speed_gb / ib_cur_speed_gb 本来就已经采集，零额外成本。
# 降速通常意味着协商失败后退到低档，常见原因是光模块老化 / 光纤劣化 /
# 连接器脏 —— 属于预测硬件故障的典型场景。
#
# 但交换机的端口限速策略也会造成 cur < cap，所以这不一定是硬件问题，
# 故输出为信息项 ib_speed_degraded 而非断言故障，由人结合现场判断。
# ----------------------------------------------------------------------------
check_speed_degraded() {
    local cap="$1"
    local cur="$2"

    [[ -z "$cap" || -z "$cur" ]] && { echo ""; return 0; }
    [[ "$cap" == "N/A" || "$cur" == "N/A" ]] && { echo ""; return 0; }
    [[ "$cap" =~ ^[0-9]+$ && "$cur" =~ ^[0-9]+$ ]] || { echo ""; return 0; }
    [[ "$cap" -eq 0 ]] && { echo ""; return 0; }

    if [[ "$cur" -lt "$cap" ]]; then
        echo "ib_speed_degraded:${cur}/${cap}"
    else
        echo ""
    fi
    return 0
}

# ----------------------------------------------------------------------------
# 判断模块级"故障标志"字段是否表示真有故障。
#
# 取值形态：0 / Off → 正常；1 / On → 故障；N/A → 该模块不支持此字段。
#
# N/A 必须当作"无法判断"，不能当作故障 —— 本模块（Q56-200G-A40H）的
# Module FW Fault / DataPath FW Fault / LOS Alarm 全是 N/A，
# 若当作故障，一台健康机器会立刻产生多条假告警。
#
# 返回 0 = 确实故障；1 = 正常 / 不支持 / 读不到。
# ----------------------------------------------------------------------------
_flag_faulty() {
    local v="$1"
    [[ -z "$v" ]] && return 1
    v="${v//[[:space:]]/}"

    # N/A、-、空 → 无法判断，不报告
    case "${v,,}" in
        n/a|na|-|--|none|unknown) return 1 ;;
    esac

    # 明确表示故障的取值
    case "${v,,}" in
        1|on|yes|true|fault|failed|fail) return 0 ;;
    esac

    # 纯数字：非 0 即故障
    if [[ "$v" =~ ^[0-9]+$ ]]; then
        [[ "$v" -ne 0 ]] && return 0
        return 1
    fi

    # 其它无法识别的取值 → 不报告（宁可漏报，不制造假告警）
    return 1
}

# ----------------------------------------------------------------------------
# 模拟量越界判断（电压 / 偏置电流 / 温度，单位不一定是 dBm）
# 与 _mlxlink_out_of_range 同样的思路，但只取【第一个数值】比较 ——
# 这几个字段是单值，不是 per-lane 列表。
# 返回 0 = 越界，1 = 在界内 / 无法判断。
# ----------------------------------------------------------------------------
_scalar_out_of_range() {
    local raw="$1"       # 形如 "3326 [2970..3630]"
    [[ -z "$raw" || "$raw" == "N/A" ]] && return 1

    local val="${raw%%\[*}"
    val="${val//[[:space:]]/}"
    val="${val%,}"
    [[ "$val" =~ ^-?[0-9.]+$ ]] || return 1

    local rng="${raw#*\[}"
    rng="${rng%%\]*}"
    rng="${rng//[[:space:]]/}"
    [[ "$rng" =~ ^(-?[0-9.]+)\.\.(-?[0-9.]+)$ ]] || return 1

    local lo="${BASH_REMATCH[1]}" hi="${BASH_REMATCH[2]}"
    awk -v x="$val" -v lo="$lo" -v hi="$hi" 'BEGIN{ exit !(x < lo || x > hi) }'
}

# 提取模拟量的"值[窗口]"里的值部分（供错误信息展示）
_scalar_value() {
    local raw="$1"
    [[ -z "$raw" || "$raw" == "N/A" ]] && { echo "N/A"; return; }
    local v="${raw%%\[*}"
    v="${v//[[:space:]]/}"
    v="${v%,}"
    [[ -z "$v" ]] && v="N/A"
    echo "$v"
}

# ----------------------------------------------------------------------------
# 判断 mlxlink 的 "Loopback Mode" 是否表示确实处于环回。
#
# 不用简单的不等比较（!= "no loopback"）：字段捕获有偏差时（空串、半截、
# 混入其它行）会把"没读到"误判成"处于环回"。
# 改为正向识别已知的环回模式名，只有明确出现环回关键字才报告。
#
# mlxlink 取值："No Loopback"（正常）/ "Local|Remote|External Loopback"（环回）。
#
# 返回 0 = 确实处于环回；1 = 正常 / 无法判断。
# ----------------------------------------------------------------------------
_mlxlink_is_loopback() {
    local v="$1"
    [[ -z "$v" ]] && return 1
    local lv="${v,,}"
    # 明确的"没有环回"
    [[ "$lv" == "no loopback" || "$lv" == "none" || "$lv" == "disabled" ]] && return 1
    # 明确的环回关键字
    [[ "$lv" == *loopback* ]] && return 0
    # 其它无法识别的取值 → 不报告
    return 1
}

# IB 端口错误计数器白名单（12 项，与 mlx5 真机 ls 逐一核对过）。
#
# 其余 9 个刻意不收：
#   8 个流量统计（*_data / *_packets）—— 不是错误；
#   port_xmit_wait —— 恒为 0xFFFFFFFF，无法作为故障判据（见下）。
_is_ib_error_counter() {
    local name="$1"
    case "$name" in
        port_rcv_errors)                      return 0 ;;
        port_rcv_remote_physical_errors)      return 0 ;;
        port_rcv_switch_relay_errors)         return 0 ;;
        port_rcv_constraint_errors)           return 0 ;;
        port_xmit_discards)                   return 0 ;;
        port_xmit_constraint_errors)          return 0 ;;
        local_link_integrity_errors)          return 0 ;;
        link_downed)                          return 0 ;;
        link_error_recovery)                  return 0 ;;
        symbol_error)                         return 0 ;;
        VL15_dropped)                         return 0 ;;
        excessive_buffer_overrun_errors)      return 0 ;;
    esac
    return 1
}

# 判断一个计数器读数是否为"无数据"哨兵值。
# 返回 0 = 是哨兵值（应跳过），1 = 是正常数值。
_is_counter_sentinel() {
    local v="$1"
    [[ -z "$v" ]] && return 0
    # 0xFFFFFFFF（32 位满量程）—— 内核用于表示"该计数器无数据"
    [[ "$v" == "4294967295" ]] && return 0
    return 1
}

get_ib_errors() {
    local iface="$1"

    local ib_device
    ib_device=$(get_ib_device_name "$iface")
    if [[ -z "$ib_device" ]]; then
        echo "0"
        return
    fi

    local port_num
    port_num=$(get_ib_port_number "$iface")

    local counters_dir="/sys/class/infiniband/$ib_device/ports/$port_num/counters"
    if [[ ! -d "$counters_dir" ]]; then
        log_debug "  IB errors: counters 目录不存在: $counters_dir"
        echo "0"
        return
    fi

    local result=""
    local f name val
    for f in "$counters_dir"/*; do
        [[ -f "$f" ]] || continue
        name=$(basename "$f")
        if ! _is_ib_error_counter "$name"; then
            continue
        fi
        val=$(cat "$f" 2>/dev/null | tr -d ' \n')
        [[ -z "$val" ]] && continue
        [[ "$val" =~ ^[0-9]+$ ]] || continue
        [[ "$val" -eq 0 ]] && continue
    # 0xFFFFFFFF 是无数据哨兵值，不是真实计数 —— 跳过
        if _is_counter_sentinel "$val"; then
            log_debug "  计数器 $name=$val (0xFFFFFFFF 哨兵值，视为无数据)"
            continue
        fi
        if [[ -n "$result" ]]; then
            result+=";${name}:${val}"
        else
            result="${name}:${val}"
        fi
    done

    if [[ -z "$result" ]]; then
        echo "0"
    else
        echo "$result"
    fi
}

# ============================================================================
# 光模块采集
# ============================================================================

_mlxlink_dbm_to_mw_avg() {
    local list="$1"
    [[ -z "$list" || "$list" == "N/A" ]] && { echo "N/A"; return; }

    list="${list%%\[*}"
    list="${list//,/ }"

    local sum="0" n=0 v
    for v in $list; do
        v="${v// /}"
        [[ -z "$v" ]] && continue
        if [[ "$v" =~ ^-?[0-9.]+$ ]]; then
            sum=$(awk -v s="$sum" -v d="$v" 'BEGIN { printf "%.6f", s + 10^(d/10) }')
            n=$((n + 1))
        fi
    done
    [[ $n -eq 0 ]] && { echo "N/A"; return; }

    awk -v s="$sum" -v n="$n" 'BEGIN { printf "%.6f", s/n }'
}

# ----------------------------------------------------------------------------
# 解析 mlxlink 的 "值,值,值,值 [下界..上界]" 形式
#
# 真实样例（ConnectX-6 + Q56-200G-A40H，现场采集）：
#   Tx Power Current [dBm]          : 0,0,0,0 [-8..4]
#   Rx Power Current [dBm]          : 2,2,2,2 [-10..4]
#   Tx Fault [per lane]             : 0,0,0,0
#
# 输出三段（用 | 分隔，便于 read 一次取回）：
#   lanes|low|high      lanes = 逗号分隔的原始值，low/high 缺省为 N/A
#
# [low..high] 是模块自己写进 EEPROM 的门限，比任何通用标准值都权威：
# 不同速率/封装/厂商的窗口差别很大，用硬编码门限判断必然误判。
# 丢掉窗口后 CSV 里只剩裸数字，事后无从复核余量。
# ----------------------------------------------------------------------------
_mlxlink_parse_range() {
    local raw="$1"
    [[ -z "$raw" || "$raw" == "N/A" ]] && { echo "N/A|N/A|N/A"; return; }

    local lanes="${raw%%\[*}"
    lanes="${lanes//[[:space:]]/}"
    lanes="${lanes%,}"
    lanes="${lanes#,}"
    lanes="${lanes%,}"

    local low="N/A" high="N/A" rng=""
    if [[ "$raw" == *"["*"]"* ]]; then
        rng="${raw#*\[}"
        rng="${rng%%\]*}"
        rng="${rng//[[:space:]]/}"
        # "-8..4" / "-10..4" / "-8.0..4.0"
        if [[ "$rng" =~ ^(-?[0-9.]+)\.\.(-?[0-9.]+)$ ]]; then
            low="${BASH_REMATCH[1]}"
            high="${BASH_REMATCH[2]}"
        fi
    fi

    [[ -z "$lanes" ]] && lanes="N/A"
    echo "${lanes}|${low}|${high}"
}

# 判断一组 per-lane 值里是否有非零。
# 返回 0 = 存在非零（即真有异常位），1 = 全零或无法判断。
#
# 只有"确实读到值且存在非零"才算异常：读不到 / 字段缺失 / 全是 N/A
# 一律返回 1（不报告），否则假告警会淹没 errors 列。
_mlxlink_any_nonzero() {
    local list="$1"
    [[ -z "$list" || "$list" == "N/A" ]] && return 1

    list="${list%%\[*}"
    list="${list//,/ }"

    local v n=0
    for v in $list; do
        v="${v// /}"
        [[ -z "$v" ]] && continue
        # 只接受数字；非数字（如 "N/A"、"-"）直接跳过，不加也不减
        [[ "$v" =~ ^-?[0-9]+$ ]] || continue
        n=$(( n + 1 ))
        [[ "$v" -ne 0 ]] && return 0
    done

    # 一个有效值都没读到 —— 视为"无法判断"，不报告
    [[ $n -eq 0 ]] && return 1
    return 1
}

# 越界判断：值(可带逗号多 lane) vs 模块窗口 [low..high]
# 返回 0 = 越界，1 = 在界内 / 无法判断
#
# ★ 只用模块自带门限，"无法判断"一律不报告 ★
#   任一 lane 越界即算越界（取最坏情况）—— 4 lane 里坏 1 lane
#   确实是硬件问题，平均后会被掩盖，所以必须逐 lane 比。
_mlxlink_out_of_range() {
    local list="$1"
    local low="$2"
    local high="$3"

    [[ -z "$list" || "$list" == "N/A" ]] && return 1
    [[ -z "$low"  || "$low"  == "N/A" ]] && return 1
    [[ -z "$high" || "$high" == "N/A" ]] && return 1

    list="${list%%\[*}"
    list="${list//,/ }"

    local v
    for v in $list; do
        v="${v// /}"
        [[ -z "$v" ]] && continue
        [[ "$v" =~ ^-?[0-9.]+$ ]] || continue
        # 用 awk 做浮点比较（窗口可能是 -8.0 这种小数）
        if awk -v x="$v" -v lo="$low" -v hi="$high" 'BEGIN{ exit !(x < lo || x > hi) }'; then
            return 0
        fi
    done
    return 1
}

# 计算距窗口边界的余量（dB），取绝对值最小的那条边，输出整数。
# 例：Tx 0 dBm，窗口 [-8..4] → 距下界 8、距上界 4 → 输出 4
#
# 用途：临界余量（比如 Rx 距上限只剩 2 dB）肉眼看不出来，
#       把余量直接写进 CSV 就能一眼发现"正在变差"的模块。
#       只在【确实越界或余量很小】时才写 errors，见调用方。
_mlxlink_edge_margin() {
    local list="$1"
    local low="$2"
    local high="$3"

    [[ -z "$list" || "$list" == "N/A" ]] && { echo "N/A"; return; }
    [[ -z "$low"  || "$low"  == "N/A" ]] && { echo "N/A"; return; }
    [[ -z "$high" || "$high" == "N/A" ]] && { echo "N/A"; return; }

    # 多 lane 时取【最接近边界】的那一个 —— 那才是风险最大的 lane
    list="${list%%\[*}"
    list="${list//,/ }"

    local v best=""
    for v in $list; do
        v="${v// /}"
        [[ -z "$v" ]] && continue
        [[ "$v" =~ ^-?[0-9.]+$ ]] || continue
        local m
        m=$(awk -v x="$v" -v lo="$low" -v hi="$high" \
            'BEGIN{ d1=x-lo; d2=hi-x; m=(d1<d2)?d1:d2; printf "%.2f", m }')
        if [[ -z "$best" ]]; then
            best="$m"
        else
            best=$(awk -v a="$best" -v b="$m" 'BEGIN{ printf "%.2f", (b<a)?b:a }')
        fi
    done

    [[ -z "$best" ]] && { echo "N/A"; return; }
    # 保留 1 位小数
    awk -v m="$best" 'BEGIN{ printf "%.1f", m }'
}

# 返回 16 段：
#   vendor|pn|fw_ver|rev|sn|tx_mw|rx_mw|temp|optics_alerts
#   第 9 段 optics_alerts 用分号分隔，空串表示无问题
#
# 第 9 段 optics_alerts 用 ';' 分隔，空串表示【没有问题】。
# 只有真异常才产生条目，取值形如：
#   optics_tx_out_of_range:0[-8..4]
#   optics_rx_out_of_range:2[-10..4]
#   optics_tx_margin_low:1.0
#   optics_fault:Tx_Fault=0,1,0,0
get_optics_info_mlxlink() {
    local bdf="$1"
    [[ -z "$bdf" || "$bdf" == "N/A" || "$bdf" == "Unknown" ]] && return 1

    # 复用共享缓存：能力枚举 / 端口诊断 / 光模块三处共用同一次调用。
    local out
    out=$(_mlxlink_raw "$bdf") || return 1
    [[ -z "$out" ]] && return 1

    echo "$out" | grep -q "Module Info" || return 1
    echo "$out" | grep -qE "^[[:space:]]*Vendor Name[[:space:]]*:[[:space:]]*[^N]" || return 1

    # 对 $out 只做一次遍历取值：逐字段跑 echo|grep 会是 9 次 fork
    # 加 9 次全量扫描。
    local vendor="" pn="" rev="" sn="" fw_ver="" temp=""
    local tx_dbm="" rx_dbm=""
    local tx_fault="" rx_los="" tx_los="" rx_valid=""
    local tx_cdr="" rx_cdr="" tx_eq=""
    # 带窗口的模拟量 + 模块级故障标志
    local volt_raw="" bias_raw="" temp_raw=""
    local mod_fw_fault="" dp_fw_fault="" los_alarm=""

    # 单次遍历取全部字段。
    local line key val
    while IFS= read -r line; do
        [[ "$line" == *:* ]] || continue
        key="${line%%:*}"
        val="${line#*:}"
        key="${key#"${key%%[![:space:]]*}"}"
        key="${key%"${key##*[![:space:]]}"}"
        val="${val#"${val%%[![:space:]]*}"}"
        val="${val%"${val##*[![:space:]]}"}"

        case "$key" in
            "Vendor Name")          vendor="$val" ;;
            "Vendor Part Number")   pn="$val" ;;
            "Rev")                  rev="$val" ;;
            "Vendor Serial Number") sn="$val" ;;
            "FW Version")           fw_ver="$val" ;;
            "Temperature [C]")      temp="${val%% *}"; temp_raw="$val" ;;
            "Tx Power Current [dBm]") tx_dbm="$val" ;;
            "Rx Power Current [dBm]") rx_dbm="$val" ;;
            "Tx Fault [per lane]")  tx_fault="$val" ;;
            "Rx LOS [per lane]")    rx_los="$val" ;;
            "Tx LOS [per lane]")    tx_los="$val" ;;
            "Rx Output Valid [per lane]") rx_valid="$val" ;;
            "Tx CDR LOL [per lane]") tx_cdr="$val" ;;
            "Rx CDR LOL [per lane]") rx_cdr="$val" ;;
            "Tx Adaptive EQ Fault [per lane]") tx_eq="$val" ;;
    # 模拟量窗口（与温度同属模拟量越界一族）
            "Voltage [mV]")         volt_raw="$val" ;;
            "Bias Current [mA]")    bias_raw="$val" ;;
    # 模块级故障标志。
            #   注意：本模块上这几项全是 "N/A"（不支持），
            #   所以 _flag_faulty 必须把 N/A 当作"无法判断"而非"故障"。
            "Module FW Fault")      mod_fw_fault="$val" ;;
            "DataPath FW Fault")    dp_fw_fault="$val" ;;
            "LOS Alarm")            los_alarm="$val" ;;
        esac
    done <<< "$out"

    local tx_mw rx_mw
    tx_mw=$(_mlxlink_dbm_to_mw_avg "$tx_dbm")
    rx_mw=$(_mlxlink_dbm_to_mw_avg "$rx_dbm")

    # ---- 收集硬件告警（只有真异常才有条目）----
    #
    # ★ 不用嵌套函数累加：函数内定义的函数看不到 caller 的 local。
    #   直接内联拼接，零歧义。
    local alerts=""

    # ① 功率越界：用【模块自带窗口】，不用通用门限
    local txp rxp
    txp=$(_mlxlink_parse_range "$tx_dbm")
    rxp=$(_mlxlink_parse_range "$rx_dbm")

    local tx_lanes tx_low tx_high rx_lanes rx_low rx_high
    IFS='|' read -r tx_lanes tx_low tx_high <<< "$txp"
    IFS='|' read -r rx_lanes rx_low rx_high <<< "$rxp"

    if _mlxlink_out_of_range "$tx_lanes" "$tx_low" "$tx_high"; then
        alerts="${alerts:+$alerts;}optics_tx_out_of_range:${tx_lanes}[${tx_low}..${tx_high}]"
    fi
    if _mlxlink_out_of_range "$rx_lanes" "$rx_low" "$rx_high"; then
        alerts="${alerts:+$alerts;}optics_rx_out_of_range:${rx_lanes}[${rx_low}..${rx_high}]"
    fi

    # ② 余量过小（未越界但已贴近边界）。
    #    阈值 2 dB —— 再来一点劣化就越界。
    #    只在【有窗口 且 余量<2】时产生条目，正常模块不会产生噪声。
    local tx_margin rx_margin
    tx_margin=$(_mlxlink_edge_margin "$tx_lanes" "$tx_low" "$tx_high")
    rx_margin=$(_mlxlink_edge_margin "$rx_lanes" "$rx_low" "$rx_high")

    if [[ "$tx_margin" != "N/A" ]] && awk -v m="$tx_margin" 'BEGIN{exit !(m < 2)}'; then
        alerts="${alerts:+$alerts;}optics_tx_margin_low:${tx_margin}dB"
    fi
    if [[ "$rx_margin" != "N/A" ]] && awk -v m="$rx_margin" 'BEGIN{exit !(m < 2)}'; then
        alerts="${alerts:+$alerts;}optics_rx_margin_low:${rx_margin}dB"
    fi

    # ③ per-lane 故障位：只有【确实读到值且非零】才记录。
    #    读不到字段 → _mlxlink_any_nonzero 返回 1（无法判断）→ 不报告。
    #
    #    ★ Rx Output Valid 不参与判决 ★
    #      它的语义是"输出有效"，0 表示【有效】。按"非零即故障"
    #      处理会把它完全弄反 —— 全 0（正常）反而会被报成故障。
    #      因此这里只检查语义明确的故障位。
    if _mlxlink_any_nonzero "$tx_fault"; then
        alerts="${alerts:+$alerts;}optics_fault:Tx_Fault=${tx_fault// /}"
    fi
    if _mlxlink_any_nonzero "$rx_los"; then
        alerts="${alerts:+$alerts;}optics_fault:Rx_LOS=${rx_los// /}"
    fi
    if _mlxlink_any_nonzero "$tx_los"; then
        alerts="${alerts:+$alerts;}optics_fault:Tx_LOS=${tx_los// /}"
    fi
    if _mlxlink_any_nonzero "$tx_cdr"; then
        alerts="${alerts:+$alerts;}optics_fault:Tx_CDR_LOL=${tx_cdr// /}"
    fi
    if _mlxlink_any_nonzero "$rx_cdr"; then
        alerts="${alerts:+$alerts;}optics_fault:Rx_CDR_LOL=${rx_cdr// /}"
    fi
    if _mlxlink_any_nonzero "$tx_eq"; then
        alerts="${alerts:+$alerts;}optics_fault:Tx_Adaptive_EQ_Fault=${tx_eq// /}"
    fi

    # 4) 模块级故障标志
    #    Module FW Fault / DataPath FW Fault / LOS Alarm
    #    这几项在本模块上是 N/A（不支持），_flag_faulty 会正确忽略，
    #    只有在真报 1/On 时才产生告警。
    if _flag_faulty "$mod_fw_fault"; then
        alerts="${alerts:+$alerts;}optics_module_fw_fault:${mod_fw_fault// /}"
    fi
    if _flag_faulty "$dp_fw_fault"; then
        alerts="${alerts:+$alerts;}optics_datapath_fw_fault:${dp_fw_fault// /}"
    fi
    if _flag_faulty "$los_alarm"; then
        alerts="${alerts:+$alerts;}optics_los_alarm:${los_alarm// /}"
    fi

    # 5) 其它模拟量越界（电压 / 偏置电流 / 温度）
    #    与 Tx/Rx 功率同一个思路 —— 用【模块自带窗口】判断。
    #    这三项能覆盖"光模块电气/热异常"，是功率之外的独立维度：
    #      电压异常 → 供电/模块内部故障
    #      偏置电流偏移 → 激光器老化（同功率下电流上升是典型老化征兆）
    #      温度过高 → 加速老化 / 散热问题
    if _scalar_out_of_range "$volt_raw"; then
        alerts="${alerts:+$alerts;}optics_voltage_out_of_range:$(_scalar_value "$volt_raw")mV"
    fi
    if _scalar_out_of_range "$bias_raw"; then
        alerts="${alerts:+$alerts;}optics_bias_out_of_range:$(_scalar_value "$bias_raw")mA"
    fi
    if _scalar_out_of_range "$temp_raw"; then
        alerts="${alerts:+$alerts;}optics_temp_out_of_range:$(_scalar_value "$temp_raw")C"
    fi

    echo "${vendor:-N/A}|${pn:-N/A}|${fw_ver:-N/A}|${rev:-N/A}|${sn:-N/A}|${tx_mw}|${rx_mw}|${temp:-N/A}|${alerts}"
    return 0
}

get_optics_info_ethtool() {
    local iface="$1"

    local vendor="" pn="" rev="" sn="" fw_ver=""
    local tx_power="" rx_power="" temperature=""

    if ! command -v ethtool &>/dev/null; then
        echo "N/A|N/A|N/A|N/A|N/A|N/A|N/A|N/A|"
        return 1
    fi

    # 用 `if ! var=$(cmd)` 直接判断，不要先赋值再看 $? ——
    # `var=$(cmd)` 之后 $? 反映的是赋值语句本身，恒为 0，捕不到 cmd 的失败。
    local ethtool_output
    if ! ethtool_output=$($SUDO ethtool -m "$iface" 2>/dev/null); then
        echo "N/A|N/A|N/A|N/A|N/A|N/A|N/A|N/A|"
        return 1
    fi
    if [[ -z "$ethtool_output" ]]; then
        echo "N/A|N/A|N/A|N/A|N/A|N/A|N/A|N/A|"
        return 1
    fi

    if ! echo "$ethtool_output" | grep -qi "Vendor name"; then
        echo "N/A|N/A|N/A|N/A|N/A|N/A|N/A|N/A|"
        return 1
    fi

    vendor=$(echo "$ethtool_output" | grep -i "Vendor name" | head -1 | awk -F':' '{print $2}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    pn=$(echo "$ethtool_output" | grep -i "Vendor PN" | head -1 | awk -F':' '{print $2}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    rev=$(echo "$ethtool_output" | grep -i "Vendor rev" | head -1 | awk -F':' '{print $2}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    sn=$(echo "$ethtool_output" | grep -i "Vendor SN" | head -1 | awk -F':' '{print $2}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    fw_ver=$(echo "$ethtool_output" | grep -iE "Vendor FW|FW Version" | head -1 | awk -F':' '{print $2}' | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')

    local tx_line
    tx_line=$(echo "$ethtool_output" | grep -iE "Laser output power|Tx power" | head -1)
    if [[ -n "$tx_line" ]]; then
        local tx_mw
        tx_mw=$(echo "$tx_line" | grep -oE '[0-9]+\.[0-9]+ mW' | head -1 | sed 's/ mW//')
        if [[ -n "$tx_mw" ]]; then
            tx_power="$tx_mw"
        else
            local tx_dbm
            tx_dbm=$(echo "$tx_line" | grep -oE '[-+]?[0-9]+\.[0-9]+ dBm' | head -1 | sed 's/ dBm//')
            [[ -n "$tx_dbm" ]] && tx_power=$(awk -v dbm="$tx_dbm" 'BEGIN {printf "%.4f", 10^(dbm/10)}')
        fi
    fi
    tx_power="${tx_power:-N/A}"

    local rx_line
    rx_line=$(echo "$ethtool_output" | grep -iE "Receiver signal average optical power|Rx power" | head -1)
    if [[ -n "$rx_line" ]]; then
        local rx_mw
        rx_mw=$(echo "$rx_line" | grep -oE '[0-9]+\.[0-9]+ mW' | head -1 | sed 's/ mW//')
        if [[ -n "$rx_mw" ]]; then
            rx_power="$rx_mw"
        else
            local rx_dbm
            rx_dbm=$(echo "$rx_line" | grep -oE '[-+]?[0-9]+\.[0-9]+ dBm' | head -1 | sed 's/ dBm//')
            [[ -n "$rx_dbm" ]] && rx_power=$(awk -v dbm="$rx_dbm" 'BEGIN {printf "%.4f", 10^(dbm/10)}')
        fi
    fi
    rx_power="${rx_power:-N/A}"

    local temp_line
    temp_line=$(echo "$ethtool_output" | grep -i "Module temperature" | head -1)
    if [[ -n "$temp_line" ]]; then
        local temp_c
        temp_c=$(echo "$temp_line" | grep -oE '[0-9]+\.[0-9]+ degrees C' | head -1 | sed 's/ degrees C//')
        [[ -z "$temp_c" ]] && temp_c=$(echo "$temp_line" | grep -oE '[0-9]+\.[0-9]+ C' | head -1 | sed 's/ C//')
        [[ -z "$temp_c" ]] && temp_c=$(echo "$temp_line" | awk -F':' '{print $2}' | grep -oE '[0-9]+\.[0-9]+' | head -1)
        temperature="$temp_c"
    fi
    temperature="${temperature:-N/A}"

    echo "${vendor:-N/A}|${pn:-N/A}|${fw_ver:-N/A}|${rev:-N/A}|${sn:-N/A}|${tx_power}|${rx_power}|${temperature}|"
}

get_optics_info() {
    local iface="$1"
    local pcie_bus_id="$2"
    local nic_vendor="$3"

    # 两个来源分开缓存，键的语义必须与数据来源一致。
    #
    #   mlxlink 路径：mlxlink -d <BDF>    → 结果只取决于 BDF
    #   ethtool 路径：ethtool -m <iface>  → 结果取决于接口名，
    #                                      与 BDF 不是一一对应
    #
    # 若两者共用一个缓存、键统一成 bus_base（按卡分组），ethtool 的结果
    # 就会从第 1 口串到同卡所有口 —— 每口的光模块是独立硬件，
    # 串了口等于整张卡的 optics 列全错，且看不出异常。
    local mlx_key="${pcie_bus_id}"
    local eth_key="${iface}"

    local result=""

    if [[ "$nic_vendor" == "Mellanox" ]] \
       && [[ -n "$pcie_bus_id" && "$pcie_bus_id" != "N/A" ]]; then
        local mlx_out=""
        if [[ -n "${MLXLINK_OPTICS_CACHE[$mlx_key]+x}" ]]; then
            mlx_out="${MLXLINK_OPTICS_CACHE[$mlx_key]}"
            log_debug "  光模块: mlxlink 缓存命中 ($mlx_key)"
        else
            mlx_out=$(get_optics_info_mlxlink "$pcie_bus_id")
            MLXLINK_OPTICS_CACHE["$mlx_key"]="$mlx_out"
        fi

        if [[ -n "$mlx_out" && "$mlx_out" != "N/A|N/A|N/A|N/A|N/A|N/A|N/A|N/A|" ]]; then
            local mlx_vendor
            mlx_vendor=$(echo "$mlx_out" | cut -d'|' -f1)
            if [[ -n "$mlx_vendor" && "$mlx_vendor" != "N/A" ]]; then
                log_debug "  光模块: mlxlink 命中 ($iface @ $pcie_bus_id)"
                result="$mlx_out"
            else
                log_debug "  光模块: mlxlink Vendor Name 无效，回退 ethtool ($iface)"
                result=$(get_optics_info_ethtool_cached "$eth_key")
            fi
        else
            log_debug "  光模块: mlxlink 未命中，回退 ethtool ($iface)"
            result=$(get_optics_info_ethtool_cached "$eth_key")
        fi
    else
        result=$(get_optics_info_ethtool_cached "$eth_key")
    fi

    echo "$result"
}

# ethtool 光模块结果的接口级缓存包装。
# 单独抽出来是为了让缓存键（接口名）与数据来源（ethtool -m <iface>）
# 严格对应，见 get_optics_info 顶部说明。
get_optics_info_ethtool_cached() {
    local iface="$1"
    if [[ -n "${ETHTOOL_OPTICS_CACHE[$iface]+x}" ]]; then
        echo "${ETHTOOL_OPTICS_CACHE[$iface]}"
        return 0
    fi
    local r
    r=$(get_optics_info_ethtool "$iface")
    ETHTOOL_OPTICS_CACHE["$iface"]="$r"
    echo "$r"
}

# ============================================================================
# CSV 文件操作
# ============================================================================

generate_output_filename() {
    local serial="$1"
    local dir="${OUTPUT_DIR}"

    local clean_serial=$(echo "$serial" | sed 's/[^a-zA-Z0-9_-]//g')

    if [[ -z "$clean_serial" ]] || [[ "$clean_serial" == "UNKNOWN" ]]; then
        echo "${dir}/ib_info.csv"
    else
        echo "${dir}/ib_info_${clean_serial}.csv"
    fi
}

# 表头直接用 CSV_HEADER 常量输出，不在函数里重复一份字面量 ——
# 否则表头、output_row 的实参、文档三处各写一遍，迟早不同步。
# 这里额外断言一次常量自身的字段数，防止改 CSV_HEADER 时漏改
# CSV_COLUMNS（那种不一致会让所有行都被 output_row 判为错列）。
write_csv_header() {
    local output_file="$1"

    local _n=1 _q=0 _k _ch
    for (( _k = 0; _k < ${#CSV_HEADER}; _k++ )); do
        _ch="${CSV_HEADER:_k:1}"
        if [[ "$_ch" == '"' ]]; then
            if [[ "${CSV_HEADER:_k+1:1}" == '"' ]]; then
                _k=$(( _k + 1 ))
            else
                _q=$(( 1 - _q ))
            fi
        elif [[ "$_ch" == ',' && "$_q" -eq 0 ]]; then
            _n=$(( _n + 1 ))
        fi
    done
    if [[ "$_n" -ne "$CSV_COLUMNS" ]]; then
        log_error "内部错误: 表头字段数($_n) 与 CSV_COLUMNS($CSV_COLUMNS) 不一致"
        return 1
    fi

    printf '%s\n' "$CSV_HEADER" > "$output_file"
    log_debug "CSV头已写入: $output_file ($CSV_COLUMNS 列)"
    return 0
}

# ============================================================================
# 主收集
# ============================================================================

collect_ib_info() {
    local serial="$1"
    local output_file="$2"

    log_info "正在收集InfiniBand网卡信息..."
    load_pci_slot_map

    local nics=()
    mapfile -t nics < <(get_physical_ib_nics)

    if [[ ${#nics[@]} -eq 0 ]]; then
        log_warn "未检测到物理IB网卡！"
        return 0
    fi

    log_info "检测到 ${#nics[@]} 个物理IB网卡: ${nics[*]}"

    # 一次遍历建立 接口 → bus 映射，端口分组走查表。
    build_iface_bus_map

    local record_count=0
    local -A processed_bus=()

    for iface in "${nics[@]}"; do
        log_debug "正在处理IB网卡: $iface"

        local pci_addr
        pci_addr=$(get_pci_address "$iface")
        local bus_base
        bus_base=$(get_pci_bus_base "$pci_addr")

        # 同一张多口卡只输出一组卡级信息（用关联数组代替线性查找）
        if [[ -n "${processed_bus[$bus_base]+x}" ]]; then
            log_debug "PCI Bus $bus_base 已处理，跳过 $iface"
            continue
        fi
        processed_bus["$bus_base"]=1

        local ports=()
        mapfile -t ports < <(get_ports_for_bus "$bus_base")

        # 防御：正常情况下这张卡自己一定在 IFACE_BUS_MAP 里（它已通过
        # is_physical_ib_nic），所以 ports 至少有一个。万一映射构建异常
        # 导致查不到，就退回"本卡只有当前这个口"，绝不能因为端口数 0
        # 而把整张卡静默丢掉。
        if [[ ${#ports[@]} -eq 0 ]]; then
            log_debug "PCI Bus $bus_base 未查到端口列表，回退为当前接口 $iface"
            ports=("$iface")
        fi

        local total_ports=${#ports[@]}
        local port_num_str="${total_ports}P"

        local first_port="${ports[0]}"
        local first_port_pci
        first_port_pci=$(get_pci_address "$first_port")
        local nic_pcie_bus_id
        nic_pcie_bus_id=$(normalize_pci_addr "$first_port_pci")

        local lnk_pci="$nic_pcie_bus_id"
        local lnk_info
        lnk_info=$(_get_lspci_vv "$lnk_pci")
        if ! echo "$lnk_info" | grep -qE "LnkCap:|LnkSta:"; then
            for port in "${ports[@]}"; do
                local pp
                pp=$(normalize_pci_addr "$(get_pci_address "$port")")
                if echo "$(_get_lspci_vv "$pp")" | grep -qE "LnkCap:|LnkSta:"; then
                    lnk_pci="$pp"
                    break
                fi
            done
        fi

        local pcie_gen
        pcie_gen=$(get_pcie_gen "$lnk_pci")
        local pcie_link_cap
        pcie_link_cap=$(get_pcie_link_cap "$lnk_pci")
        local pcie_link_sta
        pcie_link_sta=$(get_pcie_link_sta "$lnk_pci")
        local pcie_vid
        pcie_vid=$(get_pcie_vid "$nic_pcie_bus_id")
        local pcie_pid
        pcie_pid=$(get_pcie_pid "$nic_pcie_bus_id")

        local vendor
        vendor=$(get_ib_vendor "$pci_addr")
        local model
        model=$(get_ib_model "$pci_addr")
        local product
        product=$(get_ib_product "$pci_addr")
        local ib_serial
        ib_serial=$(get_ib_serial "$pci_addr")
        local firmware
        firmware=$(get_ib_firmware "$iface")

        local cap_speed_gb
        cap_speed_gb=$(get_ib_cap_speed_gb "$nic_pcie_bus_id")
        local cur_speed_gb
        cur_speed_gb=$(get_ib_cur_speed_gb "$iface")

        log_info "✅ IB网卡: $model (Bus: $bus_base, 端口数: $port_num_str, Cap: ${cap_speed_gb}Gb/s, Cur: ${cur_speed_gb}Gb/s, PCIe: $pcie_link_sta)"
        log_debug "   - Vendor: $vendor"
        log_debug "   - Product: $product"
        log_debug "   - Serial: $ib_serial"
        log_debug "   - Firmware: $firmware"
        log_debug "   - Cap Speed: ${cap_speed_gb}Gb/s"
        log_debug "   - Cur Speed: ${cur_speed_gb}Gb/s"
        log_debug "   - nic_pcie_bus_id: $nic_pcie_bus_id"
        log_debug "   - pcie_gen: $pcie_gen"
        log_debug "   - pcie_link_cap: $pcie_link_cap"
        log_debug "   - pcie_link_sta: $pcie_link_sta"

        local subnum=1
        for port in "${ports[@]}"; do
            local port_guid
            port_guid=$(get_ib_port_guid "$port")
            local port_name
            port_name=$(get_ib_interface_name "$port")
            local port_pci_raw
            port_pci_raw=$(get_pci_address "$port")
            local port_pci
            port_pci=$(normalize_pci_addr "$port_pci_raw")
            local pcie_slot
            pcie_slot=$(get_pcie_slot "$port_pci")

            local optics_vendor="N/A"
            local optics_pn="N/A"
            local optics_fw_ver="N/A"
            local optics_rev="N/A"
            local optics_sn="N/A"
            local optics_tx="N/A"
            local optics_rx="N/A"
            local optics_temp="N/A"
            local optics_alerts=""

            local optics_info
            optics_info=$(get_optics_info "$port" "$port_pci" "$vendor")
            if [[ -n "$optics_info" && "$optics_info" != "N/A|N/A|N/A|N/A|N/A|N/A|N/A|N/A|" ]]; then
                optics_vendor=$(echo "$optics_info" | cut -d'|' -f1)
                optics_pn=$(echo "$optics_info"     | cut -d'|' -f2)
                optics_fw_ver=$(echo "$optics_info" | cut -d'|' -f3)
                optics_rev=$(echo "$optics_info"    | cut -d'|' -f4)
                optics_sn=$(echo "$optics_info"     | cut -d'|' -f5)
                optics_tx=$(echo "$optics_info"     | cut -d'|' -f6)
                optics_rx=$(echo "$optics_info"     | cut -d'|' -f7)
                optics_temp=$(echo "$optics_info"   | cut -d'|' -f8)
                # 第 9 段是硬件告警：只有真异常才有内容，正常时为空串。
                optics_alerts=$(echo "$optics_info" | cut -d'|' -f9)
            fi

            local ib_errors
            ib_errors=$(get_ib_errors "$port")

    # 把链路/光模块判据并入 errors 列
            #
            # 顺序刻意如此：先"数据来源是否合法"（link_layer），
            # 再"当前链路状态"，最后"历史计数/劣化信息"。
            # 下游扫一眼开头就知道最严重的问题是什么。
            #
            # 每一项在正常时都返回空串 → 完全不影响既有输出。
            local _extra=""

            # ① 链路类型 / 状态（sysfs，零成本）
            #    传入 BDF 作为兜底：以太网模式下 netdev 路径可能不含
            #    infiniband/<dev>，靠 PCI 地址反查才能定位到 IB 设备。
            _extra=$(get_link_diag "$port" "$port_pci")
            [[ -n "$_extra" ]] && ib_errors="${ib_errors:+$ib_errors;}${_extra}"

            # ② 端口级 mlxlink 诊断（按 BDF 缓存，每卡一次）
            _extra=$(get_link_diag_mlxlink "$port_pci")
            [[ -n "$_extra" ]] && ib_errors="${ib_errors:+$ib_errors;}${_extra}"

            # ③ 速率降级（数据本来就有，只是没人比较过）
            _extra=$(check_speed_degraded "$cap_speed_gb" "$cur_speed_gb")
            [[ -n "$_extra" ]] && ib_errors="${ib_errors:+$ib_errors;}${_extra}"

            # ④ 光模块告警
            #   正常模块 optics_alerts 为空串 → 对原有输出零影响。
            if [[ -n "$optics_alerts" ]]; then
                ib_errors="${ib_errors:+$ib_errors;}${optics_alerts}"
            fi

            # 必须检查 output_row 的退出码：
            # 它在列数自检失败时只写 stderr 并 return 1，stdout 一个字节都没有。
            # 若不判断退出码，失败时不会追加任何内容（因为没有 stdout），
            # 但调用方不知道失败了，仍会 continue、仍会计数，最后打印
            # "完成 N 条记录" —— "本该报错的场景被降级为静默少数据"。
            local row
            if ! row=$(output_row "$serial" "$vendor" "$model" "$product" "$ib_serial" \
                       "$cap_speed_gb" "$cur_speed_gb" "$port_num_str" "$subnum" "$firmware" "$port_name" "$port_guid" \
                       "$nic_pcie_bus_id" "$port_pci" "$pcie_slot" \
                       "$pcie_vid" "$pcie_pid" "$pcie_gen" "$pcie_link_cap" "$pcie_link_sta" \
                       "$optics_vendor" "$optics_pn" "$optics_fw_ver" "$optics_rev" "$optics_sn" \
                       "$optics_tx" "$optics_rx" "$optics_temp" \
                       "$ib_errors"); then
                log_error "端口 $port_name 的 CSV 行组装失败，已中止以免写出错位文件"
                log_error "已写入 $record_count 条记录，输出文件可能不完整: $output_file"
                return 1
            fi
            printf '%s\n' "$row" >> "$output_file"

            log_debug "   - 端口 $subnum/$total_ports: $port_name (GUID: $port_guid, PCI: $port_pci, Slot: $pcie_slot, Optics: $optics_vendor, FW: $optics_fw_ver, Rev: $optics_rev, Tx: $optics_tx, Rx: $optics_rx, Errors: $ib_errors)"
            ((subnum++)) || true
            ((record_count++)) || true
        done
    done

    echo "$record_count"
}

# ============================================================================
# 主函数
# ============================================================================

main() {
    print_header "服务器InfiniBand网卡信息收集工具 v18 (VF已过滤，含光模块)"

    if ! ls /sys/class/infiniband/ 2>/dev/null | grep -q .; then
        log_warn "未检测到InfiniBand设备（/sys/class/infiniband/ 为空）！"
    fi

    init_vendor_id_map

    # -s 指定的序列号优先：无条件执行 get_system_serial 会冲掉它。
    if [[ "$SERIAL_EXPLICIT" == "true" ]]; then
        log_info "使用命令行指定的系统序列号: $SYSTEM_SERIAL"
    else
        SYSTEM_SERIAL=$(get_system_serial)
    fi
    OUTPUT_FILE=$(generate_output_filename "$SYSTEM_SERIAL")

    local missing_tools=()

    if ! command -v dmidecode &>/dev/null; then
        missing_tools+=("dmidecode")
    fi

    if ! command -v lspci &>/dev/null; then
        missing_tools+=("pciutils")
    fi

    if [[ ${#missing_tools[@]} -gt 0 ]]; then
        log_warn "缺少以下工具: ${missing_tools[*]}"
        log_info "请根据系统类型安装："
        echo "  - CentOS/RHEL: yum install -y dmidecode pciutils" >&2
        echo "  - Ubuntu/Debian: apt-get install -y dmidecode pciutils" >&2
        echo "" >&2

        read -p "是否继续执行（部分信息可能不完整）？[y/N] " -n 1 -r < /dev/tty
        echo
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            exit 1
        fi
    fi

    if ! command -v mlxlink &>/dev/null; then
        log_debug "mlxlink 未安装，Mellanox 光模块 / HCA 能力将回退 ethtool 或返回 N/A"
    else
        log_debug "检测到 mlxlink: $(command -v mlxlink)"
    fi

    if [[ "$(id -u)" -ne 0 ]]; then
        if ! sudo -n true 2>/dev/null; then
            if [[ -t 0 && -r /dev/tty ]]; then
                log_warn "需要 sudo 权限获取 PCI VPD / dmidecode 信息"
                log_warn "建议用 sudo 运行以避免重复输入密码: sudo bash $SCRIPT_NAME"
                if ! sudo -v 2>/dev/null; then
                    log_error "sudo 认证失败，退出"
                    exit 1
                fi
            else
                log_warn "非交互环境且无免密 sudo，部分字段可能为空"
            fi
        fi
    fi

    if [[ ! -d "$OUTPUT_DIR" ]]; then
        mkdir -p "$OUTPUT_DIR" 2>/dev/null || {
            log_error "无法创建输出目录: $OUTPUT_DIR"
            exit 1
        }
    fi

    write_csv_header "$OUTPUT_FILE"

    local record_count
    record_count=$(collect_ib_info "$SYSTEM_SERIAL" "$OUTPUT_FILE")

    print_separator
    echo -e "${GREEN}✅ 完成！${NC}" >&2
    print_separator
    echo -e "📁 输出文件: ${BLUE}$OUTPUT_FILE${NC}" >&2

    if [[ -f "$OUTPUT_FILE" ]]; then
        # ★ 用实打实的行数（减掉表头），而不是 collect_ib_info 的返回值 ★
        #   两个数来源不同：record_count 是"我们认为写了几行"，
        #   wc -l 是"文件里真有几行"。用文件行数更可信 ——
        #   万一有哪一行没写进去，这里能直接看出来。
    #   层叠的命令替换可读性差，且空文件会得到 -1，
        #     命令替换嵌在算术里可读性差，拆成两步。）
        local file_lines
        file_lines=$(wc -l < "$OUTPUT_FILE")
        file_lines="${file_lines//[[:space:]]/}"
        [[ -z "$file_lines" ]] && file_lines=0
        local line_count=$(( file_lines - 1 ))
        [[ $line_count -lt 0 ]] && line_count=0
        echo -e "📊 IB网卡端口记录: ${BLUE}$line_count${NC} 条 (仅包含Physical Function)" >&2
        print_separator
        echo -e "${YELLOW}📄 内容预览:${NC}" >&2
        print_separator
        cat "$OUTPUT_FILE"
        print_separator
    else
        log_error "输出文件生成失败"
        exit 1
    fi
}

# ============================================================================
# 帮助 & 参数
# ============================================================================

show_help() {
    cat << EOF
服务器InfiniBand网卡信息收集工具 - v18

用法: sudo bash $SCRIPT_NAME [选项]

选项:
    -h, --help          显示此帮助信息
    -d, --debug         启用调试模式
    -o, --output DIR    指定输出目录 (默认: <脚本目录>/report)
    -s, --serial SN     手动指定系统序列号
                        指定后【不再自动探测】，CSV 首列即该值

功能说明:
    - 自动识别 InfiniBand 网卡 (Mellanox/NVIDIA 等)
    - 自动过滤 Virtual Function (VF) 网卡
    - 只显示 Physical Function (PF) 网卡
    - 每个物理端口单独输出一行

IB 接口判定:
    优先按内核设备类型判定，不再使用接口名：
      ① /sys/class/net/<iface>/type == 32 (ARPHRD_INFINIBAND)  → IB
      ② /sys/class/net/<iface>/type == 1  (ARPHRD_ETHER)       → 非 IB
      ③ /sys/class/net/<iface>/type == 772 (ARPHRD_LOOPBACK)   → 非 IB
      ④ ip -o link show <iface> 输出含 "link/infiniband"       → IB
      ⑤ ip -o link show <iface> 输出含 "link/ether"            → 非 IB
      ⑥ /sys/class/net/<iface>/device/infiniband/ 目录存在      → IB
      ⑦ 其余                                                  → 非 IB

速率字段说明:
    ib_cap_speed_gb   硬件支持的最高 IB 速率（HCA 能力），单位 Gb/s
                      数据源：mlxlink -d <bdf> -m 的 "Enabled Link Speed"
                      解析括号内枚举名取最高：
                        XDR=800  NDR=400  HDR=200  EDR=100
                        FDR=56   FDR10=40 QDR=40   DDR=20  SDR=10
                      未安装 mlxlink 或解析失败 → N/A
    ib_cur_speed_gb   当前协商速率，单位 Gb/s
                      数据源：ibstat Rate → sysfs rate → ethtool
                      端口未插线时可能返回 10（SDR 兜底值），
                      此时不代表 HCA 能力上限，请参考 ib_cap_speed_gb

光模块策略:
    Mellanox 卡 → 优先 mlxlink -d <bdf> -m（需 MFT 已安装）
                  mlxlink 只要读到有效 Vendor Name 就采用；
                  允许 Tx/Rx Power 为 0 dBm（Active Cable 的真实值）
    mlxlink 未命中（无 Module Info / 无 Vendor Name）→ 回退 ethtool -m
    其他厂商卡 → ethtool -m

    输出 8 列：
        optics_vendor          光模块厂商
        optics_pn              光模块 Part Number
        optics_fw_ver          光模块固件版本（mlxlink: FW Version 字段；
                               ethtool: 通常为 N/A）
        optics_rev             光模块 Rev（如 A7）
        optics_sn              光模块序列号
        optics_tx_power_mw     发送功率（mW，多个 lane 取平均）
                               dBm → mW 换算：mW = 10^(dBm/10)
                               0 dBm → 1.000000
                               2 dBm → 1.584893
        optics_rx_power_mw     接收功率（mW，多个 lane 取平均）
        optics_temperature_c   光模块温度（℃）

光模块健康判定:
    数据源：mlxlink -d <BDF> -m 里的
            "Tx/Rx Power Current [dBm] : 值,值,值,值 [下界..上界]"
    判定原则：
      ① 只用【模块自己写进 EEPROM 的门限】[下界..上界]，
         不使用任何通用标准值 —— 不同速率/封装/厂商的窗口差别很大，
         硬编码门限必然误判。
      ② 逐 lane 比较（4 lane 里坏 1 lane 会被平均值掩盖）。
      ③ 只有真异常才写入 errors 列：
           - 任一 lane 越界              → 记录
           - 距最近边界余量 < 2 dB       → 记录（劣化前兆）
           - per-lane 故障位非零         → 记录
      ④ 读不到 / 字段缺失 / 无窗口 → 【一律不报告】。
         "缺数据"不等于"有故障"。

    说明：Rx Output Valid [per lane] 刻意不参与判决 ——
          它的语义是"输出有效"，0 表示【有效】，
          按"非零即故障"处理会把结论完全弄反。

errors 列说明:
    数据源：① /sys/class/infiniband/<dev>/ports/<port>/counters/
            ② /sys/class/infiniband/<dev>/ports/<port>/{link_layer,state,phys_state}
            ③ mlxlink -d <BDF> -m（端口诊断 + 光模块，全脚本仅此一次调用）
    只统计"错误/异常"项，正常时输出 "0"。
    输出顺序（严重程度由高到低）：
      ── 数据来源合法性 ──
        link_layer:<值>                  非 InfiniBand（可能是以太网口！）
          ⚠️ 实测限制：本脚本用 is_ib_iface()（按 netdev type）筛选端口，
             以太网模式的 mlx5 端口 netdev type=1，会被【整行过滤掉】，
             因此这一条对以太网口【永远不会触发】。
             真机实例：3 卡机器 link_layer = InfiniBand/Ethernet/Ethernet，
             脚本只会产出 1 行。需要用户决定是否放宽筛选。
      ── 当前链路状态 ──
        ib_state:<值>                    state 未到 Active
        ib_phys_state:<值>               phys_state 非 LinkUp
        ib_state_phys_mismatch:<s>/<p>   Active 却不在 LinkUp（矛盾组合）
        mlxlink_state:<s>/<p>            mlxlink 报告的 State 异常
                                         （需 s 与 p 都读到才判断）
        mlxlink_phys_state:<值>          mlxlink 报告的 Physical state 异常
        mlxlink_autoneg:OFF              自动协商关闭
        loopback:<模式>                  端口处于环回（未连对端）
        mlxlink_status:<opcode>          mlxlink Status Opcode 非 0（须为纯数字）
      ── 劣化 / 统计 ──
        ib_speed_degraded:<cur>/<cap>    当前速率低于能力速率
        optics_*                         光模块告警（见下）
        <counter_name>:<value>           IB 错误计数器（见下）
      ── 光模块告警 ──
        optics_tx_out_of_range:<lanes>[<low>..<high>]
        optics_rx_out_of_range:<lanes>[<low>..<high>]
        optics_tx_margin_low:<dB>              余量不足 2dB
        optics_rx_margin_low:<dB>
        optics_voltage_out_of_range:<mV>
        optics_bias_out_of_range:<mA>
        optics_temp_out_of_range:<C>
        optics_fault:Tx_Fault=<lanes>
        optics_fault:Rx_LOS=<lanes>
        optics_fault:Tx_LOS=<lanes>
        optics_fault:Tx_CDR_LOL=<lanes>
        optics_fault:Rx_CDR_LOL=<lanes>
        optics_fault:Tx_Adaptive_EQ_Fault=<lanes>
        optics_module_fw_fault:<值>
        optics_datapath_fw_fault:<值>
        optics_los_alarm:<值>
      ── IB 错误计数器（非零才输出）──
        port_rcv_errors                      接收错误
        port_rcv_remote_physical_errors      远端物理层接收错误
        port_rcv_switch_relay_errors         交换机转发错误
        port_rcv_constraint_errors           接收约束错误
        port_xmit_discards                   发送丢弃
        port_xmit_constraint_errors          发送约束错误
        local_link_integrity_errors          本地链路完整性错误
        link_downed                          链路 Down 次数
        link_error_recovery                  链路错误恢复次数
        symbol_error                         符号错误
        VL15_dropped                         VL15 丢弃
        excessive_buffer_overrun_errors      接收缓冲溢出
        ★ 读到 4294967295 (0xFFFFFFFF) 的计数器一律【跳过】★
          这是 32 位寄存器满量程的"无数据"哨兵值，不是真实计数；
          真机实测 port_xmit_wait 恒为该值，故未纳入白名单。
    输出格式：name:value;name:value
    无错误时输出 "0"，与 collect_nic.sh 的 errors 列保持一致。
    完全健康的机器不会产生任何新增内容。

    ⚠️ mlxlink 字段可用性（实测 ConnectX-6 + Q56-200G-A40H）：
       - `mlxlink -d <BDF> -m` 的输出【包含】端口级诊断段，
         故本脚本每个 BDF 只调用一次 mlxlink。
       - Module FW Fault / DataPath FW Fault / LOS Alarm 在本模块上
         是 N/A（不支持）→ 按"无法判断"处理，不报故障。
         （若把 N/A 当故障，一台健康机器会凭空多出多条假告警。）
       - BER / SNR 在 -m 与 bare 两种输出里都【没有】，
         需要 amBER 等专门子命令，本脚本不采集。
       - Voltage / Bias / Temperature 的窗口是模块自带门限，
         与 Tx/Rx 功率同样处理；本模块实测 3326mV / 7.458mA / 34C，
         均在窗内。

输出格式（29 列）:
    server_serial,ib_vendor,ib_model,ib_product,ib_serial,
    ib_cap_speed_gb,ib_cur_speed_gb,ib_port_num,ib_port_subnum,
    ib_firmware,ib_interface_name,ib_port_guid,
    nic_pcie_bus_id,nic_port_pcie_bus_id,pcie_slot,
    pcie_vendor_id,pcie_product_id,pcie_gen,pcie_link_cap,pcie_link_sta,
    optics_vendor,optics_pn,optics_fw_ver,optics_rev,optics_sn,
    optics_tx_power_mw,optics_rx_power_mw,optics_temperature_c,errors

依赖工具:
    - dmidecode: 获取系统序列号 / PCI slot 表
    - lspci: 获取 PCI 设备信息（VPD 需要 root）
    - ibstat (推荐): 获取 IB 设备详细信息
    - mlxlink (推荐): HCA 能力枚举 / Mellanox 光模块信息（需 MFT）
    - ethtool (可选): 光模块兜底 / 速率

示例:
    sudo bash $SCRIPT_NAME
    sudo bash $SCRIPT_NAME -o /tmp
    sudo bash $SCRIPT_NAME -s ABC123456
    sudo bash $SCRIPT_NAME -d
EOF
}

parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)
                show_help
                exit 0
                ;;
            -d|--debug)
                DEBUG="true"
                shift
                ;;
            -o|--output)
                # 必须先用 ${2:-} 校验，再 shift 2。
                #
                # shift N 在 N > $# 时会失败：返回非 0，且位置参数原封不动。
                # 于是 `-o` 作为最后一个参数时 $1 仍是 -o、$# 仍是 1，
                # while 条件永远成立 → 死循环。该死循环不打印、不报错、
                # 永远到不了 main()，现场表现为"脚本卡住"。
                #
                # 用 ${2:-} 而非 "$2"：要表达的是"第 2 个参数不存在或为空"。
                if [[ -z "${2:-}" ]]; then
                    log_error "选项 $1 需要参数"
                    show_help
                    exit 1
                fi
                OUTPUT_DIR="$2"
                shift 2
                ;;
            -s|--serial)
                if [[ -z "${2:-}" ]]; then
                    log_error "选项 $1 需要参数"
                    show_help
                    exit 1
                fi
                SYSTEM_SERIAL="$2"
                # 置位"用户显式指定"标志，使 main 不去自动探测（见 main）。
                SERIAL_EXPLICIT=true
                shift 2
                ;;
            *)
                log_error "未知选项: $1"
                show_help
                exit 1
                ;;
        esac
    done
}

parse_args "$@"
main
