#!/bin/bash
# ============================================================================
# 服务器电源信息收集脚本 - 通用兼容版（v13）
#
# v13 变更（相比 v12）：
#   - ★ 新增 Mock 模式：--mock-dir DIR / MOCK_DIR=DIR
#       · 命令层：run_cmd <key> -- <cmd>
#         - dmidecode → cmd/dmidecode.txt
#         - dmidecode -s system-serial-number → cmd/dmidecode.s.system-serial-number.txt
#         - cat /sys/class/dmi/id/product_serial → cmd/sysfs.product_serial.txt
#         - hostid → cmd/hostid.txt
#         - ipmitool sensor → cmd/ipmitool.sensor.txt
#         - ipmitool dcmi power reading → cmd/ipmitool.dcmi-power-reading.txt
#       · Mock 模式下跳过 sudo 检查与命令存在性检查
#       · 配套 make_psu_mock.sh 生成 mock 数据
#
# v12 变更保留：
#   - psu_model 归一化：去掉末尾的电源序号（"OEM Power Supply 1" → "OEM Power Supply"）
#
# v11 变更保留：
#   - 温度支持"无后缀"匹配
#   - PIN 缺失时用 VIN × IIN 换算
#   - POUT 缺失时用 VOUT × IOUT 换算
#   - 新增 IIN / IOUT 值域规则
#
# 输出列:
#   server_serial,psu_index,psu_vendor,psu_model,psu_type,psu_status,
#   psu_input_voltage_range_switching,psu_plugged,psu_hot_replaceable,
#   psu_revision,psu_serial,psu_power_w,
#   psu_vin_v,psu_pin_w,psu_vout_v,psu_pout_w,
#   psu_hs_temp_c,psu_amb_temp_c,psu_fan_speed_rpm
# ============================================================================

SCRIPT_NAME=$(basename "$0")
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
OUTPUT_DIR="${OUTPUT_DIR:-${SCRIPT_DIR}/report}"
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
OUTPUT_FILE=""
SYSTEM_SERIAL=""
DEBUG="${DEBUG:-false}"
SKIP_IPMI="${SKIP_IPMI:-false}"
PSU_DEBUG="${PSU_DEBUG:-false}"

# ★ v13：Mock 开关
MOCK_DIR="${MOCK_DIR:-}"
MOCK_MODE=false
[[ -n "$MOCK_DIR" ]] && MOCK_MODE=true

DMIDECODE_CACHE=""
DMIDECODE_PSU_BLOCKS=""
IPMITOOL_SENSOR_CACHE=""
IPMITOOL_DCMI_CACHE=""
PSU_INFO_CACHE=""

# 颜色变量（保护性定义，兼容 source 场景）
if [[ -z "${RED:-}" ]]; then
    RED=$'\033[0;31m'
    GREEN=$'\033[0;32m'
    YELLOW=$'\033[1;33m'
    BLUE=$'\033[0;34m'
    MAGENTA=$'\033[0;35m'
    NC=$'\033[0m'
    readonly RED GREEN YELLOW BLUE MAGENTA NC
fi

log_info()   { echo -e "${GREEN}[INFO]${NC} $*" >&2; }
log_warn()   { echo -e "${YELLOW}[WARN]${NC} $*" >&2; }
log_error()  { echo -e "${RED}[ERROR]${NC} $*" >&2; }
log_debug()  { [[ "${DEBUG}" == "true" ]] && echo -e "${BLUE}[DEBUG]${NC} $*" >&2; return 0; }
log_psudbg() { [[ "${PSU_DEBUG}" == "true" ]] && echo -e "${MAGENTA}[PSUDBG]${NC} $*" >&2; return 0; }

print_separator() { echo "=========================================" >&2; }
print_header() {
    print_separator
    echo -e "${GREEN}$1${NC}" >&2
    print_separator
}

csv_escape() {
    local field="$1"
    [[ -z "$field" ]] && { echo ""; return; }
    if echo "$field" | grep -qE '[, "]' ; then
        field=$(echo "$field" | sed 's/"/""/g')
        echo "\"$field\""
    else
        echo "$field"
    fi
}

# ============================================================================
# ★ v13：Mock 基础设施
# ============================================================================

# 命令执行包装：mock 模式从 $MOCK_DIR/cmd/<key>.txt 读，否则执行真命令
run_cmd() {
    local key="$1"; shift
    [[ "$1" == "--" ]] && shift
    if [[ "$MOCK_MODE" == "true" ]]; then
        local f="$MOCK_DIR/cmd/${key}.txt"
        if [[ -r "$f" ]]; then
            cat "$f"
        else
            log_debug "mock 缺失命令: $key ($f)"
        fi
        return 0
    fi
    "$@" 2>/dev/null || true
}

# 命令存在性检查：mock 模式恒真
have_cmd() {
    [[ "$MOCK_MODE" == "true" ]] && return 0
    command -v "$1" &>/dev/null
}

# ============================================================================
# 缓存
# ============================================================================

cache_dmidecode() {
    if [[ -z "$DMIDECODE_CACHE" ]]; then
        log_debug "执行 dmidecode 并缓存结果..."
        DMIDECODE_CACHE=$(run_cmd "dmidecode" -- sudo dmidecode)
    fi
    echo "$DMIDECODE_CACHE"
}

cache_dmidecode_psu_blocks() {
    if [[ -z "$DMIDECODE_PSU_BLOCKS" ]]; then
        local dmidecode_output
        dmidecode_output=$(cache_dmidecode)
        if [[ -n "$dmidecode_output" ]]; then
            log_debug "从dmidecode缓存中提取电源块..."
            DMIDECODE_PSU_BLOCKS=$(printf '%s\n' "$dmidecode_output" | awk '
                BEGIN { block = ""; in_block = 0 }
                /^[[:space:]]*System Power Supply/ {
                    if (in_block == 1 && block != "") {
                        print "===BLOCK_START==="
                        print block
                        print "===BLOCK_END==="
                    }
                    in_block = 1
                    block = $0
                    next
                }
                in_block == 1 {
                    if ($0 == "") {
                        if (block != "") {
                            print "===BLOCK_START==="
                            print block
                            print "===BLOCK_END==="
                        }
                        in_block = 0
                        block = ""
                        next
                    }
                    block = block "\n" $0
                }
                END {
                    if (in_block == 1 && block != "") {
                        print "===BLOCK_START==="
                        print block
                        print "===BLOCK_END==="
                    }
                }
            ')
        else
            DMIDECODE_PSU_BLOCKS=""
        fi
    fi
    echo "$DMIDECODE_PSU_BLOCKS"
}

cache_ipmitool_sensor() {
    if [[ -z "$IPMITOOL_SENSOR_CACHE" ]]; then
        if [[ "$SKIP_IPMI" == "true" ]]; then
            log_debug "SKIP_IPMI=true，跳过 ipmitool sensor"
            IPMITOOL_SENSOR_CACHE="__SKIPPED__"
        elif have_cmd ipmitool; then
            log_debug "执行 ipmitool sensor 并缓存结果（可能较慢）..."
            IPMITOOL_SENSOR_CACHE=$(run_cmd "ipmitool.sensor" -- sudo ipmitool sensor)
        fi
    fi
    if [[ "$IPMITOOL_SENSOR_CACHE" == "__SKIPPED__" ]]; then
        echo ""
    else
        echo "$IPMITOOL_SENSOR_CACHE"
    fi
}

cache_ipmitool_dcmi() {
    if [[ -z "$IPMITOOL_DCMI_CACHE" ]]; then
        if [[ "$SKIP_IPMI" == "true" ]]; then
            IPMITOOL_DCMI_CACHE="__SKIPPED__"
        elif have_cmd ipmitool; then
            log_debug "执行 ipmitool dcmi power reading 并缓存结果..."
            IPMITOOL_DCMI_CACHE=$(run_cmd "ipmitool.dcmi-power-reading" -- sudo ipmitool dcmi power reading)
        fi
    fi
    if [[ "$IPMITOOL_DCMI_CACHE" == "__SKIPPED__" ]]; then
        echo ""
    else
        echo "$IPMITOOL_DCMI_CACHE"
    fi
}

# ============================================================================
# 系统序列号
# ============================================================================

get_serial_from_dmidecode() {
    local serial
    serial=$(run_cmd "dmidecode.s.system-serial-number" -- sudo dmidecode -s system-serial-number | head -1)
    if [[ -n "$serial" && "$serial" != "Not Specified" && "$serial" != "Unknown" ]]; then
        echo "$serial"; return 0
    fi
    return 1
}

get_serial_from_sysfs() {
    local serial
    if [[ "$MOCK_MODE" == "true" ]]; then
        serial=$(run_cmd "sysfs.product_serial" -- cat /sys/class/dmi/id/product_serial)
        if [[ -n "$serial" && "$serial" != "Not Specified" ]]; then
            echo "$serial"; return 0
        fi
        return 1
    fi
    if [[ -f "/sys/class/dmi/id/product_serial" ]]; then
        serial=$(run_cmd "sysfs.product_serial" -- sudo cat /sys/class/dmi/id/product_serial)
        if [[ -n "$serial" && "$serial" != "Not Specified" ]]; then
            echo "$serial"; return 0
        fi
    fi
    return 1
}

get_serial_from_hostid() {
    local serial
    serial=$(run_cmd "hostid" -- hostid)
    if [[ -n "$serial" && "$serial" != "00000000" ]]; then
        echo "$serial"; return 0
    fi
    return 1
}

get_system_serial() {
    local serial=""
    local methods=(get_serial_from_dmidecode get_serial_from_sysfs get_serial_from_hostid)
    log_info "正在获取系统序列号..."
    for method in "${methods[@]}"; do
        if serial=$($method 2>/dev/null); then
            local method_name="${method#get_serial_from_}"
            log_info "通过 ${method_name} 获取到序列号: $serial"
            echo "$serial"
            return 0
        fi
    done
    log_warn "无法获取系统序列号，使用默认值: UNKNOWN"
    echo "UNKNOWN"
    return 1
}

# ============================================================================
# 字段值域规则表
# ============================================================================
_sensor_value_range() {
    case "$1" in
        VIN)         echo "0|400" ;;
        VOUT)        echo "0|100" ;;
        PIN)         echo "0|5000" ;;
        POUT)        echo "0|5000" ;;
        IIN)         echo "0|50" ;;
        IOUT)        echo "0|300" ;;
        Hs_Temp|HsTemp|HSTemp|Temp|TEMP|temp) echo "0|200" ;;
        Amb_Temp|AmbTemp|AMBTemp)             echo "0|200" ;;
        FanSpeed|Fan_Speed|FanRPM|Fan_RPM)    echo "0|100000" ;;
        *)           echo "" ;;
    esac
}

# ============================================================================
# 从 ipmitool sensor 中按 (PSU 索引, 字段名候选) 提取传感器值
# ============================================================================
_get_sensor_field() {
    local idx="$1"; shift
    local -a candidates=("$@")
    [[ ${#candidates[@]} -eq 0 ]] && { echo ""; return; }

    if [[ ! "$idx" =~ ^[0-9]+$ ]] || (( idx < 0 || idx > 15 )); then
        log_psudbg "  _get_sensor_field: 索引越界 idx=[$idx]，跳过"
        echo ""
        return
    fi

    local sdr; sdr=$(cache_ipmitool_sensor)
    [[ -z "$sdr" ]] && { log_psudbg "  _get_sensor_field(idx=$idx): SDR 为空"; echo ""; return; }

    local cand pattern line rest val range min_v max_v
    for cand in "${candidates[@]}"; do
        if [[ -z "$cand" ]]; then
            pattern="^PSU${idx}[[:space:]]*\|"
        else
            pattern="^PSU${idx}_${cand}[[:space:]]*\|"
        fi
        line=$(printf '%s\n' "$sdr" | grep -m1 -i -E "$pattern")
        [[ -z "$line" ]] && continue

        rest="${line#*|}"
        val="${rest%%|*}"
        val="${val#"${val%%[![:space:]]*}"}"
        val="${val%"${val##*[![:space:]]}"}"

        if [[ ! "$val" =~ ^[0-9]+\.?[0-9]*$ ]]; then
            log_psudbg "  _get_sensor_field(idx=$idx, cand='${cand}'): 非数字 [$val]"
            log_psudbg "    原始行: $line"
            continue
        fi

        range=$(_sensor_value_range "$cand")
        if [[ -n "$range" ]]; then
            min_v="${range%|*}"
            max_v="${range#*|}"
            if awk -v v="$val" -v lo="$min_v" -v hi="$max_v" \
                    'BEGIN { exit !(v < lo || v > hi) }'; then
                log_psudbg "  _get_sensor_field(idx=$idx, cand='${cand}'): 值越界 val=$val 不在 [$min_v,$max_v]"
                log_psudbg "    原始行: $line"
                continue
            fi
        fi

        if [[ -z "$cand" ]]; then
            log_psudbg "  ✓ idx=$idx cand=<无后缀> val=$val"
        else
            log_psudbg "  ✓ idx=$idx cand=$cand val=$val"
        fi
        log_psudbg "    原始行: $line"
        echo "$val"
        return
    done

    log_psudbg "  _get_sensor_field(idx=$idx): 全部候选未命中 (${candidates[*]})"
    echo ""
}

# ============================================================================
# 内部PSU缓存格式（19字段，以 | 分隔）
# ============================================================================

parse_psu_from_dmidecode() {
    local blocks
    blocks=$(cache_dmidecode_psu_blocks)
    local psus=()
    local block_num=0
    local current_block=""
    local in_block=false

    [[ -z "$blocks" ]] && { echo ""; return; }

    while IFS= read -r line; do
        if [[ "$line" == "===BLOCK_START===" ]]; then
            in_block=true
            current_block=""
            continue
        elif [[ "$line" == "===BLOCK_END===" ]]; then
            in_block=false
            if [[ -n "$current_block" ]]; then
                local vendor psu_name model_part model serial power
                local revision status psu_type input_voltage plugged hot_replaceable

                vendor=$(printf '%s\n' "$current_block" | grep -i "^[[:space:]]*Manufacturer:" | head -1 | awk -F':' '{print $2}' | sed 's/^[ \t]*//;s/[ \t]*$//')
                psu_name=$(printf '%s\n' "$current_block" | grep -i "^[[:space:]]*Name:" | head -1 | awk -F':' '{print $2}' | sed 's/^[ \t]*//;s/[ \t]*$//')
                model_part=$(printf '%s\n' "$current_block" | grep -i "^[[:space:]]*Model Part Number:" | head -1 | awk -F':' '{print $2}' | sed 's/^[ \t]*//;s/[ \t]*$//')

                model="$psu_name"
                if [[ -z "$model" || "$model" == "Not Specified" || "$model" == "Unknown" || "$model" == "To Be Filled By O.E.M." ]]; then
                    model="$model_part"
                fi

                serial=$(printf '%s\n' "$current_block" | grep -i "^[[:space:]]*Serial Number:" | head -1 | awk -F':' '{print $2}' | sed 's/^[ \t]*//;s/[ \t]*$//')
                power=$(printf '%s\n' "$current_block" | grep -i "^[[:space:]]*Max Power Capacity:" | head -1 | awk -F':' '{print $2}' | sed 's/^[ \t]*//;s/[ \t]*$//' | sed 's/[^0-9]//g')

                revision=$(printf '%s\n' "$current_block" | grep -i "^[[:space:]]*Revision:" | head -1 | awk -F':' '{print $2}' | sed 's/^[ \t]*//;s/[ \t]*$//')
                status=$(printf '%s\n' "$current_block" | grep -i "^[[:space:]]*Status:" | head -1 | awk -F':' '{print $2}' | sed 's/^[ \t]*//;s/[ \t]*$//')
                psu_type=$(printf '%s\n' "$current_block" | grep -i "^[[:space:]]*Type:" | head -1 | awk -F':' '{print $2}' | sed 's/^[ \t]*//;s/[ \t]*$//')
                input_voltage=$(printf '%s\n' "$current_block" | grep -i "^[[:space:]]*Input Voltage Range Switching:" | head -1 | awk -F':' '{print $2}' | sed 's/^[ \t]*//;s/[ \t]*$//')
                plugged=$(printf '%s\n' "$current_block" | grep -i "^[[:space:]]*Plugged:" | head -1 | awk -F':' '{print $2}' | sed 's/^[ \t]*//;s/[ \t]*$//')
                hot_replaceable=$(printf '%s\n' "$current_block" | grep -i "^[[:space:]]*Hot Replaceable:" | head -1 | awk -F':' '{print $2}' | sed 's/^[ \t]*//;s/[ \t]*$//')

                [[ "$vendor" == "Not Specified" || "$vendor" == "Unknown" ]] && vendor=""
                [[ "$model" == "Not Specified" || "$model" == "Unknown" || "$model" == "To Be Filled By O.E.M." ]] && model=""
                [[ "$serial" == "Not Specified" || "$serial" == "Unknown" ]] && serial=""
                [[ -z "$power" ]] && power="0"

                psus+=("$block_num|${vendor:-UNKNOWN}|${model:-UNKNOWN}|${serial:-N/A}|$power|PSU$block_num|${status:-UNKNOWN}|${revision:-N/A}|${psu_type:-N/A}|${input_voltage:-N/A}|${plugged:-N/A}|${hot_replaceable:-N/A}|N/A|N/A|N/A|N/A|N/A|N/A|N/A")
                ((block_num++))
            fi
            continue
        elif [[ "$in_block" == "true" ]]; then
            current_block="$current_block"$'\n'"$line"
        fi
    done <<< "$blocks"

    if [[ ${#psus[@]} -gt 0 ]]; then
        PSU_INFO_CACHE=$(printf '%s\n' "${psus[@]}")
    else
        PSU_INFO_CACHE=""
    fi
    echo "$PSU_INFO_CACHE"
}

# ----------------------------------------------------------------------------
# parse_psu_from_sdr
# ----------------------------------------------------------------------------
parse_psu_from_sdr() {
    local dmidecode_info
    dmidecode_info=$(parse_psu_from_dmidecode)
    local dmidecode_count=0
    [[ -n "$dmidecode_info" ]] && dmidecode_count=$(printf '%s\n' "$dmidecode_info" | grep -c '.')

    if [[ $dmidecode_count -eq 0 ]]; then
        log_debug "dmidecode 无电源块，无法组装"
        echo ""
        return
    fi

    local sdr_base=0
    local probe
    probe=$(_get_sensor_field "0" "VIN")
    [[ -z "$probe" ]] && probe=$(_get_sensor_field "0" "PIN")
    if [[ -z "$probe" ]]; then
        probe=$(_get_sensor_field "1" "VIN")
        [[ -z "$probe" ]] && probe=$(_get_sensor_field "1" "PIN")
        if [[ -n "$probe" ]]; then
            sdr_base=1
            log_debug "SDR 使用基于 1 的 PSU 索引（SDR 中无 PSU0）"
        fi
    fi
    if [[ "$sdr_base" == "0" && -z "$probe" ]]; then
        log_debug "SDR 中未发现 PSU 传感器，使用默认 0 基"
    fi
    log_psudbg "sdr_base = $sdr_base"

    local -A info_array=()
    local out_idx=0

    local idx=0
    while IFS= read -r line; do
        [[ -z "$line" ]] && continue

        local vendor=$(echo "$line" | cut -d'|' -f2)
        local model=$(echo "$line" | cut -d'|' -f3)
        local serial=$(echo "$line" | cut -d'|' -f4)
        local power=$(echo "$line" | cut -d'|' -f5)
        local psu_name=$(echo "$line" | cut -d'|' -f6)
        local status=$(echo "$line" | cut -d'|' -f7)
        local revision=$(echo "$line" | cut -d'|' -f8)
        local psu_type=$(echo "$line" | cut -d'|' -f9)
        local input_voltage=$(echo "$line" | cut -d'|' -f10)
        local plugged=$(echo "$line" | cut -d'|' -f11)
        local hot_replaceable=$(echo "$line" | cut -d'|' -f12)

        local sdr_idx=$((idx + sdr_base))

        local vin vout pin pout iin iout hs_temp amb_temp fan
        vin=$(_get_sensor_field "$sdr_idx" "VIN")
        vout=$(_get_sensor_field "$sdr_idx" "VOUT")
        iin=$(_get_sensor_field "$sdr_idx" "IIN")
        iout=$(_get_sensor_field "$sdr_idx" "IOUT")

        pin=$(_get_sensor_field "$sdr_idx" "PIN")
        if [[ -z "$pin" && -n "$vin" && -n "$iin" ]]; then
            pin=$(awk -v u="$vin" -v i="$iin" 'BEGIN { printf "%.3f", u*i }')
            log_psudbg "PSU$sdr_idx: PIN 直读缺失，估算 = VIN($vin) × IIN($iin) = ${pin} W"
        fi

        pout=$(_get_sensor_field "$sdr_idx" "POUT")
        if [[ -z "$pout" && -n "$vout" && -n "$iout" ]]; then
            pout=$(awk -v u="$vout" -v i="$iout" 'BEGIN { printf "%.3f", u*i }')
            log_psudbg "PSU$sdr_idx: POUT 直读缺失，估算 = VOUT($vout) × IOUT($iout) = ${pout} W"
        fi

        hs_temp=$(_get_sensor_field "$sdr_idx" "Hs_Temp" "HsTemp" "Temp" "")
        amb_temp=$(_get_sensor_field "$sdr_idx" "Amb_Temp" "AmbTemp")
        fan=$(_get_sensor_field "$sdr_idx" "FanSpeed" "Fan_Speed" "FanRPM" "Fan_RPM")

        local has_data=false
        [[ -n "$vin" ]]  && has_data=true
        [[ -n "$pin" ]]  && has_data=true
        [[ -n "$vout" ]] && has_data=true
        [[ -n "$pout" ]] && has_data=true

        if [[ "$has_data" == "false" ]]; then
            log_psudbg "PSU$sdr_idx: 无电压/功率数据，判定为不存在，跳过"
            ((idx++))
            continue
        fi

        [[ -z "$vin" ]]      && vin="N/A"
        [[ -z "$vout" ]]     && vout="N/A"
        [[ -z "$pin" ]]      && pin="N/A"
        [[ -z "$pout" ]]     && pout="N/A"
        [[ -z "$hs_temp" ]]  && hs_temp="N/A"
        [[ -z "$amb_temp" ]] && amb_temp="N/A"
        [[ -z "$fan" ]]      && fan="N/A"

        log_debug "PSU$sdr_idx (src_idx=$idx) -> out_idx=$out_idx: vin=$vin, pin=$pin, vout=$vout, pout=$pout, hs=$hs_temp, amb=$amb_temp, fan=$fan"

        info_array["$out_idx"]="$out_idx|${vendor:-UNKNOWN}|${model:-UNKNOWN}|${serial:-N/A}|${power:-0}|${psu_name:-PSU$out_idx}|${status:-UNKNOWN}|${revision:-N/A}|${psu_type:-N/A}|${input_voltage:-N/A}|${plugged:-N/A}|${hot_replaceable:-N/A}|$vin|$pin|$vout|$pout|$hs_temp|$amb_temp|$fan"
        ((out_idx++))
        ((idx++))
    done <<< "$dmidecode_info"

    log_psudbg "parse_psu_from_sdr 完成: dmidecode=${dmidecode_count} 块, 输出 ${out_idx} 个 PSU"

    if [[ ${#info_array[@]} -gt 0 ]]; then
        local sorted_psus=""
        for idx in $(echo "${!info_array[@]}" | tr ' ' '\n' | sort -n); do
            sorted_psus="$sorted_psus"$'\n'"${info_array[$idx]}"
        done
        PSU_INFO_CACHE=$(printf '%s\n' "$sorted_psus" | sed '/^$/d')
    else
        PSU_INFO_CACHE=""
    fi
    echo "$PSU_INFO_CACHE"
}

# ============================================================================
# 从缓存取字段
# ============================================================================

get_psu_info_from_cache() {
    local psu_idx="$1" field="$2"

    if [[ -z "$PSU_INFO_CACHE" ]]; then
        parse_psu_from_dmidecode > /dev/null
        [[ -z "$PSU_INFO_CACHE" ]] && parse_psu_from_sdr > /dev/null
    fi
    [[ -z "$PSU_INFO_CACHE" ]] && { echo ""; return; }

    local line
    line=$(printf '%s\n' "$PSU_INFO_CACHE" | sed -n "$((psu_idx + 1))p")
    [[ -z "$line" ]] && { echo ""; return; }

    local result=""
    case "$field" in
        vendor)                        result=$(echo "$line" | cut -d'|' -f2) ;;
        model)                         result=$(echo "$line" | cut -d'|' -f3) ;;
        serial)                        result=$(echo "$line" | cut -d'|' -f4) ;;
        power)                         result=$(echo "$line" | cut -d'|' -f5) ;;
        name)                          result=$(echo "$line" | cut -d'|' -f6) ;;
        status)                        result=$(echo "$line" | cut -d'|' -f7) ;;
        revision)                      result=$(echo "$line" | cut -d'|' -f8) ;;
        type)                          result=$(echo "$line" | cut -d'|' -f9) ;;
        input_voltage_range_switching) result=$(echo "$line" | cut -d'|' -f10) ;;
        plugged)                       result=$(echo "$line" | cut -d'|' -f11) ;;
        hot_replaceable)               result=$(echo "$line" | cut -d'|' -f12) ;;
        vin)                           result=$(echo "$line" | cut -d'|' -f13) ;;
        pin)                           result=$(echo "$line" | cut -d'|' -f14) ;;
        vout)                          result=$(echo "$line" | cut -d'|' -f15) ;;
        pout)                          result=$(echo "$line" | cut -d'|' -f16) ;;
        hs_temp)                       result=$(echo "$line" | cut -d'|' -f17) ;;
        amb_temp)                      result=$(echo "$line" | cut -d'|' -f18) ;;
        fan_speed)                     result=$(echo "$line" | cut -d'|' -f19) ;;
        *)                             result="" ;;
    esac

    log_psudbg "get_psu_info_from_cache(idx=$psu_idx, field=$field) -> [$result]"
    echo "$result"
}

# ============================================================================
# 电源数量
# ============================================================================

get_psu_count() {
    local count=0

    if [[ -z "$PSU_INFO_CACHE" ]]; then
        parse_psu_from_dmidecode > /dev/null
        [[ -z "$PSU_INFO_CACHE" ]] && parse_psu_from_sdr > /dev/null
    fi

    if [[ -n "$PSU_INFO_CACHE" ]]; then
        count=$(printf '%s\n' "$PSU_INFO_CACHE" | grep -c '.')
        if [[ -n "$count" && "$count" -gt 0 ]]; then
            echo "$count"; return
        fi
    fi

    echo "0"
}

# ============================================================================
# PSU 型号归一化
# ============================================================================
_normalize_psu_model() {
    local m="$1"
    [[ -z "$m" ]] && { echo ""; return; }

    # 匹配 "任意前缀 + 空格 + 1-2位数字"，前缀最后一个字符不能是空格或数字
    if [[ "$m" =~ ^(.+[^[:space:]0-9])[[:space:]]+[0-9]{1,2}$ ]]; then
        echo "${BASH_REMATCH[1]}"
    else
        echo "$m"
    fi
}

# ============================================================================
# 各字段 getter
# ============================================================================

get_psu_vendor() {
    local v; v=$(get_psu_info_from_cache "$1" "vendor")
    [[ -n "$v" && "$v" != "UNKNOWN" ]] && echo "$v" || echo "UNKNOWN"
}

get_psu_model() {
    local v; v=$(get_psu_info_from_cache "$1" "model")
    [[ -z "$v" || "$v" == "UNKNOWN" ]] && { echo "UNKNOWN"; return; }
    _normalize_psu_model "$v"
}

get_psu_serial() {
    local v; v=$(get_psu_info_from_cache "$1" "serial")
    [[ -n "$v" && "$v" != "N/A" ]] && echo "$v" || echo "N/A"
}

get_psu_power_w() {
    local psu_idx="$1"
    local p; p=$(get_psu_info_from_cache "$psu_idx" "power")
    if [[ -n "$p" && "$p" != "0" ]]; then echo "$p"; return; fi
    if [[ $psu_idx -eq 0 && "$SKIP_IPMI" != "true" ]]; then
        local dcmi_output
        dcmi_output=$(cache_ipmitool_dcmi)
        if [[ -n "$dcmi_output" ]]; then
            p=$(printf '%s\n' "$dcmi_output" | grep -i "Maximum Power" | head -1 | awk -F':' '{print $2}' | sed 's/^[ \t]*//;s/[ \t]*$//' | sed 's/[^0-9]//g')
            [[ -n "$p" && "$p" =~ ^[0-9]+$ ]] && { echo "$p"; return; }
        fi
    fi
    echo "0"
}

get_psu_vin_v() {
    local v; v=$(get_psu_info_from_cache "$1" "vin")
    [[ -n "$v" && "$v" != "N/A" ]] && echo "$v" || echo "N/A"
}

get_psu_pin_w() {
    local v; v=$(get_psu_info_from_cache "$1" "pin")
    [[ -n "$v" && "$v" != "N/A" ]] && echo "$v" || echo "N/A"
}

get_psu_vout_v() {
    local v; v=$(get_psu_info_from_cache "$1" "vout")
    [[ -n "$v" && "$v" != "N/A" ]] && echo "$v" || echo "N/A"
}

get_psu_pout_w() {
    local v; v=$(get_psu_info_from_cache "$1" "pout")
    [[ -n "$v" && "$v" != "N/A" ]] && echo "$v" || echo "N/A"
}

get_psu_hs_temp_c() {
    local v; v=$(get_psu_info_from_cache "$1" "hs_temp")
    [[ -n "$v" && "$v" != "N/A" ]] && echo "$v" || echo "N/A"
}

get_psu_amb_temp_c() {
    local v; v=$(get_psu_info_from_cache "$1" "amb_temp")
    [[ -n "$v" && "$v" != "N/A" ]] && echo "$v" || echo "N/A"
}

get_psu_fan_speed_rpm() {
    local v; v=$(get_psu_info_from_cache "$1" "fan_speed")
    [[ -n "$v" && "$v" != "N/A" ]] && echo "$v" || echo "N/A"
}

get_psu_revision() {
    local v; v=$(get_psu_info_from_cache "$1" "revision")
    [[ -n "$v" && "$v" != "N/A" ]] && echo "$v" || echo "N/A"
}

get_psu_status() {
    local v; v=$(get_psu_info_from_cache "$1" "status")
    [[ -n "$v" && "$v" != "UNKNOWN" ]] && echo "$v" || echo "UNKNOWN"
}

get_psu_type() {
    local v; v=$(get_psu_info_from_cache "$1" "type")
    [[ -n "$v" && "$v" != "N/A" ]] && echo "$v" || echo "N/A"
}

get_psu_input_voltage_range_switching() {
    local v; v=$(get_psu_info_from_cache "$1" "input_voltage_range_switching")
    [[ -n "$v" && "$v" != "N/A" ]] && echo "$v" || echo "N/A"
}

get_psu_plugged() {
    local v; v=$(get_psu_info_from_cache "$1" "plugged")
    [[ -n "$v" && "$v" != "N/A" ]] && echo "$v" || echo "N/A"
}

get_psu_hot_replaceable() {
    local v; v=$(get_psu_info_from_cache "$1" "hot_replaceable")
    [[ -n "$v" && "$v" != "N/A" ]] && echo "$v" || echo "N/A"
}

# ============================================================================
# CSV
# ============================================================================

generate_output_filename() {
    local serial="$1"
    local dir="${OUTPUT_DIR}"
    local clean_serial
    clean_serial=$(echo "$serial" | sed 's/[^a-zA-Z0-9_-]//g')
    if [[ -z "$clean_serial" || "$clean_serial" == "UNKNOWN" ]]; then
        echo "${dir}/psu_info.csv"
    else
        echo "${dir}/psu_info_${clean_serial}.csv"
    fi
}

write_csv_header() {
    local output_file="$1"
    local header="server_serial,psu_index,psu_vendor,psu_model,psu_type,psu_status,psu_input_voltage_range_switching,psu_plugged,psu_hot_replaceable,psu_revision,psu_serial,psu_power_w,psu_vin_v,psu_pin_w,psu_vout_v,psu_pout_w,psu_hs_temp_c,psu_amb_temp_c,psu_fan_speed_rpm"
    if ! printf '%s\n' "$header" > "$output_file" 2>/dev/null; then
        log_error "无法写入CSV文件: $output_file"
        return 1
    fi
    log_debug "CSV头已写入: $output_file"
    return 0
}

# ============================================================================
# 主收集
# ============================================================================

collect_psu_info() {
    local serial="$1"
    local output_file="$2"

    log_info "正在收集电源信息..."

    cache_dmidecode
    cache_ipmitool_sensor
    cache_ipmitool_dcmi

    parse_psu_from_dmidecode > /dev/null
    parse_psu_from_sdr > /dev/null

    local psu_count
    psu_count=$(get_psu_count)

    if [[ "$psu_count" -gt 16 ]]; then
        log_warn "检测到 $psu_count 个电源，可能解析有误，限制为最大16个"
        psu_count=16
    fi

    log_info "检测到 $psu_count 个电源"
    [[ "$psu_count" -eq 0 ]] && { log_warn "未检测到电源设备！"; return 0; }

    local record_count=0

    for ((psu_idx=0; psu_idx<psu_count; psu_idx++)); do
        log_debug "正在处理电源 $psu_idx"

        local vendor model psu_type status input_voltage plugged hot_replaceable
        local revision psu_serial power psu_name
        local vin pin vout pout hs_temp amb_temp fan

        vendor=$(get_psu_vendor "$psu_idx")
        model=$(get_psu_model "$psu_idx")
        psu_type=$(get_psu_type "$psu_idx")
        status=$(get_psu_status "$psu_idx")
        input_voltage=$(get_psu_input_voltage_range_switching "$psu_idx")
        plugged=$(get_psu_plugged "$psu_idx")
        hot_replaceable=$(get_psu_hot_replaceable "$psu_idx")
        revision=$(get_psu_revision "$psu_idx")
        psu_serial=$(get_psu_serial "$psu_idx")
        power=$(get_psu_power_w "$psu_idx")
        psu_name=$(get_psu_info_from_cache "$psu_idx" "name")

        vin=$(get_psu_vin_v "$psu_idx")
        pin=$(get_psu_pin_w "$psu_idx")
        vout=$(get_psu_vout_v "$psu_idx")
        pout=$(get_psu_pout_w "$psu_idx")
        hs_temp=$(get_psu_hs_temp_c "$psu_idx")
        amb_temp=$(get_psu_amb_temp_c "$psu_idx")
        fan=$(get_psu_fan_speed_rpm "$psu_idx")

        local line
        line="$(csv_escape "$serial"),$(csv_escape "$psu_idx"),$(csv_escape "$vendor"),$(csv_escape "$model"),$(csv_escape "$psu_type"),$(csv_escape "$status"),$(csv_escape "$input_voltage"),$(csv_escape "$plugged"),$(csv_escape "$hot_replaceable"),$(csv_escape "$revision"),$(csv_escape "$psu_serial"),$(csv_escape "$power"),$(csv_escape "$vin"),$(csv_escape "$pin"),$(csv_escape "$vout"),$(csv_escape "$pout"),$(csv_escape "$hs_temp"),$(csv_escape "$amb_temp"),$(csv_escape "$fan")"

        if ! printf '%s\n' "$line" >> "$output_file" 2>/dev/null; then
            log_error "无法写入CSV文件: $output_file"
            break
        fi

        ((record_count++))

        log_info "✅ 电源 $psu_idx (${psu_name:-PSU$psu_idx}): $vendor, $model, Type:$psu_type, Status:$status, Rev:$revision, SN:$psu_serial, 额定:${power}W, Vin:${vin}V, Pin:${pin}W, Vout:${vout}V, Pout:${pout}W, Hs:${hs_temp}°C, Amb:${amb_temp}°C, Fan:${fan}RPM"
    done

    echo "$record_count"
}

# ============================================================================
# main
# ============================================================================

main() {
    print_header "服务器电源信息收集工具 - 通用兼容版（v13）"

    if [[ "$MOCK_MODE" == "true" ]]; then
        log_info "🧪 Mock 模式: MOCK_DIR=$MOCK_DIR"
    fi

    if [[ "$PSU_DEBUG" == "true" ]]; then
        log_info "PSU_DEBUG=true，将输出详细调试信息（前缀 [PSUDBG]）"
    fi

    SYSTEM_SERIAL=$(get_system_serial)
    OUTPUT_FILE=$(generate_output_filename "$SYSTEM_SERIAL")

    have_cmd dmidecode || {
        log_warn "dmidecode 未安装，无法获取电源硬件信息"
        echo "  - CentOS/RHEL: yum install -y dmidecode" >&2
        echo "  - Ubuntu/Debian: apt-get install -y dmidecode" >&2
    }

    if [[ "$SKIP_IPMI" != "true" ]]; then
        have_cmd ipmitool || {
            log_warn "ipmitool 未安装，温度和实时功率可能无法获取"
            echo "  请安装: yum install -y ipmitool 或 apt-get install -y ipmitool" >&2
        }
    fi

    # ★ v13：Mock 模式下跳过 sudo 检查
    if [[ "$MOCK_MODE" != "true" ]]; then
        if ! sudo -n true 2>/dev/null; then
            if [[ -t 0 && -r /dev/tty ]]; then
                log_warn "需要sudo权限获取硬件信息，尝试获取..."
                if ! sudo -v 2>/dev/null; then
                    log_warn "无法获取sudo权限，部分信息可能不完整"
                    read -p "是否继续执行（部分信息可能不完整）？[y/N] " -n 1 -r < /dev/tty
                    echo >&2
                    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
                        exit 1
                    fi
                fi
            else
                log_warn "非交互环境，且当前无免密sudo，部分信息可能不完整，将继续执行"
            fi
        fi
    fi

    if [[ ! -d "$OUTPUT_DIR" ]]; then
        if ! mkdir -p "$OUTPUT_DIR" 2>/dev/null; then
            log_error "无法创建输出目录: $OUTPUT_DIR"
            exit 1
        fi
    fi

    if ! write_csv_header "$OUTPUT_FILE"; then
        exit 1
    fi

    local record_count
    record_count=$(collect_psu_info "$SYSTEM_SERIAL" "$OUTPUT_FILE")
    record_count=${record_count:-0}

    print_separator
    echo -e "${GREEN}✅ 完成！${NC}" >&2
    print_separator
    echo -e "📁 输出文件: ${BLUE}$OUTPUT_FILE${NC}" >&2

    if [[ -f "$OUTPUT_FILE" ]]; then
        local line_count
        line_count=$(($(wc -l < "$OUTPUT_FILE") - 1))
        [[ "$line_count" -lt 0 ]] && line_count=0
        echo -e "📊 电源记录: ${BLUE}$line_count${NC} 条" >&2
        print_separator
        echo -e "${YELLOW}📄 内容预览:${NC}" >&2
        print_separator
        cat "$OUTPUT_FILE"
        print_separator
    else
        log_error "输出文件生成失败"
        exit 1
    fi
}

# ============================================================================
# 入口
# ============================================================================

set -o pipefail 2>/dev/null || true

show_help() {
    cat << EOF
服务器电源信息收集工具 - 通用兼容版（v13）

用法: $SCRIPT_NAME [选项]

选项:
    -h, --help          显示此帮助信息
    -d, --debug         启用调试模式
    -o, --output DIR    指定输出目录
    -s, --serial SN     手动指定系统序列号
        --skip-ipmi     跳过 ipmitool 调用
    --mock-dir DIR      ★ Mock 模式：从 DIR 读取命令输出

环境变量:
    PSU_DEBUG=true      打印 PSU 解析中间信息（前缀 [PSUDBG]）
    SKIP_IPMI=true      等同于 --skip-ipmi
    DEBUG=true          等同于 --debug
    OUTPUT_DIR=DIR      等同于 --output DIR
    MOCK_DIR=DIR        等同于 --mock-dir DIR

调试用法:
    PSU_DEBUG=true sudo -E $SCRIPT_NAME -d 2>&1 | tee run.log
    grep '\[PSUDBG\]' run.log

Mock 模式说明:
    Mock 模式下所有外部命令改为从 \$MOCK_DIR/cmd/<key>.txt 读取：
      cmd/dmidecode.txt                       # 完整 dmidecode（含电源块）
      cmd/dmidecode.s.system-serial-number.txt
      cmd/sysfs.product_serial.txt
      cmd/hostid.txt
      cmd/ipmitool.sensor.txt
      cmd/ipmitool.dcmi-power-reading.txt
    由配套的 make_psu_mock.sh 生成。

输出列:
    server_serial,psu_index,psu_vendor,psu_model,psu_type,psu_status,
    psu_input_voltage_range_switching,psu_plugged,psu_hot_replaceable,
    psu_revision,psu_serial,psu_power_w,
    psu_vin_v,psu_pin_w,psu_vout_v,psu_pout_w,
    psu_hs_temp_c,psu_amb_temp_c,psu_fan_speed_rpm

v13 变更:
    - 新增 --mock-dir / MOCK_DIR 支持
    - 所有外部命令走 run_cmd 包装
    - Mock 模式下跳过 sudo 检查与命令存在性检查

v12 变更:
    - psu_model 归一化：去掉末尾的电源序号

v11 变更:
    - 温度支持"无后缀"匹配
    - POUT 缺失时用 VOUT × IOUT 换算
    - PIN 缺失时用 VIN × IIN 换算

字段来源与推导:
    psu_vin_v        ← PSU<N>_VIN 直读
    psu_pin_w        ← PSU<N>_PIN 直读；缺失时 VIN × IIN 换算
    psu_vout_v       ← PSU<N>_VOUT 直读
    psu_pout_w       ← PSU<N>_POUT 直读；缺失时 VOUT × IOUT 换算
    psu_hs_temp_c    ← PSU<N>_Hs_Temp / PSU<N>_Temp / PSU<N>（无后缀）
    psu_amb_temp_c   ← PSU<N>_Amb_Temp（部分机型无此字段，显示 N/A）
    psu_fan_speed_rpm← PSU<N>_FanSpeed 等（多数 BMC 无 PSU 独立风扇传感器）
EOF
}

parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)      show_help; exit 0 ;;
            -d|--debug)     DEBUG="true"; shift ;;
            -o|--output)    OUTPUT_DIR="$2"; shift 2 ;;
            -s|--serial)    SYSTEM_SERIAL="$2"; shift 2 ;;
            --skip-ipmi)    SKIP_IPMI="true"; shift ;;
            --mock-dir)     MOCK_DIR="$2"; MOCK_MODE=true; shift 2 ;;
            *)              log_error "未知选项: $1"; show_help; exit 1 ;;
        esac
    done
}

parse_args "$@"
main

# ============================================================================
# 结束
# ============================================================================
