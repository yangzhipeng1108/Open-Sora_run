#!/bin/bash
# ============================================================================
# 服务器基础信息收集脚本 - v23
#
# v23 变更：
#   - ★ summarize_ib：IB 摘要格式简化为
#       <ib_vendor> <ib_model> <ib_cap_speed_gb>g <ib_port_num> x N
#       不再展示 ib_cur_speed_gb（当前速率）
#       例：Mellanox "MT2910 Family [ConnectX-7]" 400g 1P x 1
#     上游 collect_ib.sh 的字段索引保持不变：
#       vendor  = ff[2]
#       model   = ff[3]
#       cap     = ff[6]    （ib_cap_speed_gb，HCA 能力上限）
#       portnum = ff[8]    （ib_port_num）
#       card    = ff[13]   （nic_pcie_bus_id，去重 key）
#     （cur = ff[7] 仍存在于 CSV，只是不参与摘要）
#
# v22 变更保留：
#   - summarize_ib：适配 IB CSV 字段变化
#       ib_speed_gb → ib_cap_speed_gb + ib_cur_speed_gb
#
# v21 变更保留：
#   - summarize_gpu：适配 GPU CSV 字段 gpu_memory_gib → gpu_memory_mib
#       上游 collect_gpu.sh 已把显存恢复为 memory.total 原始 MiB 值，
#       汇总侧按 gib = int(mib/1024 + 0.5) 换算为整数 GiB 展示
#
# v19 修复保留：
#   - summarize_raid：新增 _bbu_absent() 识别"无 BBU"语义值
#
# v18 优化保留：
#   - 抽取共享的 AWK CSV 解析器（_AWK_CSV_PARSER）
#   - 新增 summarize_with_awk 辅助函数
#   - 集中路径解析 resolve_output_dir()
#   - sudo 探测缓存（SUDO_OK/SUDO_ERR）
#   - 缺失文件时明确 log_debug
# ============================================================================

SCRIPT_NAME=$(basename "$0")
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

resolve_output_dir() {
    local d="${OUTPUT_DIR:-${SCRIPT_DIR}/report}"
    case "$d" in
        /*) : ;;
        *)  d="${PWD}/${d}" ;;
    esac
    d="${d%/}"
    printf '%s' "$d"
}
OUTPUT_DIR="$(resolve_output_dir)"

DEBUG="${DEBUG:-false}"

DMIDECODE_CACHE=""
IPMITOOL_LAN_CACHE=""
OFED_VERSION_CACHE=""
SUDO_OK=""

readonly RED='\033[0;31m'
readonly GREEN='\033[0;32m'
readonly YELLOW='\033[1;33m'
readonly BLUE='\033[0;34m'
readonly NC='\033[0m'

log_info()  { echo -e "${GREEN}[INFO]${NC} $*" >&2; }
log_warn()  { echo -e "${YELLOW}[WARN]${NC} $*" >&2; }
log_error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }
log_debug() { [[ "${DEBUG}" == "true" ]] && echo -e "${BLUE}[DEBUG]${NC} $*" >&2 || true; }

print_separator() { echo "=========================================" >&2; }
print_header() {
    print_separator
    echo -e "${GREEN}$1${NC}" >&2
    print_separator
}

# ============================================================================
# sudo 探测（只跑一次）
# ============================================================================

detect_sudo() {
    [[ -n "$SUDO_OK" ]] && { [[ "$SUDO_OK" == "yes" ]] && return 0 || return 1; }

    if [[ "$(id -u)" -eq 0 ]]; then
        SUDO_OK="yes"; return 0
    fi
    if ! command -v sudo &>/dev/null; then
        SUDO_OK="no"; return 1
    fi
    if sudo -n true 2>/dev/null; then
        SUDO_OK="yes"; return 0
    fi
    if [[ -t 0 && -r /dev/tty ]]; then
        log_warn "需要 sudo 权限获取硬件信息，尝试认证..."
        if sudo -v 2>/dev/null; then
            SUDO_OK="yes"; return 0
        fi
    fi
    SUDO_OK="no"
    return 1
}

# ============================================================================
# CSV 转义
# ============================================================================

csv_escape() {
    local field="$1"
    if [[ -z "$field" ]]; then
        printf ''
        return
    fi
    if [[ "$field" == *","* || "$field" == *"\""* || "$field" == *$'\n'* ]]; then
        field=$(printf '%s' "$field" | sed 's/"/""/g')
        printf '"%s"' "$field"
    else
        printf '%s' "$field"
    fi
}

# ============================================================================
# 缓存
# ============================================================================

cache_dmidecode() {
    if [[ -z "$DMIDECODE_CACHE" ]]; then
        log_debug "执行 dmidecode 并缓存结果..."
        DMIDECODE_CACHE=$(sudo dmidecode 2>/dev/null || true)
    fi
    echo "$DMIDECODE_CACHE"
}

cache_ipmitool_lan() {
    if [[ -z "$IPMITOOL_LAN_CACHE" ]]; then
        if command -v ipmitool &>/dev/null; then
            log_debug "执行 ipmitool lan print 并缓存结果..."
            IPMITOOL_LAN_CACHE=$(sudo ipmitool lan print 1 2>/dev/null || true)
            if [[ -z "$IPMITOOL_LAN_CACHE" ]]; then
                IPMITOOL_LAN_CACHE=$(sudo ipmitool lan print 2 2>/dev/null || true)
            fi
        else
            IPMITOOL_LAN_CACHE="__NONE__"
        fi
    fi
    [[ "$IPMITOOL_LAN_CACHE" == "__NONE__" ]] && echo "" || echo "$IPMITOOL_LAN_CACHE"
}

# ============================================================================
# 系统序列号
# ============================================================================

get_serial_from_dmidecode() {
    local serial=""
    serial=$(sudo dmidecode -s system-serial-number 2>/dev/null | head -1)
    if [[ -n "$serial" ]] && [[ "$serial" != "Not Specified" ]] && [[ "$serial" != "Unknown" ]]; then
        echo "$serial"; return 0
    fi
    return 1
}

get_serial_from_sysfs() {
    local serial=""
    if [[ -f "/sys/class/dmi/id/product_serial" ]]; then
        serial=$(sudo cat /sys/class/dmi/id/product_serial 2>/dev/null)
        if [[ -n "$serial" ]] && [[ "$serial" != "Not Specified" ]]; then
            echo "$serial"; return 0
        fi
    fi
    return 1
}

get_serial_from_hostid() {
    local serial=""
    serial=$(hostid 2>/dev/null)
    if [[ -n "$serial" ]] && [[ "$serial" != "00000000" ]]; then
        echo "$serial"; return 0
    fi
    return 1
}

get_system_serial() {
    local serial=""
    local methods=(
        "get_serial_from_dmidecode"
        "get_serial_from_sysfs"
        "get_serial_from_hostid"
    )
    log_info "正在获取系统序列号..."
    for method in "${methods[@]}"; do
        if serial=$($method 2>/dev/null); then
            log_info "通过 ${method#get_serial_from_} 获取到序列号: $serial"
            echo "$serial"
            return 0
        fi
    done
    log_warn "无法获取系统序列号，使用默认值: UNKNOWN"
    echo "UNKNOWN"
    return 1
}

# ============================================================================
# 服务器基础信息
# ============================================================================

_dmi_first() {
    local section="$1" key="$2"
    local out; out=$(cache_dmidecode)
    [[ -z "$out" ]] && return
    echo "$out" | awk -v sec="$section" -v k="$key" '
        $0 ~ "^"sec { f=1; next }
        /^Handle / { if (f) exit }
        f && $0 ~ "^[[:space:]]*"k":" {
            sub("^[[:space:]]*"k":[[:space:]]*", "")
            print; exit
        }
    '
}

_dmi_first_global() {
    local key="$1"
    local out; out=$(cache_dmidecode)
    [[ -z "$out" ]] && return
    echo "$out" | awk -v k="$key" '
        $0 ~ "^[[:space:]]*"k":" {
            sub("^[[:space:]]*"k":[[:space:]]*", "")
            print; exit
        }
    '
}

get_server_vendor() {
    local v
    v=$(_dmi_first_global "Manufacturer")
    [[ -n "$v" && "$v" != "Not Specified" && "$v" != "Unknown" ]] && { echo "$v"; return; }
    for f in /sys/class/dmi/id/sys_vendor /sys/class/dmi/id/board_vendor; do
        if [[ -f "$f" ]]; then
            v=$(cat "$f" 2>/dev/null | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
            [[ -n "$v" ]] && { echo "$v"; return; }
        fi
    done
    echo "UNKNOWN"
}

get_server_model() {
    local m
    m=$(_dmi_first_global "Product Name")
    [[ -n "$m" && "$m" != "Not Specified" && "$m" != "Unknown" ]] && { echo "$m"; return; }
    for f in /sys/class/dmi/id/product_name /sys/class/dmi/id/board_name; do
        if [[ -f "$f" ]]; then
            m=$(cat "$f" 2>/dev/null | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
            [[ -n "$m" ]] && { echo "$m"; return; }
        fi
    done
    echo "UNKNOWN"
}

get_server_uuid() {
    local u
    u=$(sudo dmidecode -s system-uuid 2>/dev/null | head -1 | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
    if [[ -n "$u" && "$u" != "Not Settable" && "$u" != "Not Present" && "$u" != "Unknown" ]]; then
        echo "$u"; return
    fi
    u=$(_dmi_first_global "UUID")
    [[ -n "$u" && "$u" != "Not Settable" && "$u" != "Not Present" ]] && { echo "$u"; return; }
    if [[ -f "/sys/class/dmi/id/product_uuid" ]]; then
        u=$(sudo cat "/sys/class/dmi/id/product_uuid" 2>/dev/null | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
        [[ -n "$u" ]] && { echo "$u"; return; }
    fi
    echo "N/A"
}

_sysfs_or_dmi() {
    local sysfile="$1" section="$2" key="$3" default="${4:-N/A}"
    local v
    if [[ -f "$sysfile" ]]; then
        v=$(cat "$sysfile" 2>/dev/null | head -1 | sed 's/^[[:space:]]*//;s/[[:space:]]*$//')
        [[ -n "$v" && "$v" != "Not Specified" ]] && { echo "$v"; return; }
    fi
    v=$(_dmi_first "$section" "$key")
    [[ -n "$v" && "$v" != "Not Specified" ]] && { echo "$v"; return; }
    echo "$default"
}

get_bios_vendor() {
    _sysfs_or_dmi "/sys/class/dmi/id/bios_vendor" "BIOS Information" "Vendor" "N/A"
}

get_bios_release_date() {
    _sysfs_or_dmi "/sys/class/dmi/id/bios_date" "BIOS Information" "Release Date" "N/A"
}

get_bios_version() {
    _sysfs_or_dmi "/sys/class/dmi/id/bios_version" "BIOS Information" "Version" "N/A"
}

get_bios_revision() {
    _sysfs_or_dmi "" "BIOS Information" "BIOS Revision" "N/A"
}

get_board_product_name() {
    _sysfs_or_dmi "/sys/class/dmi/id/board_name" "Base Board Information" "Product Name" "N/A"
}

get_board_serial() {
    _sysfs_or_dmi "/sys/class/dmi/id/board_serial" "Base Board Information" "Serial Number" "N/A"
}

get_board_version() {
    _sysfs_or_dmi "/sys/class/dmi/id/board_version" "Base Board Information" "Version" "N/A"
}

get_chassis_asset_tag() {
    _sysfs_or_dmi "/sys/class/dmi/id/chassis_asset_tag" "Chassis Information" "Asset Tag" "N/A"
}

# ---- IPMI ----

_get_ipmi_field() {
    local pattern="$1"
    local out; out=$(cache_ipmitool_lan)
    [[ -z "$out" ]] && return
    echo "$out" | grep -iE "^[[:space:]]*${pattern}[[:space:]]*:" | grep -v "Source" | head -1 \
        | sed 's/^[^:]*:[[:space:]]*//;s/[[:space:]]*$//'
}

get_ipmi_ip() {
    local v; v=$(_get_ipmi_field "IP Address")
    if [[ -n "$v" && "$v" != "0.0.0.0" && "$v" != "255.255.255.255" ]]; then
        echo "$v"; return
    fi
    echo "N/A"
}

get_ipmi_subnet_mask() {
    local v; v=$(_get_ipmi_field "Subnet Mask")
    [[ -n "$v" && "$v" != "0.0.0.0" ]] && { echo "$v"; return; }
    echo "N/A"
}

get_ipmi_gateway_ip() {
    local v; v=$(_get_ipmi_field "Default Gateway IP")
    [[ -n "$v" && "$v" != "0.0.0.0" ]] && { echo "$v"; return; }
    echo "N/A"
}

get_ipmi_mac() {
    local v; v=$(_get_ipmi_field "MAC Address")
    if [[ -n "$v" && "$v" != "00:00:00:00:00:00" && "$v" != "FF:FF:FF:FF:FF:FF" ]]; then
        echo "$v"; return
    fi
    echo "N/A"
}

get_bmc_version() {
    local v
    if command -v ipmitool &>/dev/null; then
        v=$(sudo ipmitool mc info 2>/dev/null | grep -i "Firmware Revision" | head -1 \
            | sed 's/^[^:]*:[[:space:]]*//;s/[[:space:]]*$//')
        [[ -n "$v" && "$v" != "0.00" ]] && { echo "$v"; return; }
    fi
    v=$(_dmi_first "BMC" "Firmware Revision")
    [[ -n "$v" && "$v" != "Not Specified" ]] && { echo "$v"; return; }
    if [[ -d "/sys/class/ipmi" ]]; then
        local dev
        for dev in /sys/class/ipmi/*; do
            if [[ -f "$dev/firmware_revision" ]]; then
                v=$(cat "$dev/firmware_revision" 2>/dev/null)
                [[ -n "$v" ]] && { echo "$v"; return; }
            fi
        done
    fi
    echo "N/A"
}

# ---- OS / Kernel ----

get_os_type() {
    local os="" ver=""
    if [[ -f "/etc/os-release" ]]; then
        os=$(grep -i "^ID=" /etc/os-release 2>/dev/null | head -1 | sed 's/ID=//;s/^[[:space:]]*//;s/[[:space:]]*$//;s/"//g')
        ver=$(grep -i "^VERSION_ID=" /etc/os-release 2>/dev/null | head -1 | sed 's/VERSION_ID=//;s/^[[:space:]]*//;s/[[:space:]]*$//;s/"//g')
        if [[ -n "$os" ]]; then
            [[ -n "$ver" ]] && { echo "${os} ${ver}"; return; }
            echo "$os"; return
        fi
    fi
    if command -v lsb_release &>/dev/null; then
        os=$(lsb_release -ds 2>/dev/null | sed 's/"//g')
        [[ -n "$os" ]] && { echo "$os"; return; }
    fi
    [[ -f "/etc/issue" ]] && { os=$(head -1 /etc/issue 2>/dev/null | sed 's/\\n//g;s/\\l//g;s/^[[:space:]]*//;s/[[:space:]]*$//'); }
    [[ -z "$os" ]] && os=$(uname -s 2>/dev/null)
    echo "${os:-UNKNOWN}"
}

get_kernel_version() {
    local k; k=$(uname -r 2>/dev/null)
    [[ -n "$k" ]] && { echo "$k"; return; }
    [[ -f "/proc/version" ]] && k=$(head -1 /proc/version 2>/dev/null | awk '{print $3}')
    echo "${k:-N/A}"
}

get_ofed_version() {
    [[ -n "$OFED_VERSION_CACHE" ]] && { echo "$OFED_VERSION_CACHE"; return; }
    local v=""
    if command -v ofed_info &>/dev/null; then
        v=$(ofed_info -s 2>/dev/null | head -1 | sed 's/^[[:space:]]*//;s/[[:space:]]*$//;s/:$//')
        [[ -n "$v" ]] && { OFED_VERSION_CACHE="$v"; echo "$v"; return; }
    fi
    if [[ -x "/usr/bin/ofed_info" ]]; then
        v=$(/usr/bin/ofed_info -s 2>/dev/null | head -1 | sed 's/^[[:space:]]*//;s/[[:space:]]*$//;s/:$//')
        [[ -n "$v" ]] && { OFED_VERSION_CACHE="$v"; echo "$v"; return; }
    fi
    if command -v rpm &>/dev/null; then
        v=$(rpm -qa 2>/dev/null | grep -E "^MLNX_OFED|^ofed" | head -1)
        [[ -n "$v" ]] && { OFED_VERSION_CACHE="$v"; echo "$v"; return; }
    fi
    if [[ -f "/sys/module/mlx5_core/version" ]]; then
        v=$(cat /sys/module/mlx5_core/version 2>/dev/null | tr -d ' \n')
        [[ -n "$v" ]] && { v="mlx5_core-${v}"; OFED_VERSION_CACHE="$v"; echo "$v"; return; }
    fi
    OFED_VERSION_CACHE="N/A"
    echo "N/A"
}

# ============================================================================
# 组件汇总 —— 共享 AWK 解析器
# ============================================================================

read -r -d '' _AWK_CSV_PARSER << 'AWKEOF' || true
function parse_csv(line, ff,   i, c, len, in_q, cur, n, nc) {
    len = length(line); in_q = 0; cur = ""; n = 0; i = 1
    while (i <= len) {
        c = substr(line, i, 1)
        if (in_q) {
            if (c == "\"") {
                nc = substr(line, i+1, 1)
                if (nc == "\"") { cur = cur "\""; i += 2 }
                else { in_q = 0; i += 1 }
            } else { cur = cur c; i += 1 }
        } else {
            if (c == "\"") { in_q = 1; i += 1 }
            else if (c == ",") { ff[++n] = cur; cur = ""; i += 1 }
            else { cur = cur c; i += 1 }
        }
    }
    ff[++n] = cur
    return n
}
function sorted_keys(cnt, keys,   n, i, j, t, k) {
    for (k in cnt) keys[++n] = k
    for (i = 1; i <= n; i++)
        for (j = i + 1; j <= n; j++)
            if (keys[i] > keys[j]) { t = keys[i]; keys[i] = keys[j]; keys[j] = t }
    return n
}
AWKEOF

summarize_with_awk() {
    local file="$1" body="$2" label="$3"
    if [[ ! -f "$file" ]]; then
        log_debug "[汇总 $label] 文件不存在: $file"
        echo ""
        return
    fi
    if [[ ! -s "$file" ]]; then
        log_debug "[汇总 $label] 文件为空: $file"
        echo ""
        return
    fi
    awk "${_AWK_CSV_PARSER}
${body}" "$file"
}

# ---------- CPU ----------
summarize_cpu() {
    summarize_with_awk "$1" '
        NR > 1 {
            line = $0; sub(/\r$/, "", line)
            parse_csv(line, ff)
            v = ff[5]
            if (v == "" || v == "N/A" || v == "UNKNOWN") next
            cnt[v]++
        }
        END {
            n = sorted_keys(cnt, keys)
            for (i = 1; i <= n; i++) printf "%s x %d\n", keys[i], cnt[keys[i]]
        }
    ' "CPU"
}

# ---------- MEM summary ----------
summarize_mem() {
    summarize_with_awk "$1" '
        NR > 1 {
            line = $0; sub(/\r$/, "", line)
            parse_csv(line, ff)
            mt = ff[2]; mv = ff[3]; mp = ff[4]; mc = ff[5]; ms = ff[6]
            if (mp == "" || mp == "N/A") next
            if (ms == "" || ms == "N/A") ms = "?"
            if (mc == "" || mc == "N/A") mc = "?"
            cnt[mt "|" mv "|" mp "|" mc "|" ms]++
        }
        END {
            n = sorted_keys(cnt, keys)
            for (i = 1; i <= n; i++) {
                split(keys[i], p, "|")
                printf "%s %s %s %sMhz %sG x %d\n", p[1], p[2], p[3], p[4], p[5], cnt[keys[i]]
            }
        }
    ' "MEM"
}

# ---------- MEM total ----------
summarize_mem_total() {
    local file="$1"
    if [[ ! -f "$file" || ! -s "$file" ]]; then
        log_debug "[汇总 MEM_TOTAL] 文件不存在或为空: $file"
        echo "N/A"
        return
    fi
    awk "${_AWK_CSV_PARSER}"'
        NR > 1 {
            line = $0; sub(/\r$/, "", line)
            parse_csv(line, ff)
            s = ff[6]
            if (s ~ /^[0-9]+$/) total += s
        }
        END {
            if (total > 0) printf "%dGB\n", total
            else print "N/A"
        }
    ' "$file"
}

# ---------- DRIVE ----------
summarize_drive() {
    summarize_with_awk "$1" '
        NR > 1 {
            line = $0; sub(/\r$/, "", line)
            parse_csv(line, ff)
            dt = ff[2]; dv = ff[3]; dm = ff[4]; ds = ff[7]
            if (dm == "" || dm == "N/A") next
            if (ds == "" || ds == "N/A") ds = "?"
            cnt[dt "|" dv "|" dm "|" ds]++
        }
        END {
            n = sorted_keys(cnt, keys)
            for (i = 1; i <= n; i++) {
                split(keys[i], p, "|")
                printf "%s %s %s %sGB x %d\n", p[1], p[2], p[3], p[4], cnt[keys[i]]
            }
        }
    ' "DRIVE"
}

# ---------- RAID ----------
# v19：_bbu_absent()，"无电池"类值不再被当作 BBU
summarize_raid() {
    summarize_with_awk "$1" '
        function _bbu_absent(v) {
            if (v == "") return 1
            if (v == "N/A" || v == "NA" || v == "na" || v == "n/a") return 1
            if (v == "-") return 1
            if (v == "None" || v == "none") return 1
            if (v == "Absent" || v == "absent") return 1
            if (v == "Not Present" || v == "Not Installed") return 1
            if (v == "Not Configured" || v == "Not Applicable") return 1
            if (v == "No Battery Connected") return 1
            return 0
        }
        NR > 1 {
            line = $0; sub(/\r$/, "", line)
            parse_csv(line, ff)
            rv    = ff[4]
            rm    = ff[5]
            busid = ff[10]
            bbu   = ff[23]

            if (rm == "" || rm == "N/A") next
            if (rv == "" || rv == "N/A") rv = "?"
            if (busid == "" || busid == "N/A") busid = "row" NR

            if (busid in seen) next
            seen[busid] = 1

            hasbbu = _bbu_absent(bbu) ? "0" : "1"
            cnt[rv "|" rm "|" hasbbu]++
        }
        END {
            n = sorted_keys(cnt, keys)
            for (i = 1; i <= n; i++) {
                split(keys[i], p, "|")
                out = p[1] " " p[2]
                if (p[3] == "1") out = out " BBU"
                printf "%s x %d\n", out, cnt[keys[i]]
            }
        }
    ' "RAID"
}

# ---------- NIC ----------
summarize_nic() {
    summarize_with_awk "$1" '
        NR > 1 {
            line = $0; sub(/\r$/, "", line)
            parse_csv(line, ff)
            model   = ff[3]
            product = ff[5]
            speed   = ff[7]
            portnum = ff[8]
            card    = ff[15]

            if (model == "" || model == "N/A") next
            if (product == "" || product == "N/A") product = ""
            if (card == "" || card == "N/A") card = "row" NR

            key = model "|" product "|" speed "|" portnum "|" card
            if (!(key in seen)) {
                seen[key] = 1
                order[++order_n] = key
            }
        }
        END {
            for (i = 1; i <= order_n; i++) {
                split(order[i], a, "|")
                gkey = a[1] "|" a[2] "|" a[3] "|" a[4]
                if (!(gkey in firstcard)) {
                    firstcard[gkey] = a[5]
                    out_order[++n] = gkey
                    cnt[gkey]++
                }
            }
            for (i = 1; i <= n; i++) {
                split(out_order[i], p, "|")
                if (p[2] == "")
                    printf "%s %sg %s x %d\n", p[1], p[3], p[4], cnt[out_order[i]]
                else
                    printf "%s %s %sg %s x %d\n", p[1], p[2], p[3], p[4], cnt[out_order[i]]
            }
        }
    ' "NIC"
}

# ---------- IB ----------
# ★ v23：摘要格式改为 <vendor> <model> <cap>g <portnum> x N
#         （去掉当前速率 ib_cur_speed_gb）
#   上游 collect_ib.sh 字段索引：
#     vendor  = ff[2]    ib_vendor
#     model   = ff[3]    ib_model
#     cap     = ff[6]    ib_cap_speed_gb（HCA 能力上限）
#     portnum = ff[8]    ib_port_num
#     card    = ff[13]   nic_pcie_bus_id（去重 key）
#   注：ff[7] = ib_cur_speed_gb 仍在 CSV 中，但本摘要不使用
summarize_ib() {
    summarize_with_awk "$1" '
        NR > 1 {
            line = $0; sub(/\r$/, "", line)
            parse_csv(line, ff)
            vendor  = ff[2]
            model   = ff[3]
            cap     = ff[6]
            portnum = ff[8]
            card    = ff[13]

            if (model == "" || model == "N/A") next
            if (vendor == "" || vendor == "N/A") vendor = "?"
            if (cap == "" || cap == "N/A") cap = "?"
            if (portnum == "" || portnum == "N/A") portnum = "?"
            if (card == "" || card == "N/A") card = "row" NR

            if (card in seen) next
            seen[card] = 1

            cnt[vendor "|" model "|" cap "|" portnum]++
        }
        END {
            n = sorted_keys(cnt, keys)
            for (i = 1; i <= n; i++) {
                split(keys[i], p, "|")
                printf "%s %s %sg %s x %d\n", p[1], p[2], p[3], p[4], cnt[keys[i]]
            }
        }
    ' "IB"
}

# ---------- GPU ----------
# ★ v21：gpu CSV 第 8 列为 gpu_memory_mib（单位 MiB，原始值）
#          汇总侧换算为整数 GiB：gib = int(mib/1024 + 0.5)
#          非数字 / 空 / 0 → "?"
summarize_gpu() {
    summarize_with_awk "$1" '
        function _to_gib(mib,   g) {
            if (mib == "" || mib == "N/A" || mib == "?") return "?"
            if (mib !~ /^[0-9]+$/) return "?"
            if (mib + 0 <= 0) return "?"
            g = mib / 1024
            return int(g + 0.5)
        }
        NR > 1 {
            line = $0; sub(/\r$/, "", line)
            parse_csv(line, ff)
            v = ff[4]; m = ff[5]; mem = ff[8]
            if (m == "" || m == "N/A") next
            mem_gib = _to_gib(mem)
            cnt[v "|" m "|" mem_gib]++
        }
        END {
            n = sorted_keys(cnt, keys)
            for (i = 1; i <= n; i++) {
                split(keys[i], p, "|")
                printf "%s \"%s\" %sGiB x %d\n", p[1], p[2], p[3], cnt[keys[i]]
            }
        }
    ' "GPU"
}

# ---------- PSU ----------
summarize_psu() {
    summarize_with_awk "$1" '
        NR > 1 {
            line = $0; sub(/\r$/, "", line)
            parse_csv(line, ff)
            v = ff[3]; m = ff[4]; w = ff[12]
            if (m == "" || m == "N/A") next
            cnt[v "|" m "|" w]++
        }
        END {
            n = sorted_keys(cnt, keys)
            for (i = 1; i <= n; i++) {
                split(keys[i], p, "|")
                printf "%s %s %sW x %d\n", p[1], p[2], p[3], cnt[keys[i]]
            }
        }
    ' "PSU"
}

# ---------- FAN ----------
summarize_fan() {
    local file="$1"
    if [[ ! -f "$file" || ! -s "$file" ]]; then
        log_debug "[汇总 FAN] 文件不存在或为空: $file"
        echo "N/A"
        return
    fi
    awk "${_AWK_CSV_PARSER}"'
        NR > 1 {
            line = $0; sub(/\r$/, "", line)
            parse_csv(line, ff)
            u = ff[6]
            total++
            if (u != "" && u != "N/A") {
                valid++
                cnt[u]++
            }
        }
        END {
            if (total == 0) { print "N/A"; exit }
            if (valid == 0) { printf "FAN x %d\n", total; exit }
            n = 0
            for (k in cnt) keys[++n] = k
            for (i = 1; i <= n; i++)
                for (j = i + 1; j <= n; j++)
                    if (keys[i] + 0 > keys[j] + 0) { t = keys[i]; keys[i] = keys[j]; keys[j] = t }
            for (i = 1; i <= n; i++) printf "FAN %sRPM x %d\n", keys[i], cnt[keys[i]]
        }
    ' "$file"
}

# ============================================================================
# CSV 输出
# ============================================================================

generate_output_filename() {
    local serial="$1"
    local clean_serial=$(echo "$serial" | sed 's/[^a-zA-Z0-9_-]//g')
    if [[ -z "$clean_serial" ]] || [[ "$clean_serial" == "UNKNOWN" ]]; then
        echo "${OUTPUT_DIR}/server_info.csv"
    else
        echo "${OUTPUT_DIR}/server_info_${clean_serial}.csv"
    fi
}

write_csv_header() {
    local output_file="$1"
    cat > "$output_file" <<'HEADER'
server_serial,chassis_asset_tag,server_vendor,server_model,server_uuid,bios_vendor,bios_release_date,bios_version,bios_revision,board_product_name,board_serial,board_version,ipmi_ip,ipmi_subnet_mask,ipmi_gateway_ip,ipmi_mac,bmc_version,os_type,kernel_version,ofed_version,server_cpu_summary,server_mem_summary,server_mem_total,server_drive_summary,server_raid_summary,server_nic_summary,server_ib_summary,server_gpu_summary,server_psu_summary,server_fan_summary
HEADER
    log_debug "CSV头已写入: $output_file"
}

# ============================================================================
# 组件汇总 —— 统一入口
# ============================================================================

_SUMMARY_FILES=(
    "cpu_info_%s.csv:cpu_summary:CPU"
    "memory_info_%s.csv:mem_summary:MEM"
    "memory_info_%s.csv:mem_total:MEM_TOTAL"
    "disk_info_%s.csv:drive_summary:DRIVE"
    "raid_info_%s.csv:raid_summary:RAID"
    "nic_info_%s.csv:nic_summary:NIC"
    "ib_info_%s.csv:ib_summary:IB"
    "gpu_info_%s.csv:gpu_summary:GPU"
    "psu_info_%s.csv:psu_summary:PSU"
    "fan_info_%s.csv:fan_summary:FAN"
)

collect_server_info() {
    local serial="$1"
    local output_file="$2"

    log_info "正在收集服务器基础信息..."

    cache_dmidecode
    cache_ipmitool_lan

    local vendor=$(get_server_vendor)
    local model=$(get_server_model)
    local server_uuid=$(get_server_uuid)
    local bios_vendor=$(get_bios_vendor)
    local bios_release_date=$(get_bios_release_date)
    local bios_version=$(get_bios_version)
    local bios_revision=$(get_bios_revision)
    local board_product_name=$(get_board_product_name)
    local board_serial=$(get_board_serial)
    local board_version=$(get_board_version)
    local chassis_asset_tag=$(get_chassis_asset_tag)
    local ipmi_ip=$(get_ipmi_ip)
    local ipmi_subnet_mask=$(get_ipmi_subnet_mask)
    local ipmi_gateway_ip=$(get_ipmi_gateway_ip)
    local ipmi_mac=$(get_ipmi_mac)
    local bmc_version=$(get_bmc_version)
    local os_type=$(get_os_type)
    local kernel_version=$(get_kernel_version)
    local ofed_version=$(get_ofed_version)

    log_info "正在汇总组件信息（SN: $serial，目录: $OUTPUT_DIR）..."

    if [[ ! -d "$OUTPUT_DIR" ]]; then
        log_warn "输出目录不存在: $OUTPUT_DIR"
    else
        local _missing=0 _total=0
        local _f
        for _f in cpu_info memory_info disk_info raid_info nic_info ib_info gpu_info psu_info fan_info; do
            _total=$((_total + 1))
            [[ ! -f "${OUTPUT_DIR}/${_f}_${serial}.csv" ]] && _missing=$((_missing + 1))
        done
        if [[ $_missing -gt 0 ]]; then
            log_warn "有 ${_missing}/${_total} 个子报告缺失（在 ${OUTPUT_DIR} 下）"
        fi
    fi

    local dir="${OUTPUT_DIR}"
    local cpu_summary=$(summarize_cpu       "${dir}/cpu_info_${serial}.csv")
    local mem_summary=$(summarize_mem       "${dir}/memory_info_${serial}.csv")
    local mem_total=$(summarize_mem_total   "${dir}/memory_info_${serial}.csv")
    local drive_summary=$(summarize_drive   "${dir}/disk_info_${serial}.csv")
    local raid_summary=$(summarize_raid     "${dir}/raid_info_${serial}.csv")
    local nic_summary=$(summarize_nic       "${dir}/nic_info_${serial}.csv")
    local ib_summary=$(summarize_ib         "${dir}/ib_info_${serial}.csv")
    local gpu_summary=$(summarize_gpu       "${dir}/gpu_info_${serial}.csv")
    local psu_summary=$(summarize_psu       "${dir}/psu_info_${serial}.csv")
    local fan_summary=$(summarize_fan       "${dir}/fan_info_${serial}.csv")

    [[ -z "$mem_total" ]]    && mem_total="N/A"
    [[ -z "$raid_summary" ]] && raid_summary="N/A"
    [[ -z "$ib_summary" ]]   && ib_summary="N/A"
    [[ -z "$fan_summary" ]]  && fan_summary="N/A"

    local fields=(
        "$serial" "$chassis_asset_tag" "$vendor" "$model" "$server_uuid"
        "$bios_vendor" "$bios_release_date" "$bios_version" "$bios_revision"
        "$board_product_name" "$board_serial" "$board_version"
        "$ipmi_ip" "$ipmi_subnet_mask" "$ipmi_gateway_ip" "$ipmi_mac"
        "$bmc_version" "$os_type" "$kernel_version" "$ofed_version"
        "$cpu_summary" "$mem_summary" "$mem_total" "$drive_summary"
        "$raid_summary" "$nic_summary" "$ib_summary" "$gpu_summary"
        "$psu_summary" "$fan_summary"
    )

    local out="" f
    for f in "${fields[@]}"; do
        out+="$(csv_escape "$f"),"
    done
    printf '%s\n' "${out%,}" >> "$output_file"

    log_info "✅ 服务器信息收集完成"
    log_info "   - CPU: $(echo "$cpu_summary" | tr '\n' ';')"
    log_info "   - MEM: $(echo "$mem_summary" | tr '\n' ';')"
    log_info "   - MEM Total: $mem_total"
    log_info "   - Drive: $(echo "$drive_summary" | tr '\n' ';')"
    log_info "   - RAID: $(echo "$raid_summary" | tr '\n' ';')"
    log_info "   - NIC: $(echo "$nic_summary" | tr '\n' ';')"
    log_info "   - IB: $(echo "$ib_summary" | tr '\n' ';')"
    log_info "   - GPU: $(echo "$gpu_summary" | tr '\n' ';')"
    log_info "   - PSU: $(echo "$psu_summary" | tr '\n' ';')"
    log_info "   - Fan: $fan_summary"

    echo "1"
}

# ============================================================================
# 主函数
# ============================================================================

main() {
    print_header "服务器基础信息收集工具 - v23"

    SYSTEM_SERIAL=$(get_system_serial)
    OUTPUT_FILE=$(generate_output_filename "$SYSTEM_SERIAL")

    command -v dmidecode &>/dev/null || log_warn "dmidecode 未安装"
    command -v ipmitool &>/dev/null || log_warn "ipmitool 未安装"

    if ! detect_sudo; then
        log_warn "无免密 sudo，硬件信息可能不完整（Ansible 场景请使用 become: yes）"
    fi

    [[ -d "$OUTPUT_DIR" ]] || mkdir -p "$OUTPUT_DIR" 2>/dev/null || {
        log_error "无法创建输出目录: $OUTPUT_DIR"
        exit 1
    }

    log_debug "最终输出目录: $OUTPUT_DIR"
    log_debug "最终输出文件: $OUTPUT_FILE"

    write_csv_header "$OUTPUT_FILE"

    local record_count
    record_count=$(collect_server_info "$SYSTEM_SERIAL" "$OUTPUT_FILE")

    print_separator
    echo -e "${GREEN}✅ 完成！${NC}" >&2
    print_separator
    echo -e "📁 输出文件: ${BLUE}$OUTPUT_FILE${NC}" >&2

    if [[ -f "$OUTPUT_FILE" ]]; then
        local line_count=$(($(wc -l < "$OUTPUT_FILE") - 1))
        echo -e "📊 服务器记录: ${BLUE}$line_count${NC} 条" >&2
        print_separator
        cat "$OUTPUT_FILE"
        print_separator
    else
        log_error "输出文件生成失败"
        exit 1
    fi
}

# ============================================================================
# 帮助 & 参数
# ============================================================================

show_help() {
    cat << EOF
服务器基础信息收集工具 - v23

用法: $SCRIPT_NAME [选项]

选项:
    -h, --help          显示此帮助信息
    -d, --debug         启用调试模式
    -o, --output DIR    指定输出目录（默认: <脚本目录>/report）
    -s, --serial SN     手动指定系统序列号

组件汇总格式:
    cpu         : <cpu_model> x N
    mem_summary : <mem_type> <mem_vendor> <mem_product> <clock>Mhz <size>G x N
    mem_total   : <总GB数>GB
    drive       : <disk_type> <disk_vendor> <disk_model> <disk_size_gb>GB x N
    raid        : <raid_vendor> <raid_model> [BBU] x N
    nic         : <nic_model> [<nic_product>] <speed_gb>g <port_num> x N
    ib          : <ib_vendor> <ib_model> <ib_cap_speed_gb>g <ib_port_num> x N
    gpu         : <gpu_vendor> "<gpu_model>" <gpu_memory_gib>GiB x N
    psu         : <psu_vendor> <psu_model> <psu_power_w>W x N
    fan         : <数量>

IB 摘要格式（v23）:
    上游 collect_ib.sh 输出的 ib_cap_speed_gb 表示 HCA 硬件支持的最高速率
    （单位 Gb/s），本脚本按该能力值汇总展示：
        <ib_vendor> <ib_model> <ib_cap_speed_gb>g <ib_port_num> x N
    示例：
        Mellanox "MT2910 Family [ConnectX-7]" 400g 1P x 1
        Mellanox "MT28908 Family [ConnectX-6]" 200g 1P x 4
    说明：
        - 能力值来自 mlxlink 的 "Enabled Link Speed"
        - 未安装 mlxlink 时该字段可能为 "?"（此时摘要显示 "?g"）
        - 当前协商速率（ib_cur_speed_gb）仍在 IB CSV 中，只是不参与摘要

GPU 显存单位（v21）:
    上游 collect_gpu.sh 输出的 gpu_memory_mib 字段是 nvidia-smi memory.total
    的原始值，单位 MiB。本脚本在汇总时按 int(mib/1024 + 0.5) 换算成
    整数 GiB 展示，避免出现 79GiB（H100 80G 报值 81559 MiB 的场景）。
    例：
      81920 MiB → 80GiB   (A100 80G)
      81559 MiB → 80GiB   (H100 80G)
      40960 MiB → 40GiB   (A100 40G)
      24576 MiB → 24GiB   (RTX 3090)
      24564 MiB → 24GiB   (RTX 4090)
      11264 MiB → 11GiB   (RTX 2080 Ti)
    摘要格式：NVIDIA "H100" 80GiB x 8

BBU 判定说明（v19）:
    只有 raid_bbu_state 代表"有 BBU/CV 硬件"时，才在 raid 摘要中加 "BBU"。
    以下值不视为 BBU（不会在摘要里加 "BBU"）：
        ""  "N/A"  "NA"  "-"  "None"  "Absent"
        "Not Present"  "Not Installed"  "Not Configured"
        "Not Applicable"  "No Battery Connected"
    其余值（Optimal / Present / OK / Charging / Learning 等）视为有 BBU。

示例:
    sudo $SCRIPT_NAME
    sudo $SCRIPT_NAME -d
    OUTPUT_DIR=/tmp/report $SCRIPT_NAME
EOF
}

parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            -h|--help)   show_help; exit 0 ;;
            -d|--debug)  DEBUG="true"; shift ;;
            -o|--output) OUTPUT_DIR="$2"; shift 2 ;;
            -s|--serial) SYSTEM_SERIAL="$2"; shift 2 ;;
            *) log_error "未知选项: $1"; show_help; exit 1 ;;
        esac
    done
}

set -o pipefail 2>/dev/null || true

parse_args "$@"
main
